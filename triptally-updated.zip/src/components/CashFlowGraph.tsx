import { useMemo, useState } from 'react';
import type { Member, OriginalDebtEdge, SimplifiedDebt } from '../types';
import { formatINR, getInitials } from '../utils/finance';

interface CashFlowGraphProps {
  members: Member[];
  pairwiseDebts: OriginalDebtEdge[];
  simplifiedTransactions: SimplifiedDebt[];
}

export function CashFlowGraph({
  members,
  pairwiseDebts,
  simplifiedTransactions,
}: CashFlowGraphProps) {
  const [mode, setMode] = useState<'after' | 'before'>('after');

  const layout = useMemo(() => {
    const count = Math.max(1, members.length);
    const width = 460;
    const height = 270;
    const cx = width / 2;
    const cy = height / 2;
    const rx = Math.min(155, 110 + count * 8);
    const ry = 92;

    const coords = new Map<string, { x: number; y: number }>();
    members.forEach((m, idx) => {
      const angle = (idx / count) * Math.PI * 2 - Math.PI / 2;
      coords.set(m.id, {
        x: cx + rx * Math.cos(angle),
        y: cy + ry * Math.sin(angle),
      });
    });

    return { width, height, coords };
  }, [members]);

  const activeEdges = useMemo(() => {
    if (mode === 'after') {
      return simplifiedTransactions.map((tx) => ({
        key: tx.id,
        from: tx.fromMemberId,
        to: tx.toMemberId,
        amountPaise: tx.amountPaise,
        color: '#7047EB',
      }));
    }
    return pairwiseDebts.map((edge) => ({
      key: `${edge.fromMemberId}_${edge.toMemberId}`,
      from: edge.fromMemberId,
      to: edge.toMemberId,
      amountPaise: edge.amountPaise,
      color: '#94A3B8',
    }));
  }, [mode, simplifiedTransactions, pairwiseDebts]);

  if (members.length === 0) return null;

  return (
    <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-base font-bold text-[#101828]">
            Cash-Flow Network Visualization
          </h2>
          <p className="text-xs text-[#525870]">
            Compare the dense pairwise debt web against the minimized settlement graph
          </p>
        </div>

        <div className="inline-flex rounded-lg border border-[#E5E3F3] bg-[#F6F5FC] p-1">
          <button
            type="button"
            onClick={() => setMode('before')}
            className={`rounded-md px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
              mode === 'before'
                ? 'bg-white text-[#101828] shadow-sm'
                : 'text-[#525870] hover:text-[#101828]'
            }`}
          >
            Before ({pairwiseDebts.length} edges)
          </button>
          <button
            type="button"
            onClick={() => setMode('after')}
            className={`rounded-md px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
              mode === 'after'
                ? 'bg-[#7047EB] text-white shadow-sm'
                : 'text-[#525870] hover:text-[#101828]'
            }`}
          >
            After ({simplifiedTransactions.length} transfers)
          </button>
        </div>
      </div>

      <div className="overflow-x-auto rounded-xl bg-[#F6F5FC]/70 p-3">
        <svg
          viewBox={`0 0 ${layout.width} ${layout.height}`}
          className="mx-auto h-64 w-full max-w-[520px]"
          role="img"
          aria-label="Directed cash flow settlement graph"
        >
          <defs>
            <marker
              id="arrow-purple"
              viewBox="0 0 10 10"
              refX="22"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#7047EB" />
            </marker>
            <marker
              id="arrow-slate"
              viewBox="0 0 10 10"
              refX="22"
              refY="5"
              markerWidth="5.5"
              markerHeight="5.5"
              orient="auto-start-reverse"
            >
              <path d="M 0 1 L 10 5 L 0 9 z" fill="#64748B" />
            </marker>
          </defs>

          {/* Directed Edges */}
          {activeEdges.map((edge, idx) => {
            const p1 = layout.coords.get(edge.from);
            const p2 = layout.coords.get(edge.to);
            if (!p1 || !p2) return null;

            // Slight curve offset so opposing edges (A->B and B->A) don't overlap
            const dx = p2.x - p1.x;
            const dy = p2.y - p1.y;
            const len = Math.hypot(dx, dy) || 1;
            const curveSign = edge.from < edge.to ? 1 : -1;
            const offset = mode === 'before' ? 18 * curveSign : 10 * ((idx % 2 === 0 ? 1 : -1));
            const mx = (p1.x + p2.x) / 2 - (dy / len) * offset;
            const my = (p1.y + p2.y) / 2 + (dx / len) * offset;

            return (
              <g key={edge.key}>
                <path
                  d={`M ${p1.x} ${p1.y} Q ${mx} ${my} ${p2.x} ${p2.y}`}
                  fill="none"
                  stroke={edge.color}
                  strokeWidth={mode === 'after' ? 2.4 : 1.6}
                  strokeDasharray={mode === 'before' ? '4 3' : undefined}
                  markerEnd={mode === 'after' ? 'url(#arrow-purple)' : 'url(#arrow-slate)'}
                />
                <rect
                  x={mx - 26}
                  y={my - 9}
                  width={52}
                  height={18}
                  rx={5}
                  fill="#FFFFFF"
                  stroke={edge.color}
                  strokeWidth={1}
                />
                <text
                  x={mx}
                  y={my + 3.5}
                  textAnchor="middle"
                  fontSize={9.5}
                  fontWeight={700}
                  fontFamily="JetBrains Mono, monospace"
                  fill="#101828"
                >
                  {formatINR(edge.amountPaise)}
                </text>
              </g>
            );
          })}

          {/* Member Nodes */}
          {members.map((m) => {
            const pos = layout.coords.get(m.id);
            if (!pos) return null;
            return (
              <g key={m.id} transform={`translate(${pos.x}, ${pos.y})`}>
                <circle
                  r={21}
                  fill={m.avatarColor || '#7047EB'}
                  stroke="#FFFFFF"
                  strokeWidth={3}
                />
                <text
                  y={4}
                  textAnchor="middle"
                  fontSize={11}
                  fontWeight={700}
                  fill="#FFFFFF"
                >
                  {getInitials(m.name)}
                </text>
                <text
                  y={35}
                  textAnchor="middle"
                  fontSize={11}
                  fontWeight={600}
                  fill="#101828"
                >
                  {m.name.split(' ')[0]}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
}
