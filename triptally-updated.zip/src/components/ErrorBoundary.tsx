import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error.message || 'An unexpected rendering error occurred.',
    };
  }

  handleRecover = () => {
    this.setState({ hasError: false, errorMessage: '' });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen items-center justify-center bg-[#F6F5FC] p-6">
          <div className="w-full max-w-md rounded-xl border border-[#E5E3F3] bg-white p-6 text-center shadow-lg">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-[#EF5350]/12 text-[#EF5350]">
              <AlertTriangle size={24} />
            </div>
            <h1 className="mt-4 font-display text-lg font-bold text-[#101828]">
              Something Went Wrong
            </h1>
            <p className="mt-1.5 text-xs leading-relaxed text-[#525870]">
              {this.state.errorMessage}
            </p>
            <div className="mt-5 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={this.handleRecover}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#7047EB] px-4 py-2 text-xs font-semibold text-white hover:bg-[#5B34D6]"
              >
                <RotateCcw size={14} /> Try Again
              </button>
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="rounded-lg border border-[#E5E3F3] px-4 py-2 text-xs font-semibold text-[#101828] hover:bg-[#F6F5FC]"
              >
                Reload Page
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
