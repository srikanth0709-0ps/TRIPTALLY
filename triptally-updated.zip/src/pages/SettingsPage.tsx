import React, { useState } from 'react';
import { Download, RotateCcw, Upload } from 'lucide-react';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { useTripTally } from '../context/TripTallyContext';
import type { SplitType, TripTallyState } from '../types';

export function SettingsPage() {
  const { state, updateSettings, resetDemoData, importState, pushToast } = useTripTally();
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  const handleExportJson = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `triptally-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    pushToast({
      type: 'success',
      title: 'Workspace Backup Exported',
    });
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as TripTallyState;
        if (!parsed || !Array.isArray(parsed.trips) || !Array.isArray(parsed.members)) {
          throw new Error('Invalid TripTally backup structure');
        }
        importState(parsed);
      } catch {
        pushToast({
          type: 'error',
          title: 'Invalid Backup File',
          description: 'Please upload a valid TripTally JSON export.',
        });
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      {/* Active User & Split Defaults */}
      <section className="rounded-xl border border-[#E5E3F3] bg-white p-6">
        <h2 className="font-display text-base font-bold text-[#101828]">
          Workspace Preferences
        </h2>
        <p className="mt-0.5 text-xs text-[#525870]">
          Configure your active traveler perspective and default expense split mode.
        </p>

        <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
              Active Profile (&ldquo;You&rdquo; on Dashboard)
            </label>
            <select
              value={state.settings.activeUserId}
              onChange={(e) => updateSettings({ activeUserId: e.target.value })}
              className="w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm text-[#101828] outline-none focus:border-[#7047EB]"
            >
              {state.members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.upiId})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
              Default Expense Split Method
            </label>
            <select
              value={state.settings.defaultSplitType}
              onChange={(e) =>
                updateSettings({ defaultSplitType: e.target.value as SplitType })
              }
              className="w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm text-[#101828] outline-none focus:border-[#7047EB]"
            >
              <option value="equal">Equal Split</option>
              <option value="subset">Subset Split</option>
              <option value="exact">Exact Amount Split</option>
            </select>
          </div>
        </div>
      </section>

      {/* Smart Budget Alert Thresholds */}
      <section className="rounded-xl border border-[#E5E3F3] bg-white p-6">
        <h2 className="font-display text-base font-bold text-[#101828]">
          Smart Budget Alert Thresholds
        </h2>
        <p className="mt-0.5 text-xs text-[#525870]">
          Receive proactive warnings in the notification center when trip spending reaches
          key budget milestones.
        </p>

        <div className="mt-4 divide-y divide-[#EFEFF7]">
          {[
            {
              key: 'enable75Alert' as const,
              title: '75% Budget Advisory',
              desc: 'Early heads-up when three-quarters of a trip budget is consumed.',
            },
            {
              key: 'enable90Alert' as const,
              title: '90% High Utilization Warning',
              desc: 'Urgent alert when less than 10% of the trip budget remains.',
            },
            {
              key: 'enable100Alert' as const,
              title: '100%+ Limit & Over-Budget Alert',
              desc: 'Critical alert when spending matches or exceeds the allocated budget.',
            },
          ].map((item) => (
            <label
              key={item.key}
              className="flex cursor-pointer items-center justify-between gap-4 py-3.5"
            >
              <div>
                <p className="text-sm font-semibold text-[#101828]">{item.title}</p>
                <p className="text-xs text-[#525870]">{item.desc}</p>
              </div>
              <input
                type="checkbox"
                checked={state.settings[item.key]}
                onChange={(e) => updateSettings({ [item.key]: e.target.checked })}
                className="h-4 w-4 accent-[#7047EB]"
              />
            </label>
          ))}
        </div>
      </section>

      {/* Data Persistence & Demo Controls */}
      <section className="rounded-xl border border-[#E5E3F3] bg-white p-6">
        <h2 className="font-display text-base font-bold text-[#101828]">
          Data Backup & Demo Reset
        </h2>
        <p className="mt-0.5 text-xs text-[#525870]">
          Changes automatically persist to both your browser LocalStorage and the TripTally
          SQLite database.
        </p>

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={handleExportJson}
            className="inline-flex items-center gap-2 rounded-lg border border-[#E5E3F3] bg-white px-4 py-2 text-xs font-semibold text-[#101828] hover:bg-[#F6F5FC]"
          >
            <Download size={14} /> Export JSON Backup
          </button>

          <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-[#E5E3F3] bg-white px-4 py-2 text-xs font-semibold text-[#101828] hover:bg-[#F6F5FC]">
            <Upload size={14} /> Import JSON Backup
            <input
              type="file"
              accept="application/json"
              onChange={handleImportJson}
              className="hidden"
            />
          </label>

          <a
            href="/api/download-zip"
            download="triptally-updated.zip"
            className="inline-flex items-center gap-2 rounded-lg bg-[#101828] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1E293B]"
          >
            <Download size={14} /> Download Project ZIP
          </a>

          <button
            type="button"
            onClick={() => setConfirmResetOpen(true)}
            className="inline-flex items-center gap-2 rounded-lg border border-[#EF5350]/30 bg-[#EF5350]/8 px-4 py-2 text-xs font-semibold text-[#EF5350] hover:bg-[#EF5350]/15"
          >
            <RotateCcw size={14} /> Reset to Goa Demo Dataset
          </button>
        </div>
      </section>

      <ConfirmDialog
        open={confirmResetOpen}
        title="Reset Workspace to Demo Data?"
        description="This will restore Goa Road Trip 2026 (8 sample expenses) and Manali Winter Escape, replacing any custom edits you made."
        confirmLabel="Restore Demo Data"
        onCancel={() => setConfirmResetOpen(false)}
        onConfirm={() => {
          resetDemoData();
          setConfirmResetOpen(false);
        }}
      />
    </div>
  );
}
