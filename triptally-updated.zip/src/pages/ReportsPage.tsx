import React, { useMemo, useState } from 'react';
import {
  Download,
  Eye,
  FileText,
  Image as ImageIcon,
  Trash2,
  Upload,
} from 'lucide-react';
import { CategoryIcon } from '../components/CategoryIcon';
import { ReceiptPreviewModal } from '../components/ReceiptPreviewModal';
import { useTripTally } from '../context/TripTallyContext';
import { exportTripFinancialPdf } from '../services/pdfReport';
import type { Expense, Member } from '../types';
import {
  ALL_CATEGORIES,
  computeBudgetAlert,
  formatDateShort,
  formatINR,
  runDebtSimplification,
} from '../utils/finance';

export function ReportsPage() {
  const {
    state,
    attachReceiptToExpense,
    removeReceiptFromExpense,
    pushToast,
  } = useTripTally();

  const [selectedTripId, setSelectedTripId] = useState<string>(
    () => state.trips[0]?.id ?? ''
  );
  const [previewExpense, setPreviewExpense] = useState<Expense | null>(null);
  const [uploadTargetExpenseId, setUploadTargetExpenseId] = useState<string>('');

  const selectedTrip = useMemo(
    () => state.trips.find((t) => t.id === selectedTripId) ?? state.trips[0],
    [state.trips, selectedTripId]
  );

  const memberMap = useMemo(
    () => new Map<string, Member>(state.members.map((m) => [m.id, m])),
    [state.members]
  );

  const tripExpenses = useMemo(
    () =>
      selectedTrip
        ? state.expenses
            .filter((e) => e.tripId === selectedTrip.id)
            .sort((a, b) => a.date.localeCompare(b.date))
        : [],
    [state.expenses, selectedTrip]
  );

  const tripSettlements = useMemo(
    () =>
      selectedTrip
        ? state.settlements.filter((s) => s.tripId === selectedTrip.id)
        : [],
    [state.settlements, selectedTrip]
  );

  const reportData = useMemo(() => {
    if (!selectedTrip) return null;
    const totalSpentPaise = tripExpenses.reduce((acc, e) => acc + e.amountPaise, 0);
    const alert = computeBudgetAlert(selectedTrip, totalSpentPaise);
    const sim = runDebtSimplification(
      selectedTrip.memberIds,
      state.members,
      tripExpenses,
      tripSettlements
    );
    const categoryRows = ALL_CATEGORIES.map((cat) => {
      const items = tripExpenses.filter((e) => e.category === cat);
      const sumPaise = items.reduce((acc, e) => acc + e.amountPaise, 0);
      return { cat, count: items.length, sumPaise };
    }).filter((r) => r.count > 0);

    return { totalSpentPaise, alert, sim, categoryRows };
  }, [selectedTrip, tripExpenses, state.members, tripSettlements]);

  const expensesWithReceipts = useMemo(
    () => state.expenses.filter((e) => Boolean(e.receipt)),
    [state.expenses]
  );

  const expensesWithoutReceipts = useMemo(
    () => state.expenses.filter((e) => !e.receipt),
    [state.expenses]
  );

  const handleUploadGalleryReceipt = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const targetId = uploadTargetExpenseId || expensesWithoutReceipts[0]?.id;
    if (!file || !targetId) return;
    if (file.size > 4 * 1024 * 1024) {
      pushToast({
        type: 'error',
        title: 'File Too Large',
        description: 'Receipt images must be under 4 MB.',
      });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        attachReceiptToExpense(targetId, {
          id: `rcpt_${Date.now()}`,
          name: file.name,
          dataUrl: reader.result,
          uploadedAt: new Date().toISOString(),
          sizeBytes: file.size,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDownloadPdf = () => {
    if (!selectedTrip) return;
    exportTripFinancialPdf({
      trip: selectedTrip,
      members: state.members,
      expenses: state.expenses,
      settlements: state.settlements,
    });
    pushToast({
      type: 'success',
      title: 'PDF Financial Statement Downloaded',
      description: `Saved report for ${selectedTrip.name}.`,
    });
  };

  const handleDownloadCsv = () => {
    if (!selectedTrip) return;
    const escapeCsv = (val: string) => `"${val.replace(/"/g, '""')}"`;
    const headers = ['Date', 'Title', 'Category', 'Paid By', 'Split Type', 'Amount (INR)', 'Notes'];
    const rows = tripExpenses.map((exp) => [
      exp.date,
      escapeCsv(exp.title),
      exp.category,
      escapeCsv(memberMap.get(exp.paidByMemberId)?.name ?? exp.paidByMemberId),
      exp.splitType,
      (exp.amountPaise / 100).toFixed(2),
      escapeCsv(exp.notes),
    ]);
    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `triptally-${selectedTrip.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    pushToast({
      type: 'success',
      title: 'CSV Ledger Exported',
      description: `Exported ${tripExpenses.length} expense rows for ${selectedTrip.name}.`,
    });
  };

  return (
    <div className="space-y-6">
      {/* PDF Financial Report Section */}
      <section className="rounded-xl border border-[#E5E3F3] bg-white p-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#EFEFF7] pb-5">
          <div>
            <h2 className="font-display text-lg font-bold text-[#101828]">
              Trip Financial Report & Statement
            </h2>
            <p className="text-xs text-[#525870]">
              Generate a complete, audit-ready PDF financial report or CSV spreadsheet for your group.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <select
              value={selectedTrip?.id ?? ''}
              onChange={(e) => setSelectedTripId(e.target.value)}
              className="rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-xs font-semibold text-[#101828] outline-none focus:border-[#7047EB]"
            >
              {state.trips.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>

            <button
              type="button"
              disabled={!selectedTrip}
              onClick={handleDownloadCsv}
              className="inline-flex items-center gap-2 rounded-lg border border-[#E5E3F3] bg-white px-4 py-2 text-xs font-semibold text-[#101828] transition-colors hover:bg-[#F6F5FC] disabled:opacity-50"
            >
              <Download size={14} />
              Export CSV
            </button>

            <button
              type="button"
              disabled={!selectedTrip}
              onClick={handleDownloadPdf}
              className="inline-flex items-center gap-2 rounded-lg bg-[#7047EB] px-4 py-2 text-xs font-semibold text-white shadow-sm transition-colors hover:bg-[#5B34D6] disabled:opacity-50"
            >
              <Download size={15} />
              Download PDF Report
            </button>
          </div>
        </div>

        {selectedTrip && reportData && (
          <div className="mt-6 space-y-6">
            {/* Statement Summary Header */}
            <div className="grid grid-cols-2 gap-4 rounded-xl bg-[#F6F5FC] p-5 sm:grid-cols-4">
              <div>
                <p className="text-xs text-[#525870]">Trip & Destination</p>
                <p className="mt-1 text-sm font-bold text-[#101828]">
                  {selectedTrip.name}
                </p>
                <p className="text-xs text-[#525870]">{selectedTrip.destination}</p>
              </div>
              <div>
                <p className="text-xs text-[#525870]">Dates</p>
                <p className="tabular-nums mt-1 text-sm font-semibold text-[#101828]">
                  {formatDateShort(selectedTrip.startDate)}
                </p>
                <p className="tabular-nums text-xs text-[#525870]">
                  to {formatDateShort(selectedTrip.endDate)}
                </p>
              </div>
              <div>
                <p className="text-xs text-[#525870]">Budget vs. Spend</p>
                <p className="font-mono-tabular mt-1 text-sm font-bold text-[#101828]">
                  {formatINR(reportData.totalSpentPaise)} /{' '}
                  {formatINR(selectedTrip.budgetPaise)}
                </p>
                <p className="font-mono-tabular text-xs text-[#7047EB]">
                  {reportData.alert.utilizationPercent.toFixed(1)}% utilized
                </p>
              </div>
              <div>
                <p className="text-xs text-[#525870]">Settlements Needed</p>
                <p className="font-mono-tabular mt-1 text-sm font-bold text-[#101828]">
                  {reportData.sim.simplifiedTransactions.length} transfers
                </p>
                <p className="font-mono-tabular text-xs text-[#16A36A]">
                  {formatINR(reportData.sim.totalSettlementVolumePaise)} volume
                </p>
              </div>
            </div>

            {/* Category Breakdown & Balances Preview */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <div>
                <h3 className="mb-3 flex items-center gap-2 text-xs font-bold text-[#101828]">
                  <FileText size={14} className="text-[#7047EB]" />
                  Category Breakdown
                </h3>
                <div className="divide-y divide-[#EFEFF7] rounded-lg border border-[#EFEFF7]">
                  {reportData.categoryRows.map((row) => (
                    <div
                      key={row.cat}
                      className="flex items-center justify-between px-4 py-2.5 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <CategoryIcon category={row.cat} showLabel />
                        <span className="tabular-nums text-[#525870]">
                          ({row.count} bills)
                        </span>
                      </div>
                      <span className="font-mono-tabular font-bold text-[#101828]">
                        {formatINR(row.sumPaise)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="mb-3 text-xs font-bold text-[#101828]">
                  Final Settlement Instructions
                </h3>
                <div className="divide-y divide-[#EFEFF7] rounded-lg border border-[#EFEFF7]">
                  {reportData.sim.simplifiedTransactions.length === 0 ? (
                    <p className="p-4 text-center text-xs text-[#16A36A]">
                      All balances settled!
                    </p>
                  ) : (
                    reportData.sim.simplifiedTransactions.map((tx) => (
                      <div
                        key={tx.id}
                        className="flex items-center justify-between px-4 py-2.5 text-xs"
                      >
                        <span className="font-medium text-[#101828]">
                          {memberMap.get(tx.fromMemberId)?.name} →{' '}
                          {memberMap.get(tx.toMemberId)?.name}
                        </span>
                        <span className="font-mono-tabular font-bold text-[#7047EB]">
                          {formatINR(tx.amountPaise)}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* Receipt Gallery */}
      <section className="rounded-xl border border-[#E5E3F3] bg-white p-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#EFEFF7] pb-4">
          <div>
            <h2 className="font-display text-base font-bold text-[#101828]">
              Receipt Gallery ({expensesWithReceipts.length})
            </h2>
            <p className="text-xs text-[#525870]">
              Uploaded bills, hotel invoices, and fuel receipts linked to trip expenses
            </p>
          </div>

          {expensesWithoutReceipts.length > 0 && (
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={uploadTargetExpenseId || expensesWithoutReceipts[0]?.id}
                onChange={(e) => setUploadTargetExpenseId(e.target.value)}
                className="max-w-[220px] rounded-lg border border-[#E5E3F3] bg-white px-3 py-2 text-xs text-[#101828] outline-none"
              >
                {expensesWithoutReceipts.map((exp) => (
                  <option key={exp.id} value={exp.id}>
                    Attach to: {exp.title}
                  </option>
                ))}
              </select>
              <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg bg-[#101828] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#1E293B]">
                <Upload size={14} />
                Upload Receipt
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleUploadGalleryReceipt}
                  className="hidden"
                />
              </label>
            </div>
          )}
        </div>

        {expensesWithReceipts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <ImageIcon size={28} className="text-slate-300" />
            <p className="mt-2 text-sm font-semibold text-[#101828]">
              No Receipts Uploaded
            </p>
            <p className="mt-1 text-xs text-[#525870]">
              Attach receipt images when adding expenses or upload one above.
            </p>
          </div>
        ) : (
          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {expensesWithReceipts.map((exp) => (
              <div
                key={exp.id}
                className="overflow-hidden rounded-xl border border-[#E5E3F3] bg-[#F6F5FC]/50"
              >
                <div className="relative h-44 bg-white">
                  <img
                    src={exp.receipt!.dataUrl}
                    alt={exp.receipt!.name}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="p-3.5">
                  <p className="truncate text-xs font-bold text-[#101828]">{exp.title}</p>
                  <p className="font-mono-tabular mt-0.5 text-xs text-[#525870]">
                    {formatINR(exp.amountPaise)} · {formatDateShort(exp.date)}
                  </p>
                  <div className="mt-3 flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setPreviewExpense(exp)}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-[#3478F6] hover:underline"
                    >
                      <Eye size={13} /> Inspect
                    </button>
                    <button
                      type="button"
                      onClick={() => removeReceiptFromExpense(exp.id)}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-[#EF5350] hover:underline"
                    >
                      <Trash2 size={13} /> Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <ReceiptPreviewModal
        expense={previewExpense}
        onClose={() => setPreviewExpense(null)}
        onDeleteReceipt={removeReceiptFromExpense}
      />
    </div>
  );
}
