import type {
  BudgetAlertInfo,
  Expense,
  ExpenseCategory,
  ExpenseSplit,
  Member,
  MemberBalance,
  OriginalDebtEdge,
  SettlementRecord,
  SimplifiedDebt,
  SimplificationResult,
  Trip,
} from '../types';

export const CATEGORY_CONFIG: Record<
  ExpenseCategory,
  { color: string; bgTint: string; textClass: string; chartColor: string }
> = {
  Travel: {
    color: '#3478F6',
    bgTint: 'bg-[#3478F6]/10',
    textClass: 'text-[#1D5AD6]',
    chartColor: '#3478F6',
  },
  Food: {
    color: '#F5A623',
    bgTint: 'bg-[#F5A623]/12',
    textClass: 'text-[#B87409]',
    chartColor: '#F5A623',
  },
  Stay: {
    color: '#7047EB',
    bgTint: 'bg-[#7047EB]/10',
    textClass: 'text-[#5B34D6]',
    chartColor: '#7047EB',
  },
  Activities: {
    color: '#16A36A',
    bgTint: 'bg-[#16A36A]/10',
    textClass: 'text-[#118254]',
    chartColor: '#16A36A',
  },
  Shopping: {
    color: '#EC4899',
    bgTint: 'bg-[#EC4899]/10',
    textClass: 'text-[#C02674]',
    chartColor: '#EC4899',
  },
  Miscellaneous: {
    color: '#64748B',
    bgTint: 'bg-[#64748B]/10',
    textClass: 'text-[#475569]',
    chartColor: '#64748B',
  },
};

export const ALL_CATEGORIES: ExpenseCategory[] = [
  'Travel',
  'Food',
  'Stay',
  'Activities',
  'Shopping',
  'Miscellaneous',
];

export function toPaise(rupees: number): number {
  if (!Number.isFinite(rupees)) return 0;
  return Math.round(rupees * 100);
}

export function fromPaise(paise: number): number {
  return paise / 100;
}

export function formatINR(paise: number, options?: { forceDecimals?: boolean; compact?: boolean }): string {
  const absPaise = Math.abs(Math.round(paise));
  const rupees = absPaise / 100;
  const hasFraction = absPaise % 100 !== 0;

  if (options?.compact && rupees >= 100000) {
    const lakhs = rupees / 100000;
    return `${paise < 0 ? '-' : ''}₹${lakhs.toFixed(1)}L`;
  }

  const formatted = new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: options?.forceDecimals || hasFraction ? 2 : 0,
    maximumFractionDigits: options?.forceDecimals || hasFraction ? 2 : 0,
  }).format(rupees);

  return `${paise < 0 ? '-' : ''}₹${formatted}`;
}

export function formatDateShort(isoDate: string): string {
  if (!isoDate) return '';
  const [y, m, d] = isoDate.split('-').map(Number);
  const date = new Date(y, (m || 1) - 1, d || 1);
  return date.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function calculateEqualSplits(amountPaise: number, participantIds: string[]): ExpenseSplit[] {
  const uniqueIds = Array.from(new Set(participantIds.filter(Boolean)));
  const count = uniqueIds.length;
  if (count === 0 || !Number.isFinite(amountPaise) || amountPaise <= 0) return [];
  const total = Math.round(amountPaise);
  const base = Math.floor(total / count);
  const remainder = total % count;

  return uniqueIds.map((memberId, index) => ({
    memberId,
    amountPaise: base + (index < remainder ? 1 : 0),
  }));
}

export function validateExactSplits(
  amountPaise: number,
  splits: ExpenseSplit[]
): { valid: boolean; sumPaise: number; diffPaise: number } {
  const hasNegative = splits.some(
    (s) => !Number.isFinite(s.amountPaise) || s.amountPaise < 0
  );
  const sumPaise = splits.reduce((acc, s) => acc + Math.round(s.amountPaise || 0), 0);
  const targetPaise = Number.isFinite(amountPaise) ? Math.round(amountPaise) : 0;
  const diffPaise = targetPaise - sumPaise;
  return {
    valid: !hasNegative && diffPaise === 0 && targetPaise > 0,
    sumPaise,
    diffPaise,
  };
}

export function computeTripBalances(
  memberIds: string[],
  membersMap: Map<string, Member>,
  expenses: Expense[],
  paidSettlements: SettlementRecord[]
): MemberBalance[] {
  const ledgerMap = new Map<
    string,
    {
      totalPaidPaise: number;
      totalSharePaise: number;
      settledOutPaise: number;
      settledInPaise: number;
      paidExpenseCount: number;
      participatedExpenseCount: number;
    }
  >();

  for (const id of memberIds) {
    ledgerMap.set(id, {
      totalPaidPaise: 0,
      totalSharePaise: 0,
      settledOutPaise: 0,
      settledInPaise: 0,
      paidExpenseCount: 0,
      participatedExpenseCount: 0,
    });
  }

  // Ensure any historical payer/participant not currently in trip.memberIds is still accounted for
  const ensureMember = (id: string) => {
    if (!ledgerMap.has(id) && membersMap.has(id)) {
      ledgerMap.set(id, {
        totalPaidPaise: 0,
        totalSharePaise: 0,
        settledOutPaise: 0,
        settledInPaise: 0,
        paidExpenseCount: 0,
        participatedExpenseCount: 0,
      });
    }
    return ledgerMap.get(id);
  };

  for (const exp of expenses) {
    const payerEntry = ensureMember(exp.paidByMemberId);
    if (payerEntry) {
      payerEntry.totalPaidPaise += exp.amountPaise;
      payerEntry.paidExpenseCount += 1;
    }
    for (const split of exp.splits) {
      if (split.amountPaise <= 0) continue;
      const partEntry = ensureMember(split.memberId);
      if (partEntry) {
        partEntry.totalSharePaise += split.amountPaise;
        partEntry.participatedExpenseCount += 1;
      }
    }
  }

  for (const st of paidSettlements) {
    if (st.status !== 'paid') continue;
    const fromEntry = ensureMember(st.fromMemberId);
    const toEntry = ensureMember(st.toMemberId);
    if (fromEntry) fromEntry.settledOutPaise += st.amountPaise;
    if (toEntry) toEntry.settledInPaise += st.amountPaise;
  }

  const results: MemberBalance[] = [];
  for (const [memberId, data] of ledgerMap.entries()) {
    const member = membersMap.get(memberId);
    if (!member) continue;
    const rawNetPaise = data.totalPaidPaise - data.totalSharePaise;
    const netBalancePaise = rawNetPaise + data.settledOutPaise - data.settledInPaise;
    let status: 'owed' | 'owes' | 'settled' = 'settled';
    if (netBalancePaise > 0) status = 'owed';
    else if (netBalancePaise < 0) status = 'owes';

    results.push({
      memberId,
      member,
      totalPaidPaise: data.totalPaidPaise,
      totalSharePaise: data.totalSharePaise,
      settledOutPaise: data.settledOutPaise,
      settledInPaise: data.settledInPaise,
      rawNetPaise,
      netBalancePaise,
      status,
      paidExpenseCount: data.paidExpenseCount,
      participatedExpenseCount: data.participatedExpenseCount,
    });
  }

  return results.sort((a, b) => b.netBalancePaise - a.netBalancePaise);
}

/**
 * Greedy Cash-Flow Minimization Algorithm
 * Matches largest debtor with largest creditor iteratively until all net balances reach zero.
 */
export function runDebtSimplification(
  memberIds: string[],
  members: Member[],
  expenses: Expense[],
  settlements: SettlementRecord[]
): SimplificationResult {
  const membersMap = new Map(members.map((m) => [m.id, m]));
  const paidSettlements = settlements.filter((s) => s.status === 'paid');
  const balances = computeTripBalances(memberIds, membersMap, expenses, paidSettlements);

  // Compute unsimplified expense-level pairwise debt edges (before cash-flow minimization)
  let rawExpenseDebtEdges = 0;
  const pairMap = new Map<string, OriginalDebtEdge>();

  for (const exp of expenses) {
    for (const split of exp.splits) {
      if (split.memberId === exp.paidByMemberId || split.amountPaise <= 0) continue;
      rawExpenseDebtEdges += 1;
      const key = `${split.memberId}__${exp.paidByMemberId}`;
      const existing = pairMap.get(key);
      if (existing) {
        existing.amountPaise += split.amountPaise;
        existing.expenseCount += 1;
      } else {
        pairMap.set(key, {
          fromMemberId: split.memberId,
          toMemberId: exp.paidByMemberId,
          amountPaise: split.amountPaise,
          expenseCount: 1,
        });
      }
    }
  }

  const pairwiseDebts = Array.from(pairMap.values()).sort(
    (a, b) => b.amountPaise - a.amountPaise
  );

  // Separate remaining unpaid balances into Creditors (>0) and Debtors (<0)
  const creditors = balances
    .filter((b) => b.netBalancePaise > 0)
    .map((b) => ({ memberId: b.memberId, amount: b.netBalancePaise }))
    .sort((a, b) => b.amount - a.amount);

  const debtors = balances
    .filter((b) => b.netBalancePaise < 0)
    .map((b) => ({ memberId: b.memberId, amount: Math.abs(b.netBalancePaise) }))
    .sort((a, b) => b.amount - a.amount);

  const simplifiedTransactions: SimplifiedDebt[] = [];
  let totalSettlementVolumePaise = 0;

  while (creditors.length > 0 && debtors.length > 0) {
    creditors.sort((a, b) => b.amount - a.amount);
    debtors.sort((a, b) => b.amount - a.amount);

    const maxCreditor = creditors[0];
    const maxDebtor = debtors[0];

    const settleAmount = Math.min(maxCreditor.amount, maxDebtor.amount);
    if (settleAmount <= 0) break;

    simplifiedTransactions.push({
      id: `sim_${maxDebtor.memberId}_${maxCreditor.memberId}_${settleAmount}`,
      fromMemberId: maxDebtor.memberId,
      toMemberId: maxCreditor.memberId,
      amountPaise: settleAmount,
    });

    totalSettlementVolumePaise += settleAmount;
    maxCreditor.amount -= settleAmount;
    maxDebtor.amount -= settleAmount;

    if (maxCreditor.amount === 0) creditors.shift();
    if (maxDebtor.amount === 0) debtors.shift();
  }

  const baselineCount = Math.max(pairwiseDebts.length, rawExpenseDebtEdges);
  const reductionPercent =
    baselineCount > 0 && simplifiedTransactions.length <= baselineCount
      ? Math.round(((baselineCount - simplifiedTransactions.length) / baselineCount) * 100)
      : 0;

  return {
    balances,
    rawExpenseDebtEdges,
    pairwiseDebts,
    simplifiedTransactions,
    totalSettlementVolumePaise,
    reductionPercent,
  };
}

export function computeBudgetAlert(trip: Trip, spentPaise: number): BudgetAlertInfo {
  const budgetPaise = Math.max(1, trip.budgetPaise);
  const utilizationPercent = Math.round((spentPaise / budgetPaise) * 1000) / 10;
  const remainingPaise = trip.budgetPaise - spentPaise;

  if (spentPaise > trip.budgetPaise) {
    return {
      level: 'exceeded',
      utilizationPercent,
      spentPaise,
      budgetPaise: trip.budgetPaise,
      remainingPaise,
      title: `Budget Exceeded on ${trip.name}`,
      message: `Spending is ${formatINR(Math.abs(remainingPaise))} over the ${formatINR(trip.budgetPaise)} trip budget (${utilizationPercent.toFixed(1)}%).`,
    };
  }
  if (utilizationPercent >= 100) {
    return {
      level: 'limit100',
      utilizationPercent,
      spentPaise,
      budgetPaise: trip.budgetPaise,
      remainingPaise,
      title: `100% Budget Reached on ${trip.name}`,
      message: `Total expenses have hit the exact ${formatINR(trip.budgetPaise)} budget limit.`,
    };
  }
  if (utilizationPercent >= 90) {
    return {
      level: 'warning90',
      utilizationPercent,
      spentPaise,
      budgetPaise: trip.budgetPaise,
      remainingPaise,
      title: `High Budget Usage (${utilizationPercent.toFixed(1)}%)`,
      message: `${trip.name} has only ${formatINR(remainingPaise)} remaining out of ${formatINR(trip.budgetPaise)}.`,
    };
  }
  if (utilizationPercent >= 75) {
    return {
      level: 'warning75',
      utilizationPercent,
      spentPaise,
      budgetPaise: trip.budgetPaise,
      remainingPaise,
      title: `Budget Threshold Reached (${utilizationPercent.toFixed(1)}%)`,
      message: `${trip.name} has crossed 75% utilization with ${formatINR(remainingPaise)} left.`,
    };
  }

  return {
    level: 'nominal',
    utilizationPercent,
    spentPaise,
    budgetPaise: trip.budgetPaise,
    remainingPaise,
    title: 'Budget On Track',
    message: `${formatINR(remainingPaise)} remaining (${utilizationPercent.toFixed(1)}% used).`,
  };
}

export function generateUpiLink(params: {
  upiId: string;
  payeeName: string;
  amountPaise: number;
  tripName: string;
}): string {
  const amountRupees = (params.amountPaise / 100).toFixed(2);
  const query = new URLSearchParams({
    pa: params.upiId,
    pn: params.payeeName,
    am: amountRupees,
    cu: 'INR',
    tn: `TripTally ${params.tripName}`,
  });
  return `upi://pay?${query.toString()}`;
}

export function getInitials(name: string): string {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? '')
    .join('');
}

/**
 * Verifies the conservation-of-funds invariant across all trip member balances:
 * Sum of all net balances must strictly equal 0 paise.
 */
export function verifyZeroSumInvariant(balances: MemberBalance[]): {
  balanced: boolean;
  netSumPaise: number;
  totalPaidPaise: number;
  totalSharePaise: number;
} {
  const netSumPaise = balances.reduce((acc, b) => acc + b.netBalancePaise, 0);
  const totalPaidPaise = balances.reduce((acc, b) => acc + b.totalPaidPaise, 0);
  const totalSharePaise = balances.reduce((acc, b) => acc + b.totalSharePaise, 0);
  return {
    balanced: netSumPaise === 0,
    netSumPaise,
    totalPaidPaise,
    totalSharePaise,
  };
}

export function generateSettlementSummaryText(params: {
  tripName: string;
  destination: string;
  totalSpentPaise: number;
  transactions: SimplifiedDebt[];
  memberMap: Map<string, Member>;
}): string {
  const { tripName, destination, totalSpentPaise, transactions, memberMap } = params;
  const header = `TripTally Settlement Summary — ${tripName} (${destination})\nTotal Group Spend: ${formatINR(totalSpentPaise)}`;
  if (transactions.length === 0) {
    return `${header}\n\nAll balances are settled (₹0 pending).`;
  }
  const lines = transactions.map((tx, idx) => {
    const from = memberMap.get(tx.fromMemberId)?.name ?? tx.fromMemberId;
    const to = memberMap.get(tx.toMemberId);
    const upi = to?.upiId ? ` [${to.upiId}]` : '';
    return `${idx + 1}. ${from} pays ${to?.name ?? tx.toMemberId}: ${formatINR(tx.amountPaise)}${upi}`;
  });
  return `${header}\n\nOptimized Transfers (${transactions.length}):\n${lines.join('\n')}`;
}
