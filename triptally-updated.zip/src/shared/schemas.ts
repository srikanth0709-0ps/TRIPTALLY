import { z } from 'zod';

const ISO_DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;

const SafeDataImageUrlSchema = z
  .string()
  .max(6_000_000, 'Receipt image exceeds maximum allowed size')
  .refine((val) => {
    if (
      val.startsWith('data:image/png;base64,') ||
      val.startsWith('data:image/jpeg;base64,') ||
      val.startsWith('data:image/jpg;base64,') ||
      val.startsWith('data:image/webp;base64,')
    ) {
      return true;
    }
    if (val.startsWith('data:image/svg+xml')) {
      const lowered = decodeURIComponent(val).toLowerCase();
      return (
        !lowered.includes('<script') &&
        !lowered.includes('onload=') &&
        !lowered.includes('onerror=') &&
        !lowered.includes('javascript:')
      );
    }
    return false;
  }, 'Unsupported or unsafe receipt image format');

export const ExpenseCategorySchema = z.enum([
  'Travel',
  'Food',
  'Stay',
  'Activities',
  'Shopping',
  'Miscellaneous',
]);

export const SplitTypeSchema = z.enum(['equal', 'exact', 'subset']);

export const SettlementMethodSchema = z.enum(['upi', 'cash', 'bank']);

export const MemberSchema = z.object({
  id: z.string().trim().min(1).max(100),
  name: z.string().trim().min(1, 'Member name is required').max(120),
  email: z.string().trim().email('Valid email is required').max(160),
  upiId: z.string().trim().min(3).max(120),
  avatarColor: z.string().trim().regex(/^#[0-9A-Fa-f]{6}$/).default('#7047EB'),
  avatarUrl: z.string().trim().max(500).optional(),
});

export const TripSchema = z
  .object({
    id: z.string().trim().min(1).max(100),
    name: z.string().trim().min(1, 'Trip name is required').max(160),
    destination: z.string().trim().min(1, 'Destination is required').max(160),
    startDate: z.string().regex(ISO_DATE_REGEX, 'Start date must be YYYY-MM-DD'),
    endDate: z.string().regex(ISO_DATE_REGEX, 'End date must be YYYY-MM-DD'),
    budgetPaise: z.number().int().positive('Budget must be greater than zero').max(1_000_000_000),
    description: z.string().max(1000).default(''),
    coverImage: z.string().trim().min(1).max(500),
    status: z.enum(['active', 'archived']),
    memberIds: z.array(z.string().trim().min(1)).min(1, 'At least one trip member is required'),
    createdAt: z.string().min(1),
  })
  .refine((t) => t.endDate >= t.startDate, {
    message: 'End date must be on or after start date',
    path: ['endDate'],
  });

export const ExpenseSplitSchema = z.object({
  memberId: z.string().trim().min(1).max(100),
  amountPaise: z.number().int().nonnegative('Split amount cannot be negative'),
});

export const ReceiptAssetSchema = z.object({
  id: z.string().trim().min(1).max(100),
  name: z.string().trim().min(1).max(200),
  dataUrl: SafeDataImageUrlSchema,
  uploadedAt: z.string().min(1),
  sizeBytes: z.number().int().nonnegative().max(6_000_000),
});

export const ExpenseSchema = z
  .object({
    id: z.string().trim().min(1).max(100),
    tripId: z.string().trim().min(1).max(100),
    title: z.string().trim().min(1, 'Expense title is required').max(180),
    amountPaise: z.number().int().positive('Expense amount must be positive').max(1_000_000_000),
    category: ExpenseCategorySchema,
    date: z.string().regex(ISO_DATE_REGEX, 'Expense date must be YYYY-MM-DD'),
    paidByMemberId: z.string().trim().min(1).max(100),
    participantIds: z.array(z.string().trim().min(1)).min(1),
    splitType: SplitTypeSchema,
    splits: z.array(ExpenseSplitSchema).min(1),
    notes: z.string().max(1000).default(''),
    receipt: ReceiptAssetSchema.optional(),
    createdAt: z.string().min(1),
  })
  .refine(
    (e) => {
      const sum = e.splits.reduce((acc, s) => acc + s.amountPaise, 0);
      return sum === e.amountPaise;
    },
    {
      message: 'Sum of expense splits must exactly equal total amountPaise',
      path: ['splits'],
    }
  );

export const SettlementRecordSchema = z
  .object({
    id: z.string().trim().min(1).max(100),
    tripId: z.string().trim().min(1).max(100),
    fromMemberId: z.string().trim().min(1).max(100),
    toMemberId: z.string().trim().min(1).max(100),
    amountPaise: z.number().int().positive('Settlement amount must be positive').max(1_000_000_000),
    status: z.enum(['pending', 'paid']),
    paidAt: z.string().optional(),
    method: SettlementMethodSchema.optional(),
    note: z.string().max(500).optional(),
  })
  .refine((s) => s.fromMemberId !== s.toMemberId, {
    message: 'Payer and recipient cannot be the same member',
    path: ['toMemberId'],
  });

export const AppSettingsSchema = z.object({
  activeUserId: z.string().max(100),
  enable75Alert: z.boolean(),
  enable90Alert: z.boolean(),
  enable100Alert: z.boolean(),
  defaultSplitType: SplitTypeSchema,
});

export const TripTallyStateSchema = z
  .object({
    members: z.array(MemberSchema).min(1, 'At least one member is required'),
    trips: z.array(TripSchema),
    expenses: z.array(ExpenseSchema),
    settlements: z.array(SettlementRecordSchema),
    settings: AppSettingsSchema,
  })
  .superRefine((state, ctx) => {
    const memberIds = new Set(state.members.map((m) => m.id));
    const tripIds = new Set(state.trips.map((t) => t.id));

    state.trips.forEach((trip, idx) => {
      for (const mid of trip.memberIds) {
        if (!memberIds.has(mid)) {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: `Trip "${trip.name}" references unknown member "${mid}"`,
            path: ['trips', idx, 'memberIds'],
          });
        }
      }
    });

    state.expenses.forEach((exp, idx) => {
      if (!tripIds.has(exp.tripId)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Expense "${exp.title}" references unknown trip "${exp.tripId}"`,
          path: ['expenses', idx, 'tripId'],
        });
      }
      if (!memberIds.has(exp.paidByMemberId)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Expense "${exp.title}" payer "${exp.paidByMemberId}" does not exist`,
          path: ['expenses', idx, 'paidByMemberId'],
        });
      }
      for (const s of exp.splits) {
        if (!memberIds.has(s.memberId)) {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: `Expense "${exp.title}" split references unknown member "${s.memberId}"`,
            path: ['expenses', idx, 'splits'],
          });
        }
      }
    });

    state.settlements.forEach((st, idx) => {
      if (!tripIds.has(st.tripId)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Settlement "${st.id}" references unknown trip "${st.tripId}"`,
          path: ['settlements', idx, 'tripId'],
        });
      }
      if (!memberIds.has(st.fromMemberId) || !memberIds.has(st.toMemberId)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Settlement "${st.id}" references unknown member`,
          path: ['settlements', idx],
        });
      }
    });
  });

export const StatePutEnvelopeSchema = z.union([
  z.object({
    state: TripTallyStateSchema,
    expectedVersion: z.number().int().positive().optional(),
  }),
  TripTallyStateSchema,
]);
