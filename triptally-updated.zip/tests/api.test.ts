import request from 'supertest';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { createApiApp } from '../server/app';
import type { TripTallyDatabase } from '../server/db';
import { createInitialDemoState } from '../src/data/demoData';

describe('TripTally SQLite API & Validation Integration Tests', () => {
  let app: ReturnType<typeof createApiApp>['app'];
  let database: TripTallyDatabase;

  beforeEach(() => {
    const created = createApiApp(':memory:');
    app = created.app;
    database = created.database;
  });

  afterEach(() => {
    database.close();
  });

  it('reports SQLite WAL health and uninitialized initial state', async () => {
    const health = await request(app).get('/api/health');
    expect(health.status).toBe(200);
    expect(health.body).toMatchObject({
      status: 'ok',
      storage: 'sqlite-wal',
      initialized: false,
    });

    const stateRes = await request(app).get('/api/state');
    expect(stateRes.status).toBe(200);
    expect(stateRes.body.initialized).toBe(false);
    expect(stateRes.body.state).toBeNull();
  });

  it('persists valid demo state to normalized SQLite tables and increments version', async () => {
    const demo = createInitialDemoState();
    const put1 = await request(app).put('/api/state').send({ state: demo });
    expect(put1.status).toBe(200);
    expect(put1.body).toMatchObject({ ok: true, version: 1 });

    const getRes = await request(app).get('/api/state');
    expect(getRes.status).toBe(200);
    expect(getRes.body.initialized).toBe(true);
    expect(getRes.body.version).toBe(1);
    expect(getRes.body.state.trips).toHaveLength(2);
    expect(getRes.body.state.expenses).toHaveLength(12);

    const put2 = await request(app)
      .put('/api/state')
      .send({ state: demo, expectedVersion: 1 });
    expect(put2.status).toBe(200);
    expect(put2.body.version).toBe(2);
  });

  it('enforces optimistic concurrency control and returns 409 Conflict on stale versions', async () => {
    const demo = createInitialDemoState();
    await request(app).put('/api/state').send({ state: demo });
    await request(app).put('/api/state').send({ state: demo, expectedVersion: 1 });

    const staleWrite = await request(app)
      .put('/api/state')
      .send({ state: demo, expectedVersion: 1 });

    expect(staleWrite.status).toBe(409);
    expect(staleWrite.body.error.code).toBe('VERSION_CONFLICT');
    expect(staleWrite.body.error.details.currentVersion).toBe(2);
  });

  it('rejects malformed payloads, split mismatches, broken references, and unsafe SVG receipts with 400', async () => {
    const emptyObj = await request(app).put('/api/state').send({ random: true });
    expect(emptyObj.status).toBe(400);
    expect(emptyObj.body.error.code).toBe('VALIDATION_ERROR');

    // Split mismatch (splits sum to 1000 instead of 2000)
    const demo = createInitialDemoState();
    const badSplits = structuredClone(demo);
    badSplits.expenses[0].amountPaise = 999999;
    const splitRes = await request(app).put('/api/state').send({ state: badSplits });
    expect(splitRes.status).toBe(400);

    // Unsafe SVG script injection
    const xssState = structuredClone(demo);
    xssState.expenses[0].receipt = {
      id: 'rcpt_xss',
      name: 'evil.svg',
      dataUrl: 'data:image/svg+xml;utf8,<svg><script>alert(1)</script></svg>',
      uploadedAt: '2026-11-12T10:00:00Z',
      sizeBytes: 120,
    };
    const xssRes = await request(app).put('/api/state').send({ state: xssState });
    expect(xssRes.status).toBe(400);

    // Broken foreign key reference
    const badFk = structuredClone(demo);
    badFk.expenses[0].paidByMemberId = 'mem_nonexistent';
    const fkRes = await request(app).put('/api/state').send({ state: badFk });
    expect(fkRes.status).toBe(400);
  });

  it('supports atomic granular expense creation, deletion, and structured 404 errors', async () => {
    const demo = createInitialDemoState();
    await request(app).put('/api/state').send({ state: demo });

    const newExp = {
      id: 'exp_test_atomic',
      tripId: 'trip_goa_2026',
      title: 'Airport Cab',
      amountPaise: 120000,
      category: 'Travel',
      date: '2026-11-16',
      paidByMemberId: 'mem_rahul',
      participantIds: ['mem_rahul', 'mem_priya'],
      splitType: 'subset',
      splits: [
        { memberId: 'mem_rahul', amountPaise: 60000 },
        { memberId: 'mem_priya', amountPaise: 60000 },
      ],
      notes: 'Return airport drop',
      createdAt: '2026-11-16T18:00:00Z',
    };

    const createRes = await request(app).post('/api/expenses').send(newExp);
    expect(createRes.status).toBe(201);
    expect(createRes.body.version).toBe(2);

    const delRes = await request(app).delete('/api/expenses/exp_test_atomic');
    expect(delRes.status).toBe(200);
    expect(delRes.body.version).toBe(3);

    const missingTrip = await request(app).get('/api/trips/does_not_exist');
    expect(missingTrip.status).toBe(404);
    expect(missingTrip.body.error.code).toBe('NOT_FOUND');
  });
});
