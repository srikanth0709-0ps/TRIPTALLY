import { describe, expect, it } from 'vitest';
import { createInitialDemoState } from '../src/data/demoData';
import type { Expense, Member, SettlementRecord, Trip } from '../src/types';
import {
  calculateEqualSplits,
  computeBudgetAlert,
  formatINR,
  fromPaise,
  generateUpiLink,
  runDebtSimplification,
  toPaise,
  validateExactSplits,
  verifyZeroSumInvariant,
} from '../src/utils/finance';

const SAMPLE_MEMBERS: Member[] = [
  { id: 'rahul', name: 'Rahul', email: 'rahul@test.com', upiId: 'rahul@okaxis', avatarColor: '#3478F6' },
  { id: 'priya', name: 'Priya', email: 'priya@test.com', upiId: 'priya@okicici', avatarColor: '#7047EB' },
  { id: 'amit', name: 'Amit', email: 'amit@test.com', upiId: 'amit@okhdfc', avatarColor: '#16A36A' },
  { id: 'sneha', name: 'Sneha', email: 'sneha@test.com', upiId: 'sneha@oksbi', avatarColor: '#F5A623' },
];

describe('Integer Paise & Currency Formatting', () => {
  it('converts rupees to integer paise without floating point drift', () => {
    expect(toPaise(19.99)).toBe(1999);
    expect(toPaise(0.1 + 0.2)).toBe(30);
    expect(toPaise(Number.NaN)).toBe(0);
    expect(fromPaise(12345)).toBe(123.45);
  });

  it('formats INR with Indian numbering grouping', () => {
    expect(formatINR(1500000)).toBe('₹15,000');
    expect(formatINR(12500000)).toBe('₹1,25,000');
    expect(formatINR(-45050)).toBe('-₹450.50');
  });
});

describe('Flexible Expense Splitting', () => {
  it('distributes remainder paise deterministically so sum strictly equals total', () => {
    const splits = calculateEqualSplits(1000, ['rahul', 'priya', 'amit']); // ₹10 / 3
    expect(splits).toEqual([
      { memberId: 'rahul', amountPaise: 334 },
      { memberId: 'priya', amountPaise: 333 },
      { memberId: 'amit', amountPaise: 333 },
    ]);
    const total = splits.reduce((s, item) => s + item.amountPaise, 0);
    expect(total).toBe(1000);
  });

  it('handles zero-amount, negative, empty, and duplicate participant edge cases', () => {
    expect(calculateEqualSplits(0, ['rahul', 'priya'])).toEqual([]);
    expect(calculateEqualSplits(-500, ['rahul', 'priya'])).toEqual([]);
    expect(calculateEqualSplits(500, [])).toEqual([]);
    expect(calculateEqualSplits(1000, ['rahul', 'rahul', 'priya'])).toEqual([
      { memberId: 'rahul', amountPaise: 500 },
      { memberId: 'priya', amountPaise: 500 },
    ]);
  });

  it('validates exact amount splits and rejects negative or mismatched sums', () => {
    expect(
      validateExactSplits(120000, [
        { memberId: 'rahul', amountPaise: 40000 },
        { memberId: 'priya', amountPaise: 30000 },
        { memberId: 'sneha', amountPaise: 50000 },
      ])
    ).toEqual({ valid: true, sumPaise: 120000, diffPaise: 0 });

    expect(
      validateExactSplits(120000, [
        { memberId: 'rahul', amountPaise: 40000 },
        { memberId: 'priya', amountPaise: 30000 },
      ]).valid
    ).toBe(false);

    expect(
      validateExactSplits(1000, [
        { memberId: 'rahul', amountPaise: 1500 },
        { memberId: 'priya', amountPaise: -500 },
      ]).valid
    ).toBe(false);
  });
});

describe('Greedy Cash-Flow Minimization Engine', () => {
  it('minimizes canonical multi-payer example into 2 optimal settlements', () => {
    // Rahul pays ₹4,000, Priya pays ₹6,000, Amit pays ₹2,000; Sneha participates equally (Total ₹12,000 -> ₹3,000 each)
    const expenses: Expense[] = [
      {
        id: 'e1',
        tripId: 't1',
        title: 'Fuel',
        amountPaise: 400000,
        category: 'Travel',
        date: '2026-11-12',
        paidByMemberId: 'rahul',
        participantIds: ['rahul', 'priya', 'amit', 'sneha'],
        splitType: 'equal',
        splits: calculateEqualSplits(400000, ['rahul', 'priya', 'amit', 'sneha']),
        notes: '',
        createdAt: '2026-11-12T10:00:00Z',
      },
      {
        id: 'e2',
        tripId: 't1',
        title: 'Hotel',
        amountPaise: 600000,
        category: 'Stay',
        date: '2026-11-12',
        paidByMemberId: 'priya',
        participantIds: ['rahul', 'priya', 'amit', 'sneha'],
        splitType: 'equal',
        splits: calculateEqualSplits(600000, ['rahul', 'priya', 'amit', 'sneha']),
        notes: '',
        createdAt: '2026-11-12T11:00:00Z',
      },
      {
        id: 'e3',
        tripId: 't1',
        title: 'Food',
        amountPaise: 200000,
        category: 'Food',
        date: '2026-11-12',
        paidByMemberId: 'amit',
        participantIds: ['rahul', 'priya', 'amit', 'sneha'],
        splitType: 'equal',
        splits: calculateEqualSplits(200000, ['rahul', 'priya', 'amit', 'sneha']),
        notes: '',
        createdAt: '2026-11-12T12:00:00Z',
      },
    ];

    const result = runDebtSimplification(
      ['rahul', 'priya', 'amit', 'sneha'],
      SAMPLE_MEMBERS,
      expenses,
      []
    );

    expect(result.simplifiedTransactions).toHaveLength(2);
    expect(result.simplifiedTransactions).toEqual([
      {
        id: 'sim_sneha_priya_300000',
        fromMemberId: 'sneha',
        toMemberId: 'priya',
        amountPaise: 300000,
      },
      {
        id: 'sim_amit_rahul_100000',
        fromMemberId: 'amit',
        toMemberId: 'rahul',
        amountPaise: 100000,
      },
    ]);
    expect(verifyZeroSumInvariant(result.balances).balanced).toBe(true);
  });

  it('maintains zero-sum conservation and reduces pending debt after recorded settlement', () => {
    const demo = createInitialDemoState();
    const goaTrip = demo.trips.find((t) => t.id === 'trip_goa_2026')!;
    const goaExpenses = demo.expenses.filter((e) => e.tripId === goaTrip.id);

    const before = runDebtSimplification(
      goaTrip.memberIds,
      demo.members,
      goaExpenses,
      []
    );
    expect(verifyZeroSumInvariant(before.balances)).toMatchObject({
      balanced: true,
      netSumPaise: 0,
      totalPaidPaise: 2340000,
      totalSharePaise: 2340000,
    });
    expect(before.simplifiedTransactions.length).toBeGreaterThan(0);

    // Apply all simplified transactions as paid settlements
    const paidSettlements: SettlementRecord[] = before.simplifiedTransactions.map((tx, i) => ({
      id: `stl_${i}`,
      tripId: goaTrip.id,
      fromMemberId: tx.fromMemberId,
      toMemberId: tx.toMemberId,
      amountPaise: tx.amountPaise,
      status: 'paid',
      method: 'upi',
      paidAt: '2026-11-16T18:00:00Z',
    }));

    const after = runDebtSimplification(
      goaTrip.memberIds,
      demo.members,
      goaExpenses,
      paidSettlements
    );
    expect(after.simplifiedTransactions).toHaveLength(0);
    expect(after.totalSettlementVolumePaise).toBe(0);
    expect(verifyZeroSumInvariant(after.balances).balanced).toBe(true);
  });
});

describe('Smart Budget Alerts & UPI Links', () => {
  const trip: Trip = {
    id: 't1',
    name: 'Test Trip',
    destination: 'Goa',
    startDate: '2026-11-10',
    endDate: '2026-11-15',
    budgetPaise: 1000000, // ₹10,000
    description: '',
    coverImage: 'cover.jpg',
    status: 'active',
    memberIds: ['rahul'],
    createdAt: '2026-11-01T00:00:00Z',
  };

  it('triggers 75%, 90%, 100%, and exceeded budget alert tiers accurately', () => {
    expect(computeBudgetAlert(trip, 500000).level).toBe('nominal');
    expect(computeBudgetAlert(trip, 750000).level).toBe('warning75');
    expect(computeBudgetAlert(trip, 900000).level).toBe('warning90');
    expect(computeBudgetAlert(trip, 1000000).level).toBe('limit100');
    expect(computeBudgetAlert(trip, 1125000).level).toBe('exceeded');
  });

  it('generates valid UPI deep link with exact rupee amount', () => {
    const link = generateUpiLink({
      upiId: 'priya.nair@okicici',
      payeeName: 'Priya Nair',
      amountPaise: 65050,
      tripName: 'Goa Road Trip 2026',
    });
    expect(link.startsWith('upi://pay?')).toBe(true);
    expect(link).toContain('pa=priya.nair%40okicici');
    expect(link).toContain('am=650.50');
    expect(link).toContain('cu=INR');
  });
});
