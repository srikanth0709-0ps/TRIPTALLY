# TripTally – SplitTheTrip

> Travel Together. Split Smarter. Settle Faster.

A full-stack group travel expense management, flexible bill-splitting, and debt-simplification application built with React, TypeScript, Tailwind CSS, Chart.js, Express, Zod, and SQLite.

## Architecture & Engineering Highlights

- **Relational SQLite Persistence (`server/db.ts`)**: Normalized schema (`members`, `trips`, `trip_members`, `expenses`, `expense_splits`, `settlements`, `app_settings`, `state_meta`) running in `WAL` journal mode with `FOREIGN KEY` enforcement, `busy_timeout = 5000`, parameterized prepared statements, and `BEGIN IMMEDIATE` atomic transactions.
- **Optimistic Concurrency Control**: Every state mutation increments `state_meta.version`. `PUT /api/state` verifies `expectedVersion` and returns `409 Conflict` on stale concurrent writes so client sessions stay synchronized.
- **Strict Runtime Input Validation (`src/shared/schemas.ts`)**: Zod schemas validate every payload on the server, enforcing positive integer paise bounds, ISO date ordering (`endDate >= startDate`), split sum invariants (`sum(splits) === amountPaise`), referential integrity across foreign keys, and safe receipt image formats.
- **Integer Paise Arithmetic & Greedy Cash-Flow Minimization (`src/utils/finance.ts`)**: All financial math executes in integer paise (`1 INR = 100 paise`) with deterministic remainder allocation and a zero-sum conservation verifier (`verifyZeroSumInvariant`).
- **Interactive Visualization & Reporting**: Includes Chart.js analytics, an interactive Before/After SVG Cash-Flow Network Graph (`CashFlowGraph.tsx`), UPI deep links with explicit manual verification, CSV export, and audit-ready PDF financial statements (`jsPDF`).

## Scripts

```bash
npm run dev      # Start Express + Vite dev server on port 3000
npm test         # Run automated unit & API integration tests (Vitest + Supertest)
npm run lint     # Run TypeScript type check (tsc --noEmit)
npm run build    # Build production frontend bundle
```
