import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  ExpenseSchema,
  StatePutEnvelopeSchema,
} from '../src/shared/schemas.ts';
import type { TripTallyState } from '../src/types/index.ts';
import { TripTallyDatabase } from './db.ts';
import { AppError, NotFoundError, ValidationError } from './errors.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DEFAULT_DB_PATH = path.resolve(__dirname, '..', '.data', 'triptally.sqlite');
const ARCHIVE_PATH = path.resolve(__dirname, '..', 'triptally-updated.zip');

export function createApiApp(dbFilePath: string = DEFAULT_DB_PATH): {
  app: express.Express;
  database: TripTallyDatabase;
} {
  const database = new TripTallyDatabase(dbFilePath);
  const app = express();

  app.disable('x-powered-by');
  app.use(express.json({ limit: '10mb' }));

  // Baseline security headers
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('X-XSS-Protection', '0');
    next();
  });

  app.get('/api/health', (_req, res) => {
    const snapshot = database.getSnapshot();
    res.json({
      status: 'ok',
      service: 'TripTally API',
      storage: 'sqlite-wal',
      initialized: snapshot.initialized,
      version: snapshot.version,
    });
  });

  app.get('/api/state', (_req, res, next) => {
    try {
      const snapshot = database.getSnapshot();
      res.status(200).json(snapshot);
    } catch (err) {
      next(err);
    }
  });

  app.put('/api/state', (req, res, next) => {
    try {
      const parsed = StatePutEnvelopeSchema.safeParse(req.body);
      if (!parsed.success) {
        throw new ValidationError(
          'Invalid TripTally state payload',
          parsed.error.issues.map((issue) => ({
            path: issue.path.join('.'),
            message: issue.message,
          }))
        );
      }

      let nextState: TripTallyState;
      let expectedVersion: number | undefined;

      if ('state' in parsed.data) {
        nextState = parsed.data.state;
        expectedVersion = parsed.data.expectedVersion;
      } else {
        nextState = parsed.data;
      }

      const result = database.replaceState(nextState, expectedVersion);
      res.status(200).json({
        ok: true,
        version: result.version,
        updatedAt: result.updatedAt,
      });
    } catch (err) {
      next(err);
    }
  });

  app.delete('/api/state', (_req, res, next) => {
    try {
      database.clearState();
      res.status(200).json({ ok: true });
    } catch (err) {
      next(err);
    }
  });

  // Granular REST endpoints for direct API integrations & automated testing
  app.get('/api/trips', (_req, res, next) => {
    try {
      const snapshot = database.getSnapshot();
      res.status(200).json({ trips: snapshot.state?.trips ?? [] });
    } catch (err) {
      next(err);
    }
  });

  app.get('/api/trips/:id', (req, res, next) => {
    try {
      const snapshot = database.getSnapshot();
      const trip = snapshot.state?.trips.find((t) => t.id === req.params.id);
      if (!trip) {
        throw new NotFoundError(`Trip "${req.params.id}" not found`);
      }
      res.status(200).json({ trip });
    } catch (err) {
      next(err);
    }
  });

  app.post('/api/expenses', (req, res, next) => {
    try {
      const parsed = ExpenseSchema.safeParse(req.body);
      if (!parsed.success) {
        throw new ValidationError(
          'Invalid expense payload',
          parsed.error.issues.map((issue) => ({
            path: issue.path.join('.'),
            message: issue.message,
          }))
        );
      }
      const result = database.addExpenseAtomic(parsed.data);
      res.status(201).json({
        ok: true,
        expense: parsed.data,
        version: result.version,
      });
    } catch (err) {
      next(err);
    }
  });

  app.delete('/api/expenses/:id', (req, res, next) => {
    try {
      const result = database.deleteExpenseAtomic(req.params.id);
      res.status(200).json({ ok: true, version: result.version });
    } catch (err) {
      next(err);
    }
  });

  app.get('/api/download-zip', (_req, res, next) => {
    try {
      if (!fs.existsSync(ARCHIVE_PATH)) {
        throw new NotFoundError('Updated project zip archive has not been generated yet');
      }
      res.download(ARCHIVE_PATH, 'triptally-updated.zip');
    } catch (err) {
      next(err);
    }
  });

  // Malformed JSON syntax error handler
  app.use((err: unknown, _req: Request, _res: Response, next: NextFunction) => {
    if (err instanceof SyntaxError && 'body' in err) {
      next(new ValidationError('Malformed JSON request body'));
      return;
    }
    next(err);
  });

  // Centralized structured error middleware
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof AppError) {
      res.status(err.statusCode).json({
        error: {
          code: err.code,
          message: err.message,
          ...(err.details !== undefined ? { details: err.details } : {}),
        },
      });
      return;
    }

    const message = err instanceof Error ? err.message : 'Unexpected server error';
    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message,
      },
    });
  });

  return { app, database };
}
