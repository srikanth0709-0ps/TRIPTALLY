import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import type {
  AppSettings,
  Expense,
  ExpenseCategory,
  ExpenseSplit,
  Member,
  ReceiptAsset,
  SettlementMethod,
  SettlementRecord,
  SplitType,
  Trip,
  TripTallyState,
} from '../src/types/index.ts';
import { ConflictError, DatabaseError, NotFoundError } from './errors.ts';

export interface PersistedSnapshot {
  initialized: boolean;
  version: number;
  updatedAt: string | null;
  state: TripTallyState | null;
}

export class TripTallyDatabase {
  public readonly db: Database.Database;

  constructor(dbFilePath: string) {
    if (dbFilePath !== ':memory:') {
      const dir = path.dirname(dbFilePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }

    this.db = new Database(dbFilePath);
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('foreign_keys = ON');
    this.db.pragma('busy_timeout = 5000');
    this.initSchema();
  }

  private initSchema(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS state_meta (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        initialized INTEGER NOT NULL DEFAULT 0,
        version INTEGER NOT NULL DEFAULT 1,
        updated_at TEXT NOT NULL
      );

      INSERT OR IGNORE INTO state_meta (id, initialized, version, updated_at)
      VALUES (1, 0, 1, datetime('now'));

      CREATE TABLE IF NOT EXISTS members (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        upi_id TEXT NOT NULL,
        avatar_color TEXT NOT NULL,
        avatar_url TEXT
      );

      CREATE TABLE IF NOT EXISTS trips (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        destination TEXT NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        budget_paise INTEGER NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        cover_image TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('active', 'archived')),
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS trip_members (
        trip_id TEXT NOT NULL,
        member_id TEXT NOT NULL,
        PRIMARY KEY (trip_id, member_id),
        FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE,
        FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS expenses (
        id TEXT PRIMARY KEY,
        trip_id TEXT NOT NULL,
        title TEXT NOT NULL,
        amount_paise INTEGER NOT NULL,
        category TEXT NOT NULL,
        date TEXT NOT NULL,
        paid_by_member_id TEXT NOT NULL,
        split_type TEXT NOT NULL CHECK (split_type IN ('equal', 'exact', 'subset')),
        notes TEXT NOT NULL DEFAULT '',
        receipt_json TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE,
        FOREIGN KEY (paid_by_member_id) REFERENCES members(id) ON DELETE RESTRICT
      );

      CREATE TABLE IF NOT EXISTS expense_splits (
        expense_id TEXT NOT NULL,
        member_id TEXT NOT NULL,
        amount_paise INTEGER NOT NULL,
        PRIMARY KEY (expense_id, member_id),
        FOREIGN KEY (expense_id) REFERENCES expenses(id) ON DELETE CASCADE,
        FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE RESTRICT
      );

      CREATE TABLE IF NOT EXISTS settlements (
        id TEXT PRIMARY KEY,
        trip_id TEXT NOT NULL,
        from_member_id TEXT NOT NULL,
        to_member_id TEXT NOT NULL,
        amount_paise INTEGER NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('pending', 'paid')),
        paid_at TEXT,
        method TEXT,
        note TEXT,
        FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE,
        FOREIGN KEY (from_member_id) REFERENCES members(id) ON DELETE RESTRICT,
        FOREIGN KEY (to_member_id) REFERENCES members(id) ON DELETE RESTRICT
      );

      CREATE TABLE IF NOT EXISTS app_settings (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        active_user_id TEXT NOT NULL,
        enable_75_alert INTEGER NOT NULL DEFAULT 1,
        enable_90_alert INTEGER NOT NULL DEFAULT 1,
        enable_100_alert INTEGER NOT NULL DEFAULT 1,
        default_split_type TEXT NOT NULL DEFAULT 'equal'
      );

      CREATE INDEX IF NOT EXISTS idx_expenses_trip_date ON expenses(trip_id, date DESC);
      CREATE INDEX IF NOT EXISTS idx_settlements_trip ON settlements(trip_id);
      CREATE INDEX IF NOT EXISTS idx_trip_members_member ON trip_members(member_id);
    `);
  }

  public getSnapshot(): PersistedSnapshot {
    try {
      const meta = this.db
        .prepare('SELECT initialized, version, updated_at FROM state_meta WHERE id = 1')
        .get() as { initialized: number; version: number; updated_at: string } | undefined;

      if (!meta || meta.initialized === 0) {
        return {
          initialized: false,
          version: meta?.version ?? 1,
          updatedAt: meta?.updated_at ?? null,
          state: null,
        };
      }

      const memberRows = this.db
        .prepare(
          'SELECT id, name, email, upi_id, avatar_color, avatar_url FROM members ORDER BY rowid ASC'
        )
        .all() as Array<{
        id: string;
        name: string;
        email: string;
        upi_id: string;
        avatar_color: string;
        avatar_url: string | null;
      }>;

      const members: Member[] = memberRows.map((r) => ({
        id: r.id,
        name: r.name,
        email: r.email,
        upiId: r.upi_id,
        avatarColor: r.avatar_color,
        ...(r.avatar_url ? { avatarUrl: r.avatar_url } : {}),
      }));

      const tripMemberRows = this.db
        .prepare('SELECT trip_id, member_id FROM trip_members ORDER BY rowid ASC')
        .all() as Array<{ trip_id: string; member_id: string }>;

      const tripMembersByTrip = new Map<string, string[]>();
      for (const row of tripMemberRows) {
        const list = tripMembersByTrip.get(row.trip_id) ?? [];
        list.push(row.member_id);
        tripMembersByTrip.set(row.trip_id, list);
      }

      const tripRows = this.db
        .prepare(
          'SELECT id, name, destination, start_date, end_date, budget_paise, description, cover_image, status, created_at FROM trips ORDER BY created_at DESC'
        )
        .all() as Array<{
        id: string;
        name: string;
        destination: string;
        start_date: string;
        end_date: string;
        budget_paise: number;
        description: string;
        cover_image: string;
        status: 'active' | 'archived';
        created_at: string;
      }>;

      const trips: Trip[] = tripRows.map((t) => ({
        id: t.id,
        name: t.name,
        destination: t.destination,
        startDate: t.start_date,
        endDate: t.end_date,
        budgetPaise: t.budget_paise,
        description: t.description,
        coverImage: t.cover_image,
        status: t.status,
        memberIds: tripMembersByTrip.get(t.id) ?? [],
        createdAt: t.created_at,
      }));

      const splitRows = this.db
        .prepare('SELECT expense_id, member_id, amount_paise FROM expense_splits ORDER BY rowid ASC')
        .all() as Array<{ expense_id: string; member_id: string; amount_paise: number }>;

      const splitsByExpense = new Map<string, ExpenseSplit[]>();
      for (const s of splitRows) {
        const list = splitsByExpense.get(s.expense_id) ?? [];
        list.push({ memberId: s.member_id, amountPaise: s.amount_paise });
        splitsByExpense.set(s.expense_id, list);
      }

      const expenseRows = this.db
        .prepare(
          'SELECT id, trip_id, title, amount_paise, category, date, paid_by_member_id, split_type, notes, receipt_json, created_at FROM expenses ORDER BY date DESC, created_at DESC'
        )
        .all() as Array<{
        id: string;
        trip_id: string;
        title: string;
        amount_paise: number;
        category: ExpenseCategory;
        date: string;
        paid_by_member_id: string;
        split_type: SplitType;
        notes: string;
        receipt_json: string | null;
        created_at: string;
      }>;

      const expenses: Expense[] = expenseRows.map((e) => {
        const splits = splitsByExpense.get(e.id) ?? [];
        let receipt: ReceiptAsset | undefined;
        if (e.receipt_json) {
          try {
            receipt = JSON.parse(e.receipt_json) as ReceiptAsset;
          } catch {
            receipt = undefined;
          }
        }
        return {
          id: e.id,
          tripId: e.trip_id,
          title: e.title,
          amountPaise: e.amount_paise,
          category: e.category,
          date: e.date,
          paidByMemberId: e.paid_by_member_id,
          participantIds: splits.map((s) => s.memberId),
          splitType: e.split_type,
          splits,
          notes: e.notes,
          ...(receipt ? { receipt } : {}),
          createdAt: e.created_at,
        };
      });

      const settlementRows = this.db
        .prepare(
          'SELECT id, trip_id, from_member_id, to_member_id, amount_paise, status, paid_at, method, note FROM settlements ORDER BY rowid DESC'
        )
        .all() as Array<{
        id: string;
        trip_id: string;
        from_member_id: string;
        to_member_id: string;
        amount_paise: number;
        status: 'pending' | 'paid';
        paid_at: string | null;
        method: SettlementMethod | null;
        note: string | null;
      }>;

      const settlements: SettlementRecord[] = settlementRows.map((s) => ({
        id: s.id,
        tripId: s.trip_id,
        fromMemberId: s.from_member_id,
        toMemberId: s.to_member_id,
        amountPaise: s.amount_paise,
        status: s.status,
        ...(s.paid_at ? { paidAt: s.paid_at } : {}),
        ...(s.method ? { method: s.method } : {}),
        ...(s.note ? { note: s.note } : {}),
      }));

      const settingsRow = this.db
        .prepare(
          'SELECT active_user_id, enable_75_alert, enable_90_alert, enable_100_alert, default_split_type FROM app_settings WHERE id = 1'
        )
        .get() as
        | {
            active_user_id: string;
            enable_75_alert: number;
            enable_90_alert: number;
            enable_100_alert: number;
            default_split_type: SplitType;
          }
        | undefined;

      const settings: AppSettings = settingsRow
        ? {
            activeUserId: settingsRow.active_user_id,
            enable75Alert: Boolean(settingsRow.enable_75_alert),
            enable90Alert: Boolean(settingsRow.enable_90_alert),
            enable100Alert: Boolean(settingsRow.enable_100_alert),
            defaultSplitType: settingsRow.default_split_type,
          }
        : {
            activeUserId: members[0]?.id ?? '',
            enable75Alert: true,
            enable90Alert: true,
            enable100Alert: true,
            defaultSplitType: 'equal',
          };

      return {
        initialized: true,
        version: meta.version,
        updatedAt: meta.updated_at,
        state: { members, trips, expenses, settlements, settings },
      };
    } catch (err) {
      throw new DatabaseError('Failed to read TripTally SQLite snapshot', {
        cause: err instanceof Error ? err.message : String(err),
      });
    }
  }

  public replaceState(
    state: TripTallyState,
    expectedVersion?: number
  ): { version: number; updatedAt: string } {
    const runTx = this.db.transaction(() => {
      const meta = this.db
        .prepare('SELECT initialized, version FROM state_meta WHERE id = 1')
        .get() as { initialized: number; version: number };

      if (
        expectedVersion !== undefined &&
        meta.initialized === 1 &&
        meta.version !== expectedVersion
      ) {
        throw new ConflictError(
          `State version conflict: expected ${expectedVersion}, but server is at ${meta.version}.`,
          meta.version
        );
      }

      // Clear child tables first to satisfy foreign key constraints
      this.db.prepare('DELETE FROM expense_splits').run();
      this.db.prepare('DELETE FROM expenses').run();
      this.db.prepare('DELETE FROM settlements').run();
      this.db.prepare('DELETE FROM trip_members').run();
      this.db.prepare('DELETE FROM trips').run();
      this.db.prepare('DELETE FROM members').run();
      this.db.prepare('DELETE FROM app_settings').run();

      const insertMember = this.db.prepare(
        'INSERT INTO members (id, name, email, upi_id, avatar_color, avatar_url) VALUES (?, ?, ?, ?, ?, ?)'
      );
      for (const m of state.members) {
        insertMember.run(
          m.id,
          m.name,
          m.email,
          m.upiId,
          m.avatarColor,
          m.avatarUrl ?? null
        );
      }

      const insertTrip = this.db.prepare(
        'INSERT INTO trips (id, name, destination, start_date, end_date, budget_paise, description, cover_image, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
      );
      const insertTripMember = this.db.prepare(
        'INSERT OR IGNORE INTO trip_members (trip_id, member_id) VALUES (?, ?)'
      );
      for (const t of state.trips) {
        insertTrip.run(
          t.id,
          t.name,
          t.destination,
          t.startDate,
          t.endDate,
          t.budgetPaise,
          t.description,
          t.coverImage,
          t.status,
          t.createdAt
        );
        for (const mid of t.memberIds) {
          insertTripMember.run(t.id, mid);
        }
      }

      const insertExpense = this.db.prepare(
        'INSERT INTO expenses (id, trip_id, title, amount_paise, category, date, paid_by_member_id, split_type, notes, receipt_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
      );
      const insertSplit = this.db.prepare(
        'INSERT INTO expense_splits (expense_id, member_id, amount_paise) VALUES (?, ?, ?)'
      );
      for (const e of state.expenses) {
        insertExpense.run(
          e.id,
          e.tripId,
          e.title,
          e.amountPaise,
          e.category,
          e.date,
          e.paidByMemberId,
          e.splitType,
          e.notes,
          e.receipt ? JSON.stringify(e.receipt) : null,
          e.createdAt
        );
        for (const s of e.splits) {
          insertSplit.run(e.id, s.memberId, s.amountPaise);
        }
      }

      const insertSettlement = this.db.prepare(
        'INSERT INTO settlements (id, trip_id, from_member_id, to_member_id, amount_paise, status, paid_at, method, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
      );
      for (const st of state.settlements) {
        insertSettlement.run(
          st.id,
          st.tripId,
          st.fromMemberId,
          st.toMemberId,
          st.amountPaise,
          st.status,
          st.paidAt ?? null,
          st.method ?? null,
          st.note ?? null
        );
      }

      this.db
        .prepare(
          'INSERT INTO app_settings (id, active_user_id, enable_75_alert, enable_90_alert, enable_100_alert, default_split_type) VALUES (1, ?, ?, ?, ?, ?)'
        )
        .run(
          state.settings.activeUserId,
          state.settings.enable75Alert ? 1 : 0,
          state.settings.enable90Alert ? 1 : 0,
          state.settings.enable100Alert ? 1 : 0,
          state.settings.defaultSplitType
        );

      const nextVersion = meta.initialized === 1 ? meta.version + 1 : 1;
      const updatedAt = new Date().toISOString();
      this.db
        .prepare(
          'UPDATE state_meta SET initialized = 1, version = ?, updated_at = ? WHERE id = 1'
        )
        .run(nextVersion, updatedAt);

      return { version: nextVersion, updatedAt };
    });

    try {
      return runTx.immediate();
    } catch (err) {
      if (err instanceof ConflictError) throw err;
      throw new DatabaseError('Failed to persist TripTally state atomically', {
        cause: err instanceof Error ? err.message : String(err),
      });
    }
  }

  public addExpenseAtomic(expense: Expense): { version: number } {
    const tx = this.db.transaction(() => {
      const tripExists = this.db
        .prepare('SELECT 1 FROM trips WHERE id = ?')
        .get(expense.tripId);
      if (!tripExists) {
        throw new NotFoundError(`Trip "${expense.tripId}" does not exist`);
      }

      const payerExists = this.db
        .prepare('SELECT 1 FROM members WHERE id = ?')
        .get(expense.paidByMemberId);
      if (!payerExists) {
        throw new NotFoundError(`Member "${expense.paidByMemberId}" does not exist`);
      }

      this.db
        .prepare(
          'INSERT INTO expenses (id, trip_id, title, amount_paise, category, date, paid_by_member_id, split_type, notes, receipt_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )
        .run(
          expense.id,
          expense.tripId,
          expense.title,
          expense.amountPaise,
          expense.category,
          expense.date,
          expense.paidByMemberId,
          expense.splitType,
          expense.notes,
          expense.receipt ? JSON.stringify(expense.receipt) : null,
          expense.createdAt
        );

      const insertSplit = this.db.prepare(
        'INSERT INTO expense_splits (expense_id, member_id, amount_paise) VALUES (?, ?, ?)'
      );
      for (const s of expense.splits) {
        insertSplit.run(expense.id, s.memberId, s.amountPaise);
      }

      const updatedAt = new Date().toISOString();
      this.db
        .prepare(
          'UPDATE state_meta SET initialized = 1, version = version + 1, updated_at = ? WHERE id = 1'
        )
        .run(updatedAt);

      const meta = this.db
        .prepare('SELECT version FROM state_meta WHERE id = 1')
        .get() as { version: number };

      return { version: meta.version };
    });

    try {
      return tx.immediate();
    } catch (err) {
      if (err instanceof NotFoundError) throw err;
      throw new DatabaseError('Failed to insert expense into SQLite', {
        cause: err instanceof Error ? err.message : String(err),
      });
    }
  }

  public deleteExpenseAtomic(expenseId: string): { version: number } {
    const tx = this.db.transaction(() => {
      const info = this.db.prepare('DELETE FROM expenses WHERE id = ?').run(expenseId);
      if (info.changes === 0) {
        throw new NotFoundError(`Expense "${expenseId}" not found`);
      }
      this.db
        .prepare(
          'UPDATE state_meta SET version = version + 1, updated_at = ? WHERE id = 1'
        )
        .run(new Date().toISOString());
      const meta = this.db
        .prepare('SELECT version FROM state_meta WHERE id = 1')
        .get() as { version: number };
      return { version: meta.version };
    });

    try {
      return tx.immediate();
    } catch (err) {
      if (err instanceof NotFoundError) throw err;
      throw new DatabaseError('Failed to delete expense from SQLite', {
        cause: err instanceof Error ? err.message : String(err),
      });
    }
  }

  public clearState(): void {
    const tx = this.db.transaction(() => {
      this.db.prepare('DELETE FROM expense_splits').run();
      this.db.prepare('DELETE FROM expenses').run();
      this.db.prepare('DELETE FROM settlements').run();
      this.db.prepare('DELETE FROM trip_members').run();
      this.db.prepare('DELETE FROM trips').run();
      this.db.prepare('DELETE FROM members').run();
      this.db.prepare('DELETE FROM app_settings').run();
      this.db
        .prepare(
          'UPDATE state_meta SET initialized = 0, version = 1, updated_at = ? WHERE id = 1'
        )
        .run(new Date().toISOString());
    });
    tx.immediate();
  }

  public close(): void {
    this.db.close();
  }
}
