import type { TripTallyState } from '../types';

export const COVER_IMAGES = {
  goa: '/src/assets/images/trip_cover_goa_1795154284150.jpg',
  mountains: '/src/assets/images/trip_cover_mountains_1795154283909.jpg',
  heritage: '/src/assets/images/trip_cover_heritage_1795154284171.jpg',
};

export const USER_AVATAR = '/src/assets/images/avatar_profile_user_1795154283454.jpg';

const SAMPLE_RECEIPT_SVG = `data:image/svg+xml;utf8,${encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="420" height="560" viewBox="0 0 420 560">
    <rect width="420" height="560" fill="#FFFFFF"/>
    <rect x="20" y="20" width="380" height="520" rx="12" fill="#FAFAFC" stroke="#E2E8F0" stroke-width="2"/>
    <text x="210" y="68" text-anchor="middle" font-family="monospace" font-size="18" font-weight="bold" fill="#101828">CALANGUTE BEACHFRONT VILLA</text>
    <text x="210" y="92" text-anchor="middle" font-family="sans-serif" font-size="12" fill="#64748B">Goa Coastal Stays Pvt Ltd · GSTIN 30AABCC1234F1Z</text>
    <line x1="44" y1="115" x2="376" y2="115" stroke="#CBD5E1" stroke-dasharray="4 4"/>
    <text x="48" y="148" font-family="monospace" font-size="13" fill="#334155">Check-in: 12 Nov 2026</text>
    <text x="48" y="170" font-family="monospace" font-size="13" fill="#334155">Check-out: 16 Nov 2026 (4 Nights)</text>
    <text x="48" y="192" font-family="monospace" font-size="13" fill="#334155">Guests: 4 (Rahul, Priya, Amit, Sneha)</text>
    <line x1="44" y1="215" x2="376" y2="215" stroke="#CBD5E1" stroke-dasharray="4 4"/>
    <text x="48" y="250" font-family="monospace" font-size="13" fill="#1E293B">2x Sea-View Villa Suites</text>
    <text x="372" y="250" text-anchor="end" font-family="monospace" font-size="13" fill="#1E293B">INR 6,800.00</text>
    <text x="48" y="280" font-family="monospace" font-size="13" fill="#1E293B">Resort Tax &amp; Breakfast</text>
    <text x="372" y="280" text-anchor="end" font-family="monospace" font-size="13" fill="#1E293B">INR 1,200.00</text>
    <line x1="44" y1="312" x2="376" y2="312" stroke="#94A3B8"/>
    <text x="48" y="346" font-family="monospace" font-size="16" font-weight="bold" fill="#101828">TOTAL PAID</text>
    <text x="372" y="346" text-anchor="end" font-family="monospace" font-size="16" font-weight="bold" fill="#16A36A">INR 8,000.00</text>
    <text x="48" y="388" font-family="monospace" font-size="12" fill="#475569">Paid via UPI · Ref #UPI88492014</text>
    <text x="48" y="408" font-family="monospace" font-size="12" fill="#475569">Payee: Priya Nair</text>
    <rect x="135" y="440" width="150" height="44" rx="6" fill="#16A36A" fill-opacity="0.1" stroke="#16A36A"/>
    <text x="210" y="467" text-anchor="middle" font-family="sans-serif" font-size="13" font-weight="bold" fill="#16A36A">VERIFIED PAID</text>
  </svg>`
)}`;

export function createInitialDemoState(): TripTallyState {
  return {
    members: [
      {
        id: 'mem_rahul',
        name: 'Rahul Sharma',
        email: 'rahul.sharma@college.edu',
        upiId: 'rahul.sharma@okaxis',
        avatarColor: '#3478F6',
        avatarUrl: USER_AVATAR,
      },
      {
        id: 'mem_priya',
        name: 'Priya Nair',
        email: 'priya.nair@college.edu',
        upiId: 'priya.nair@okicici',
        avatarColor: '#7047EB',
      },
      {
        id: 'mem_amit',
        name: 'Amit Verma',
        email: 'amit.verma@college.edu',
        upiId: 'amit.verma@okhdfcbank',
        avatarColor: '#16A36A',
      },
      {
        id: 'mem_sneha',
        name: 'Sneha Kulkarni',
        email: 'sneha.k@college.edu',
        upiId: 'sneha.kulkarni@oksbi',
        avatarColor: '#F5A623',
      },
    ],
    trips: [
      {
        id: 'trip_goa_2026',
        name: 'Goa Road Trip 2026',
        destination: 'North & South Goa',
        startDate: '2026-11-12',
        endDate: '2026-11-16',
        budgetPaise: 2500000, // ₹25,000
        description:
          'Post-semester coastal drive from Pune to Goa covering Calangute, Dudhsagar Falls, and Palolem.',
        coverImage: COVER_IMAGES.goa,
        status: 'active',
        memberIds: ['mem_rahul', 'mem_priya', 'mem_amit', 'mem_sneha'],
        createdAt: '2026-11-01T10:00:00.000Z',
      },
      {
        id: 'trip_manali_2026',
        name: 'Manali Winter Escape',
        destination: 'Manali & Solang Valley',
        startDate: '2026-10-10',
        endDate: '2026-10-14',
        budgetPaise: 1800000, // ₹18,000
        description:
          'Autumn mountain getaway with overnight Volvo transit, cedar cottage stay, and Solang Valley adventure.',
        coverImage: COVER_IMAGES.mountains,
        status: 'active',
        memberIds: ['mem_rahul', 'mem_priya', 'mem_amit', 'mem_sneha'],
        createdAt: '2026-10-01T09:00:00.000Z',
      },
    ],
    expenses: [
      // Goa Road Trip 2026 — 8 internally consistent sample expenses (Total: ₹23,400)
      {
        id: 'exp_goa_1',
        tripId: 'trip_goa_2026',
        title: 'Hotel – Beachfront Villa Stay',
        amountPaise: 800000, // ₹8,000
        category: 'Stay',
        date: '2026-11-12',
        paidByMemberId: 'mem_priya',
        participantIds: ['mem_rahul', 'mem_priya', 'mem_amit', 'mem_sneha'],
        splitType: 'equal',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 200000 },
          { memberId: 'mem_priya', amountPaise: 200000 },
          { memberId: 'mem_amit', amountPaise: 200000 },
          { memberId: 'mem_sneha', amountPaise: 200000 },
        ],
        notes: '4 nights twin-suite booking near Calangute beach including breakfast.',
        receipt: {
          id: 'rcpt_goa_1',
          name: 'calangute_villa_invoice.svg',
          dataUrl: SAMPLE_RECEIPT_SVG,
          uploadedAt: '2026-11-12T15:30:00.000Z',
          sizeBytes: 2140,
        },
        createdAt: '2026-11-12T15:30:00.000Z',
      },
      {
        id: 'exp_goa_2',
        tripId: 'trip_goa_2026',
        title: 'Highway Fuel & FASTag Tolls',
        amountPaise: 450000, // ₹4,500
        category: 'Travel',
        date: '2026-11-12',
        paidByMemberId: 'mem_rahul',
        participantIds: ['mem_rahul', 'mem_priya', 'mem_amit', 'mem_sneha'],
        splitType: 'equal',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 112500 },
          { memberId: 'mem_priya', amountPaise: 112500 },
          { memberId: 'mem_amit', amountPaise: 112500 },
          { memberId: 'mem_sneha', amountPaise: 112500 },
        ],
        notes: 'Full tank petrol refill + Pune-Goa expressway tolls.',
        createdAt: '2026-11-12T19:15:00.000Z',
      },
      {
        id: 'exp_goa_3',
        tripId: 'trip_goa_2026',
        title: 'Group Sunset Dinners',
        amountPaise: 320000, // ₹3,200
        category: 'Food',
        date: '2026-11-13',
        paidByMemberId: 'mem_amit',
        participantIds: ['mem_rahul', 'mem_priya', 'mem_amit', 'mem_sneha'],
        splitType: 'equal',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 80000 },
          { memberId: 'mem_priya', amountPaise: 80000 },
          { memberId: 'mem_amit', amountPaise: 80000 },
          { memberId: 'mem_sneha', amountPaise: 80000 },
        ],
        notes: 'Coastal seafood & vegetarian platter dinner at Vagator cliff.',
        createdAt: '2026-11-13T21:40:00.000Z',
      },
      {
        id: 'exp_goa_4',
        tripId: 'trip_goa_2026',
        title: 'Sightseeing & Fort Entry Passes',
        amountPaise: 150000, // ₹1,500
        category: 'Activities',
        date: '2026-11-14',
        paidByMemberId: 'mem_rahul',
        participantIds: ['mem_rahul', 'mem_priya', 'mem_amit', 'mem_sneha'],
        splitType: 'equal',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 37500 },
          { memberId: 'mem_priya', amountPaise: 37500 },
          { memberId: 'mem_amit', amountPaise: 37500 },
          { memberId: 'mem_sneha', amountPaise: 37500 },
        ],
        notes: 'Aguada Fort, Chapora viewpoint parking, and spice plantation tour.',
        createdAt: '2026-11-14T14:20:00.000Z',
      },
      {
        id: 'exp_goa_5',
        tripId: 'trip_goa_2026',
        title: 'Baga Water Sports & Kayaking',
        amountPaise: 240000, // ₹2,400
        category: 'Activities',
        date: '2026-11-14',
        paidByMemberId: 'mem_priya',
        participantIds: ['mem_rahul', 'mem_priya', 'mem_amit'],
        splitType: 'subset',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 80000 },
          { memberId: 'mem_priya', amountPaise: 80000 },
          { memberId: 'mem_amit', amountPaise: 80000 },
        ],
        notes: 'Jet ski and tandem kayak session (Sneha opted out to relax by the beach).',
        createdAt: '2026-11-14T17:10:00.000Z',
      },
      {
        id: 'exp_goa_6',
        tripId: 'trip_goa_2026',
        title: 'Anjuna Flea Market Souvenirs',
        amountPaise: 120000, // ₹1,200
        category: 'Shopping',
        date: '2026-11-15',
        paidByMemberId: 'mem_sneha',
        participantIds: ['mem_rahul', 'mem_priya', 'mem_sneha'],
        splitType: 'exact',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 40000 },
          { memberId: 'mem_priya', amountPaise: 30000 },
          { memberId: 'mem_sneha', amountPaise: 50000 },
        ],
        notes: 'Exact itemized split for cashews, tote bags, and postcards.',
        createdAt: '2026-11-15T13:05:00.000Z',
      },
      {
        id: 'exp_goa_7',
        tripId: 'trip_goa_2026',
        title: 'South Goa Scooter Rentals',
        amountPaise: 160000, // ₹1,600
        category: 'Travel',
        date: '2026-11-15',
        paidByMemberId: 'mem_amit',
        participantIds: ['mem_rahul', 'mem_priya', 'mem_amit', 'mem_sneha'],
        splitType: 'equal',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 40000 },
          { memberId: 'mem_priya', amountPaise: 40000 },
          { memberId: 'mem_amit', amountPaise: 40000 },
          { memberId: 'mem_sneha', amountPaise: 40000 },
        ],
        notes: 'Two Activa scooters rented for Palolem and Cabo de Rama loop.',
        createdAt: '2026-11-15T16:45:00.000Z',
      },
      {
        id: 'exp_goa_8',
        tripId: 'trip_goa_2026',
        title: 'Cafe Brunch & Cold Brews',
        amountPaise: 100000, // ₹1,000
        category: 'Food',
        date: '2026-11-16',
        paidByMemberId: 'mem_rahul',
        participantIds: ['mem_rahul', 'mem_sneha'],
        splitType: 'subset',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 50000 },
          { memberId: 'mem_sneha', amountPaise: 50000 },
        ],
        notes: 'Early morning breakfast stop before driving back.',
        createdAt: '2026-11-16T09:30:00.000Z',
      },

      // Manali Winter Escape — 4 October 2026 expenses (Total: ₹14,400)
      {
        id: 'exp_manali_1',
        tripId: 'trip_manali_2026',
        title: 'Overnight Volvo Bus Tickets',
        amountPaise: 480000, // ₹4,800
        category: 'Travel',
        date: '2026-10-10',
        paidByMemberId: 'mem_rahul',
        participantIds: ['mem_rahul', 'mem_priya', 'mem_amit', 'mem_sneha'],
        splitType: 'equal',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 120000 },
          { memberId: 'mem_priya', amountPaise: 120000 },
          { memberId: 'mem_amit', amountPaise: 120000 },
          { memberId: 'mem_sneha', amountPaise: 120000 },
        ],
        notes: 'Semi-sleeper round trip tickets.',
        createdAt: '2026-10-10T20:00:00.000Z',
      },
      {
        id: 'exp_manali_2',
        tripId: 'trip_manali_2026',
        title: 'Riverside Cedar Cottage',
        amountPaise: 600000, // ₹6,000
        category: 'Stay',
        date: '2026-10-11',
        paidByMemberId: 'mem_amit',
        participantIds: ['mem_rahul', 'mem_priya', 'mem_amit', 'mem_sneha'],
        splitType: 'equal',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 150000 },
          { memberId: 'mem_priya', amountPaise: 150000 },
          { memberId: 'mem_amit', amountPaise: 150000 },
          { memberId: 'mem_sneha', amountPaise: 150000 },
        ],
        notes: '3-night wooden cottage booking in Old Manali.',
        createdAt: '2026-10-11T12:00:00.000Z',
      },
      {
        id: 'exp_manali_3',
        tripId: 'trip_manali_2026',
        title: 'Solang Paragliding & Gear',
        amountPaise: 240000, // ₹2,400
        category: 'Activities',
        date: '2026-10-12',
        paidByMemberId: 'mem_sneha',
        participantIds: ['mem_rahul', 'mem_priya', 'mem_amit', 'mem_sneha'],
        splitType: 'equal',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 60000 },
          { memberId: 'mem_priya', amountPaise: 60000 },
          { memberId: 'mem_amit', amountPaise: 60000 },
          { memberId: 'mem_sneha', amountPaise: 60000 },
        ],
        notes: 'Snow suit rentals and adventure passes.',
        createdAt: '2026-10-12T14:00:00.000Z',
      },
      {
        id: 'exp_manali_4',
        tripId: 'trip_manali_2026',
        title: 'Old Manali Cafe Dinner',
        amountPaise: 120000, // ₹1,200
        category: 'Food',
        date: '2026-10-13',
        paidByMemberId: 'mem_priya',
        participantIds: ['mem_rahul', 'mem_priya', 'mem_amit', 'mem_sneha'],
        splitType: 'equal',
        splits: [
          { memberId: 'mem_rahul', amountPaise: 30000 },
          { memberId: 'mem_priya', amountPaise: 30000 },
          { memberId: 'mem_amit', amountPaise: 30000 },
          { memberId: 'mem_sneha', amountPaise: 30000 },
        ],
        notes: 'Wood-fired pizza, hot chocolate, and Himalayan trout.',
        createdAt: '2026-10-13T20:30:00.000Z',
      },
    ],
    settlements: [
      {
        id: 'stl_manali_1',
        tripId: 'trip_manali_2026',
        fromMemberId: 'mem_priya',
        toMemberId: 'mem_amit',
        amountPaise: 240000,
        status: 'paid',
        paidAt: '2026-10-15T11:20:00.000Z',
        method: 'upi',
        note: 'Settled via Google Pay after Manali return',
      },
      {
        id: 'stl_manali_2',
        tripId: 'trip_manali_2026',
        fromMemberId: 'mem_sneha',
        toMemberId: 'mem_rahul',
        amountPaise: 120000,
        status: 'paid',
        paidAt: '2026-10-15T14:05:00.000Z',
        method: 'upi',
        note: 'Manali Volvo ticket balance cleared',
      },
    ],
    settings: {
      activeUserId: 'mem_rahul',
      enable75Alert: true,
      enable90Alert: true,
      enable100Alert: true,
      defaultSplitType: 'equal',
    },
  };
}
