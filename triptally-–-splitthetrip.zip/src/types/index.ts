export type ExpenseCategory =
  | 'Travel'
  | 'Food'
  | 'Stay'
  | 'Activities'
  | 'Shopping'
  | 'Miscellaneous';

export type SplitType = 'equal' | 'exact' | 'subset';

export interface Member {
  id: string;
  name: string;
  email: string;
  upiId: string;
  avatarColor: string;
  avatarUrl?: string;
}

export interface Trip {
  id: string;
  name: string;
  destination: string;
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
  budgetPaise: number;
  description: string;
  coverImage: string;
  status: 'active' | 'archived';
  memberIds: string[];
  createdAt: string;
}

export interface ExpenseSplit {
  memberId: string;
  amountPaise: number;
}

export interface ReceiptAsset {
  id: string;
  name: string;
  dataUrl: string;
  uploadedAt: string;
  sizeBytes: number;
}

export interface Expense {
  id: string;
  tripId: string;
  title: string;
  amountPaise: number;
  category: ExpenseCategory;
  date: string; // YYYY-MM-DD
  paidByMemberId: string;
  participantIds: string[];
  splitType: SplitType;
  splits: ExpenseSplit[];
  notes: string;
  receipt?: ReceiptAsset;
  createdAt: string;
}

export type SettlementMethod = 'upi' | 'cash' | 'bank';

export interface SettlementRecord {
  id: string;
  tripId: string;
  fromMemberId: string;
  toMemberId: string;
  amountPaise: number;
  status: 'pending' | 'paid';
  paidAt?: string;
  method?: SettlementMethod;
  note?: string;
}

export interface AppSettings {
  activeUserId: string;
  enable75Alert: boolean;
  enable90Alert: boolean;
  enable100Alert: boolean;
  defaultSplitType: SplitType;
}

export interface TripTallyState {
  members: Member[];
  trips: Trip[];
  expenses: Expense[];
  settlements: SettlementRecord[];
  settings: AppSettings;
}

export interface MemberBalance {
  memberId: string;
  member: Member;
  totalPaidPaise: number;
  totalSharePaise: number;
  settledOutPaise: number;
  settledInPaise: number;
  rawNetPaise: number;
  netBalancePaise: number;
  status: 'owed' | 'owes' | 'settled';
  paidExpenseCount: number;
  participatedExpenseCount: number;
}

export interface OriginalDebtEdge {
  fromMemberId: string;
  toMemberId: string;
  amountPaise: number;
  expenseCount: number;
}

export interface SimplifiedDebt {
  id: string;
  fromMemberId: string;
  toMemberId: string;
  amountPaise: number;
}

export interface SimplificationResult {
  balances: MemberBalance[];
  rawExpenseDebtEdges: number;
  pairwiseDebts: OriginalDebtEdge[];
  simplifiedTransactions: SimplifiedDebt[];
  totalSettlementVolumePaise: number;
  reductionPercent: number;
}

export type BudgetAlertLevel = 'nominal' | 'warning75' | 'warning90' | 'limit100' | 'exceeded';

export interface BudgetAlertInfo {
  level: BudgetAlertLevel;
  utilizationPercent: number;
  spentPaise: number;
  budgetPaise: number;
  remainingPaise: number;
  title: string;
  message: string;
}
