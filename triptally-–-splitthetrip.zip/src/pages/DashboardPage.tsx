import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowDownLeft,
  ArrowRight,
  ArrowUpRight,
  Calendar,
  CreditCard,
  MapPin,
  PiggyBank,
  Plus,
  Receipt,
  Sparkles,
  Wallet,
} from 'lucide-react';
import {
  CategoryDoughnutChart,
  MonthlySpendingLineChart,
} from '../components/AnalyticsCharts';
import { CategoryIcon } from '../components/CategoryIcon';
import { ExpenseModal } from '../components/ExpenseModal';
import { MemberAvatar } from '../components/MemberAvatar';
import { UpiPaymentModal } from '../components/UpiPaymentModal';
import { useTripTally } from '../context/TripTallyContext';
import type { Expense, Member, SimplifiedDebt } from '../types';
import {
  computeBudgetAlert,
  formatDateShort,
  formatINR,
  runDebtSimplification,
} from '../utils/finance';

export function DashboardPage() {
  const { state } = useTripTally();
  const [selectedTripScope, setSelectedTripScope] = useState<string>('all');
  const [expenseModalOpen, setExpenseModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [upiTarget, setUpiTarget] = useState<{
    tripId: string;
    tripName: string;
    tx: SimplifiedDebt;
  } | null>(null);

  const memberMap = useMemo(
    () => new Map<string, Member>(state.members.map((m) => [m.id, m])),
    [state.members]
  );

  const activeUser = useMemo(
    () =>
      memberMap.get(state.settings.activeUserId) ?? state.members[0],
    [memberMap, state.settings.activeUserId, state.members]
  );

  const scopedTrips = useMemo(() => {
    const activeTrips = state.trips.filter((t) => t.status === 'active');
    if (selectedTripScope === 'all') return activeTrips;
    return state.trips.filter((t) => t.id === selectedTripScope);
  }, [state.trips, selectedTripScope]);

  const scopedExpenses = useMemo(() => {
    const tripIds = new Set(scopedTrips.map((t) => t.id));
    return state.expenses
      .filter((e) => tripIds.has(e.tripId))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [state.expenses, scopedTrips]);

  // Compute aggregated trip-by-trip settlements and ledger
  const aggregatedStats = useMemo(() => {
    let totalBudgetPaise = 0;
    let totalExpensesPaise = 0;
    let userPaidPaise = 0;
    let userOwePaise = 0;
    let userOwedPaise = 0;

    const pendingTransfers: Array<{
      tripId: string;
      tripName: string;
      tx: SimplifiedDebt;
    }> = [];

    const combinedMemberNet = new Map<
      string,
      { paid: number; share: number; net: number }
    >();
    for (const m of state.members) {
      combinedMemberNet.set(m.id, { paid: 0, share: 0, net: 0 });
    }

    for (const trip of scopedTrips) {
      totalBudgetPaise += trip.budgetPaise;
      const tExpenses = state.expenses.filter((e) => e.tripId === trip.id);
      const tSettlements = state.settlements.filter((s) => s.tripId === trip.id);
      totalExpensesPaise += tExpenses.reduce((acc, e) => acc + e.amountPaise, 0);

      const sim = runDebtSimplification(
        trip.memberIds,
        state.members,
        tExpenses,
        tSettlements
      );

      for (const b of sim.balances) {
        const entry = combinedMemberNet.get(b.memberId);
        if (entry) {
          entry.paid += b.totalPaidPaise;
          entry.share += b.totalSharePaise;
          entry.net += b.netBalancePaise;
        }
        if (activeUser && b.memberId === activeUser.id) {
          userPaidPaise += b.totalPaidPaise;
          if (b.netBalancePaise < 0) {
            userOwePaise += Math.abs(b.netBalancePaise);
          } else if (b.netBalancePaise > 0) {
            userOwedPaise += b.netBalancePaise;
          }
        }
      }

      for (const tx of sim.simplifiedTransactions) {
        pendingTransfers.push({
          tripId: trip.id,
          tripName: trip.name,
          tx,
        });
      }
    }

    const remainingBudgetPaise = totalBudgetPaise - totalExpensesPaise;
    const budgetUsedPct =
      totalBudgetPaise > 0 ? (totalExpensesPaise / totalBudgetPaise) * 100 : 0;
    const paidSharePct =
      totalExpensesPaise > 0 ? (userPaidPaise / totalExpensesPaise) * 100 : 0;

    return {
      totalBudgetPaise,
      totalExpensesPaise,
      userPaidPaise,
      remainingBudgetPaise,
      userOwePaise,
      userOwedPaise,
      budgetUsedPct,
      paidSharePct,
      pendingTransfers,
      combinedMemberNet,
    };
  }, [scopedTrips, state.expenses, state.settlements, state.members, activeUser]);

  // Smart budget alerts for scoped trips
  const budgetAlerts = useMemo(() => {
    return scopedTrips
      .map((trip) => {
        const spent = state.expenses
          .filter((e) => e.tripId === trip.id)
          .reduce((acc, e) => acc + e.amountPaise, 0);
        return { trip, alert: computeBudgetAlert(trip, spent) };
      })
      .filter(({ alert }) => alert.level !== 'nominal');
  }, [scopedTrips, state.expenses]);

  const recentTrips = useMemo(() => {
    return state.trips.slice(0, 3).map((trip) => {
      const tripExps = state.expenses.filter((e) => e.tripId === trip.id);
      const spentPaise = tripExps.reduce((acc, e) => acc + e.amountPaise, 0);
      return {
        trip,
        spentPaise,
        remainingPaise: trip.budgetPaise - spentPaise,
        expenseCount: tripExps.length,
        alert: computeBudgetAlert(trip, spentPaise),
      };
    });
  }, [state.trips, state.expenses]);

  return (
    <div className="space-y-6">
      {/* Scope Filter & Quick Action Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-[#525870]">Scope:</span>
          <div className="inline-flex flex-wrap items-center gap-1 rounded-lg border border-[#E5E3F3] bg-white p-1">
            <button
              type="button"
              onClick={() => setSelectedTripScope('all')}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedTripScope === 'all'
                  ? 'bg-[#101828] text-white'
                  : 'text-[#525870] hover:text-[#101828]'
              }`}
            >
              All Active Trips
            </button>
            {state.trips
              .filter((t) => t.status === 'active')
              .map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setSelectedTripScope(t.id)}
                  className={`rounded-md px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                    selectedTripScope === t.id
                      ? 'bg-[#7047EB] text-white'
                      : 'text-[#525870] hover:text-[#101828]'
                  }`}
                >
                  {t.name}
                </button>
              ))}
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <Link
            to="/settlements"
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-xs font-semibold whitespace-nowrap text-[#101828] transition-colors hover:bg-[#F6F5FC]"
          >
            <Sparkles size={14} className="text-[#7047EB]" />
            Simplify Debts
          </Link>
          <button
            type="button"
            onClick={() => {
              setEditingExpense(null);
              setExpenseModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#101828] px-4 py-2 text-xs font-semibold whitespace-nowrap text-white shadow-sm transition-colors hover:bg-[#1E293B]"
          >
            <Plus size={14} />
            Log Expense
          </button>
        </div>
      </div>

      {/* Smart Budget Alert Banner */}
      {budgetAlerts.length > 0 && (
        <div className="space-y-2">
          {budgetAlerts.slice(0, 2).map(({ trip, alert }) => {
            const isDanger = alert.level === 'exceeded' || alert.level === 'limit100';
            return (
              <div
                key={trip.id}
                className={`flex flex-wrap items-center justify-between gap-3 rounded-xl border px-4 py-3 ${
                  isDanger
                    ? 'border-[#EF5350]/30 bg-[#EF5350]/8 text-[#991B1B]'
                    : 'border-[#F5A623]/35 bg-[#F5A623]/10 text-[#92400E]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <AlertTriangle
                    size={18}
                    className={isDanger ? 'text-[#EF5350]' : 'text-[#D97706]'}
                  />
                  <div>
                    <p className="text-xs font-bold">{alert.title}</p>
                    <p className="text-xs opacity-90">{alert.message}</p>
                  </div>
                </div>
                <Link
                  to={`/trips/${trip.id}`}
                  className="inline-flex items-center gap-1 text-xs font-semibold underline-offset-2 hover:underline"
                >
                  Inspect Budget <ArrowRight size={13} />
                </Link>
              </div>
            );
          })}
        </div>
      )}

      {/* 6 Financial Stat Cards */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {/* 1. Total Trip Budget */}
        <div className="group rounded-xl border border-[#E5E3F3] bg-gradient-to-br from-white to-[#F8F7FE] p-5 transition-transform duration-150 hover:-translate-y-0.5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold text-[#525870]">Total Trip Budget</p>
              <p className="font-mono-tabular mt-2 text-2xl font-bold tracking-tight text-[#101828]">
                {formatINR(aggregatedStats.totalBudgetPaise)}
              </p>
            </div>
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#101828]/8 text-[#101828]">
              <Wallet size={19} />
            </span>
          </div>
          <p className="mt-3 text-xs text-[#525870]">
            Across {scopedTrips.length} active {scopedTrips.length === 1 ? 'trip' : 'trips'}
          </p>
        </div>

        {/* 2. Total Expenses */}
        <div className="group rounded-xl border border-[#E5E3F3] bg-gradient-to-br from-white to-[#F4F2FE] p-5 transition-transform duration-150 hover:-translate-y-0.5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold text-[#525870]">Total Expenses</p>
              <p className="font-mono-tabular mt-2 text-2xl font-bold tracking-tight text-[#101828]">
                {formatINR(aggregatedStats.totalExpensesPaise)}
              </p>
            </div>
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#7047EB]/12 text-[#7047EB]">
              <Receipt size={19} />
            </span>
          </div>
          <p className="font-mono-tabular mt-3 text-xs text-[#525870]">
            <span className="font-semibold text-[#7047EB]">
              {aggregatedStats.budgetUsedPct.toFixed(1)}%
            </span>{' '}
            of budget utilized · {scopedExpenses.length} entries
          </p>
        </div>

        {/* 3. Amount Paid */}
        <div className="group rounded-xl border border-[#E5E3F3] bg-gradient-to-br from-white to-[#F2F7FF] p-5 transition-transform duration-150 hover:-translate-y-0.5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold text-[#525870]">
                Amount Paid ({activeUser?.name.split(' ')[0]})
              </p>
              <p className="font-mono-tabular mt-2 text-2xl font-bold tracking-tight text-[#101828]">
                {formatINR(aggregatedStats.userPaidPaise)}
              </p>
            </div>
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#3478F6]/12 text-[#3478F6]">
              <CreditCard size={19} />
            </span>
          </div>
          <p className="font-mono-tabular mt-3 text-xs text-[#525870]">
            <span className="font-semibold text-[#3478F6]">
              {aggregatedStats.paidSharePct.toFixed(1)}%
            </span>{' '}
            of total group spending
          </p>
        </div>

        {/* 4. Remaining Budget */}
        <div className="group rounded-xl border border-[#E5E3F3] bg-gradient-to-br from-white to-[#F3FBF7] p-5 transition-transform duration-150 hover:-translate-y-0.5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold text-[#525870]">Remaining Budget</p>
              <p
                className={`font-mono-tabular mt-2 text-2xl font-bold tracking-tight ${
                  aggregatedStats.remainingBudgetPaise < 0
                    ? 'text-[#EF5350]'
                    : 'text-[#101828]'
                }`}
              >
                {formatINR(aggregatedStats.remainingBudgetPaise)}
              </p>
            </div>
            <span
              className={`flex h-10 w-10 items-center justify-center rounded-xl ${
                aggregatedStats.remainingBudgetPaise < 0
                  ? 'bg-[#EF5350]/12 text-[#EF5350]'
                  : 'bg-[#16A36A]/12 text-[#16A36A]'
              }`}
            >
              <PiggyBank size={19} />
            </span>
          </div>
          <p className="font-mono-tabular mt-3 text-xs text-[#525870]">
            {aggregatedStats.remainingBudgetPaise >= 0
              ? `${(100 - Math.min(100, aggregatedStats.budgetUsedPct)).toFixed(1)}% headroom available`
              : 'Budget limit exceeded'}
          </p>
        </div>

        {/* 5. You Owe */}
        <div className="group rounded-xl border border-[#E5E3F3] bg-gradient-to-br from-white to-[#FFF5F5] p-5 transition-transform duration-150 hover:-translate-y-0.5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold text-[#525870]">You Owe</p>
              <p className="font-mono-tabular mt-2 text-2xl font-bold tracking-tight text-[#EF5350]">
                {formatINR(aggregatedStats.userOwePaise)}
              </p>
            </div>
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#EF5350]/12 text-[#EF5350]">
              <ArrowUpRight size={19} />
            </span>
          </div>
          <p className="mt-3 text-xs text-[#525870]">
            {aggregatedStats.userOwePaise > 0
              ? `Pending payable for ${activeUser?.name.split(' ')[0]}`
              : 'No pending outgoing debt'}
          </p>
        </div>

        {/* 6. You Are Owed */}
        <div className="group rounded-xl border border-[#E5E3F3] bg-gradient-to-br from-white to-[#F2FBF6] p-5 transition-transform duration-150 hover:-translate-y-0.5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold text-[#525870]">You Are Owed</p>
              <p className="font-mono-tabular mt-2 text-2xl font-bold tracking-tight text-[#16A36A]">
                {formatINR(aggregatedStats.userOwedPaise)}
              </p>
            </div>
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#16A36A]/12 text-[#16A36A]">
              <ArrowDownLeft size={19} />
            </span>
          </div>
          <p className="mt-3 text-xs text-[#525870]">
            {aggregatedStats.userOwedPaise > 0
              ? `Receivable from group members`
              : 'No pending reimbursements'}
          </p>
        </div>
      </section>

      {/* Charts Row: Category Spending + Monthly Spending */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-bold text-[#101828]">
                Category Spending
              </h2>
              <p className="text-xs text-[#525870]">
                Distribution across Travel, Stay, Food, and Activities
              </p>
            </div>
            <Link
              to="/analytics"
              className="text-xs font-semibold text-[#7047EB] hover:text-[#5B34D6]"
            >
              Full Analytics
            </Link>
          </div>
          <CategoryDoughnutChart expenses={scopedExpenses} />
        </div>

        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-bold text-[#101828]">
                Monthly Spending Trend
              </h2>
              <p className="text-xs text-[#525870]">
                Cumulative travel expenditure across months
              </p>
            </div>
            <span className="font-mono-tabular text-xs font-semibold text-[#101828]">
              {formatINR(
                state.expenses.reduce((s, e) => s + e.amountPaise, 0)
              )}{' '}
              all-time
            </span>
          </div>
          <MonthlySpendingLineChart expenses={state.expenses} />
        </div>
      </section>

      {/* Recent Trips */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-display text-base font-bold text-[#101828]">Recent Trips</h2>
            <p className="text-xs text-[#525870]">
              Active and recent group expeditions with live budget tracking
            </p>
          </div>
          <Link
            to="/trips"
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#7047EB] hover:text-[#5B34D6]"
          >
            View All Trips <ArrowRight size={13} />
          </Link>
        </div>

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
          {recentTrips.map(({ trip, spentPaise, remainingPaise, expenseCount, alert }) => {
            const tripMembers = trip.memberIds
              .map((id) => memberMap.get(id))
              .filter((m): m is Member => Boolean(m));
            const pctClamped = Math.min(100, Math.max(0, alert.utilizationPercent));

            return (
              <div
                key={trip.id}
                className="flex flex-col overflow-hidden rounded-xl border border-[#E5E3F3] bg-white transition-shadow hover:shadow-md"
              >
                <div className="relative h-40 overflow-hidden bg-slate-200">
                  <img
                    src={trip.coverImage}
                    alt={trip.name}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#101828]/80 via-[#101828]/25 to-transparent" />
                  <div className="absolute right-4 bottom-3 left-4 text-white">
                    <h3 className="font-display truncate text-base font-bold">{trip.name}</h3>
                    <div className="mt-0.5 flex items-center gap-2 text-xs text-slate-200">
                      <span className="inline-flex items-center gap-1 truncate">
                        <MapPin size={12} /> {trip.destination}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums shrink-0">{expenseCount} expenses</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-1 flex-col justify-between p-5">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-[#525870]">
                      <span className="inline-flex items-center gap-1.5 tabular-nums">
                        <Calendar size={13} />
                        {formatDateShort(trip.startDate)} – {formatDateShort(trip.endDate)}
                      </span>
                    </div>

                    <div>
                      <div className="mb-1.5 flex items-center justify-between text-xs">
                        <span className="font-medium text-[#525870]">
                          Spent:{' '}
                          <strong className="font-mono-tabular text-[#101828]">
                            {formatINR(spentPaise)}
                          </strong>
                        </span>
                        <span
                          className={`font-mono-tabular font-semibold ${
                            remainingPaise < 0 ? 'text-[#EF5350]' : 'text-[#16A36A]'
                          }`}
                        >
                          {remainingPaise >= 0
                            ? `${formatINR(remainingPaise)} left`
                            : `${formatINR(Math.abs(remainingPaise))} over`}
                        </span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-[#EFEFF7]">
                        <div
                          className={`h-full rounded-full transition-all ${
                            alert.level === 'exceeded' || alert.level === 'limit100'
                              ? 'bg-[#EF5350]'
                              : alert.level === 'warning90' || alert.level === 'warning75'
                              ? 'bg-[#F5A623]'
                              : 'bg-[#7047EB]'
                          }`}
                          style={{ width: `${pctClamped}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 flex items-center justify-between border-t border-[#EFEFF7] pt-3.5">
                    <div className="flex -space-x-2">
                      {tripMembers.slice(0, 4).map((m) => (
                        <MemberAvatar key={m.id} member={m} size="sm" />
                      ))}
                      {tripMembers.length > 4 && (
                        <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-[#F6F5FC] text-xs font-semibold text-[#525870] ring-2 ring-white">
                          +{tripMembers.length - 4}
                        </span>
                      )}
                    </div>
                    <Link
                      to={`/trips/${trip.id}`}
                      className="inline-flex items-center gap-1 rounded-lg border border-[#E5E3F3] bg-white px-3 py-1.5 text-xs font-semibold text-[#101828] transition-colors hover:bg-[#F6F5FC]"
                    >
                      View Details
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Bottom 2-Column Split: Member Balance Overview + Pending Settlements */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Member Balance Overview */}
        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-bold text-[#101828]">
                Member Balance Overview
              </h2>
              <p className="text-xs text-[#525870]">
                Net position across selected trips
              </p>
            </div>
            <Link
              to="/members"
              className="text-xs font-semibold text-[#7047EB] hover:text-[#5B34D6]"
            >
              Manage Members
            </Link>
          </div>

          <div className="divide-y divide-[#EFEFF7]">
            {state.members.map((m) => {
              const entry = aggregatedStats.combinedMemberNet.get(m.id) ?? {
                paid: 0,
                share: 0,
                net: 0,
              };
              const isPositive = entry.net > 0;
              const isNegative = entry.net < 0;
              return (
                <div key={m.id} className="flex items-center justify-between py-3">
                  <div className="flex min-w-0 items-center gap-3">
                    <MemberAvatar member={m} size="sm" />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-[#101828]">
                        {m.name}
                      </p>
                      <p className="font-mono-tabular text-xs text-[#525870]">
                        Paid {formatINR(entry.paid)} · Share {formatINR(entry.share)}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p
                      className={`font-mono-tabular text-sm font-bold ${
                        isPositive
                          ? 'text-[#16A36A]'
                          : isNegative
                          ? 'text-[#EF5350]'
                          : 'text-[#525870]'
                      }`}
                    >
                      {isPositive ? '+' : ''}
                      {formatINR(entry.net)}
                    </p>
                    <p className="text-[11px] font-medium text-[#525870]">
                      {isPositive
                        ? 'Owed to member'
                        : isNegative
                        ? 'Owes group'
                        : 'Settled'}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Pending Settlements */}
        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-bold text-[#101828]">
                Pending Settlements
              </h2>
              <p className="text-xs text-[#525870]">
                Minimized transactions via Greedy Cash-Flow Engine
              </p>
            </div>
            <Link
              to="/settlements"
              className="text-xs font-semibold text-[#7047EB] hover:text-[#5B34D6]"
            >
              Open Engine
            </Link>
          </div>

          {aggregatedStats.pendingTransfers.length === 0 ? (
            <div className="flex h-48 flex-col items-center justify-center rounded-lg bg-[#F6F5FC] p-6 text-center">
              <p className="text-sm font-semibold text-[#16A36A]">All Balances Settled</p>
              <p className="mt-1 text-xs text-[#525870]">
                Zero pending debts remain across the selected trips.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-[#EFEFF7]">
              {aggregatedStats.pendingTransfers.slice(0, 5).map((item) => {
                const fromM = memberMap.get(item.tx.fromMemberId);
                const toM = memberMap.get(item.tx.toMemberId);
                return (
                  <div
                    key={`${item.tripId}_${item.tx.id}`}
                    className="flex flex-wrap items-center justify-between gap-3 py-3"
                  >
                    <div className="flex min-w-0 items-center gap-2.5">
                      <MemberAvatar member={fromM} size="sm" />
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-[#101828]">
                          {fromM?.name.split(' ')[0]} pays {toM?.name.split(' ')[0]}
                        </p>
                        <p className="truncate text-xs text-[#525870]">{item.tripName}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-mono-tabular text-sm font-bold text-[#101828]">
                        {formatINR(item.tx.amountPaise)}
                      </span>
                      <button
                        type="button"
                        onClick={() => setUpiTarget(item)}
                        className="rounded-lg bg-[#7047EB] px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-[#5B34D6]"
                      >
                        Settle
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Recent Expenses Table */}
      <section className="rounded-xl border border-[#E5E3F3] bg-white p-6">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="font-display text-base font-bold text-[#101828]">
              Recent Expenses
            </h2>
            <p className="text-xs text-[#525870]">
              Latest shared bills across your selected scope
            </p>
          </div>
          <Link
            to="/expenses"
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#7047EB] hover:text-[#5B34D6]"
          >
            All Expenses <ArrowRight size={13} />
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[680px] border-collapse text-left">
            <thead>
              <tr className="border-b border-[#EFEFF7] text-xs font-semibold text-[#525870]">
                <th className="py-3 pr-4">Expense</th>
                <th className="py-3 pr-4">Category</th>
                <th className="py-3 pr-4">Paid By</th>
                <th className="py-3 pr-4">Participants</th>
                <th className="py-3 pr-4">Date</th>
                <th className="py-3 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EFEFF7] text-sm">
              {scopedExpenses.slice(0, 6).map((exp) => {
                const payer = memberMap.get(exp.paidByMemberId);
                return (
                  <tr
                    key={exp.id}
                    onClick={() => {
                      setEditingExpense(exp);
                      setExpenseModalOpen(true);
                    }}
                    className="cursor-pointer transition-colors hover:bg-[#F6F5FC]/70"
                  >
                    <td className="py-3 pr-4 font-semibold text-[#101828]">
                      {exp.title}
                    </td>
                    <td className="py-3 pr-4">
                      <CategoryIcon category={exp.category} showLabel />
                    </td>
                    <td className="py-3 pr-4 text-xs font-medium text-[#202438]">
                      <span className="inline-flex items-center gap-2">
                        <MemberAvatar member={payer} size="xs" />
                        {payer?.name.split(' ')[0]}
                      </span>
                    </td>
                    <td className="tabular-nums py-3 pr-4 text-xs text-[#525870]">
                      {exp.participantIds.length} members · {exp.splitType}
                    </td>
                    <td className="tabular-nums py-3 pr-4 text-xs text-[#525870]">
                      {formatDateShort(exp.date)}
                    </td>
                    <td className="font-mono-tabular py-3 text-right font-bold text-[#101828]">
                      {formatINR(exp.amountPaise)}
                    </td>
                  </tr>
                );
              })}
              {scopedExpenses.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-xs text-[#525870]">
                    No expenses logged yet in this scope.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <ExpenseModal
        open={expenseModalOpen}
        defaultTripId={selectedTripScope !== 'all' ? selectedTripScope : undefined}
        editingExpense={editingExpense}
        onClose={() => {
          setExpenseModalOpen(false);
          setEditingExpense(null);
        }}
      />

      <UpiPaymentModal
        open={Boolean(upiTarget)}
        tripId={upiTarget?.tripId ?? ''}
        tripName={upiTarget?.tripName ?? ''}
        fromMember={upiTarget ? memberMap.get(upiTarget.tx.fromMemberId) : undefined}
        toMember={upiTarget ? memberMap.get(upiTarget.tx.toMemberId) : undefined}
        amountPaise={upiTarget?.tx.amountPaise ?? 0}
        onClose={() => setUpiTarget(null)}
      />
    </div>
  );
}
