import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowLeft,
  Calendar,
  Download,
  Edit3,
  Eye,
  MapPin,
  Plus,
  Trash2,
} from 'lucide-react';
import { CategoryIcon } from '../components/CategoryIcon';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { ExpenseModal } from '../components/ExpenseModal';
import { MemberAvatar } from '../components/MemberAvatar';
import { ReceiptPreviewModal } from '../components/ReceiptPreviewModal';
import { TripModal } from '../components/TripModal';
import { UpiPaymentModal } from '../components/UpiPaymentModal';
import { useTripTally } from '../context/TripTallyContext';
import { exportTripFinancialPdf } from '../services/pdfReport';
import type { Expense, Member, SimplifiedDebt } from '../types';
import {
  computeBudgetAlert,
  formatDateShort,
  formatINR,
  runDebtSimplification,
} from '../utils/finance';

export function TripDetailPage() {
  const { tripId } = useParams<{ tripId: string }>();
  const navigate = useNavigate();
  const { state, deleteExpense, removeReceiptFromExpense, pushToast } = useTripTally();

  const [activeTab, setActiveTab] = useState<'expenses' | 'ledger' | 'settlements'>(
    'expenses'
  );
  const [tripModalOpen, setTripModalOpen] = useState(false);
  const [expenseModalOpen, setExpenseModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [expenseToDelete, setExpenseToDelete] = useState<Expense | null>(null);
  const [receiptExpense, setReceiptExpense] = useState<Expense | null>(null);
  const [upiTx, setUpiTx] = useState<SimplifiedDebt | null>(null);

  const trip = useMemo(
    () => state.trips.find((t) => t.id === tripId),
    [state.trips, tripId]
  );

  const memberMap = useMemo(
    () => new Map<string, Member>(state.members.map((m) => [m.id, m])),
    [state.members]
  );

  const tripExpenses = useMemo(
    () =>
      state.expenses
        .filter((e) => e.tripId === tripId)
        .sort((a, b) => b.date.localeCompare(a.date)),
    [state.expenses, tripId]
  );

  const tripSettlements = useMemo(
    () => state.settlements.filter((s) => s.tripId === tripId),
    [state.settlements, tripId]
  );

  if (!trip) {
    return (
      <div className="rounded-xl border border-[#E5E3F3] bg-white p-10 text-center">
        <h2 className="font-display text-lg font-bold text-[#101828]">Trip Not Found</h2>
        <p className="mt-1 text-xs text-[#525870]">
          This trip may have been deleted or moved.
        </p>
        <button
          type="button"
          onClick={() => navigate('/trips')}
          className="mt-4 rounded-lg bg-[#7047EB] px-4 py-2 text-xs font-semibold text-white"
        >
          Back to My Trips
        </button>
      </div>
    );
  }

  const totalSpentPaise = tripExpenses.reduce((acc, e) => acc + e.amountPaise, 0);
  const budgetAlert = computeBudgetAlert(trip, totalSpentPaise);
  const sim = runDebtSimplification(
    trip.memberIds,
    state.members,
    tripExpenses,
    tripSettlements
  );

  const handleExportPdf = () => {
    exportTripFinancialPdf({
      trip,
      members: state.members,
      expenses: state.expenses,
      settlements: state.settlements,
    });
    pushToast({
      type: 'success',
      title: 'PDF Financial Report Exported',
      description: `Downloaded statement for ${trip.name}.`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link
          to="/trips"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#525870] hover:text-[#101828]"
        >
          <ArrowLeft size={14} /> Back to My Trips
        </Link>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleExportPdf}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-xs font-semibold text-[#101828] hover:bg-[#F6F5FC]"
          >
            <Download size={14} /> Export PDF Report
          </button>
          <button
            type="button"
            onClick={() => setTripModalOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-xs font-semibold text-[#101828] hover:bg-[#F6F5FC]"
          >
            <Edit3 size={14} /> Edit Trip
          </button>
          <button
            type="button"
            onClick={() => {
              setEditingExpense(null);
              setExpenseModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#7047EB] px-4 py-2 text-xs font-semibold text-white hover:bg-[#5B34D6]"
          >
            <Plus size={14} /> Add Expense
          </button>
        </div>
      </div>

      {/* Hero Trip Banner */}
      <div className="overflow-hidden rounded-xl border border-[#E5E3F3] bg-white">
        <div className="relative h-52 bg-slate-200">
          <img
            src={trip.coverImage}
            alt={trip.name}
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#101828]/85 via-[#101828]/40 to-transparent" />
          <div className="absolute right-6 bottom-5 left-6 flex flex-wrap items-end justify-between gap-4 text-white">
            <div>
              <h2 className="font-display text-2xl font-extrabold">{trip.name}</h2>
              <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-slate-200">
                <span className="inline-flex items-center gap-1">
                  <MapPin size={13} /> {trip.destination}
                </span>
                <span aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1 tabular-nums">
                  <Calendar size={13} /> {formatDateShort(trip.startDate)} –{' '}
                  {formatDateShort(trip.endDate)}
                </span>
                <span aria-hidden="true">·</span>
                <span>{trip.memberIds.length} travelers</span>
              </div>
            </div>
            <div className="flex -space-x-2">
              {trip.memberIds.map((id) => (
                <MemberAvatar key={id} member={memberMap.get(id)} size="md" />
              ))}
            </div>
          </div>
        </div>

        {/* Budget Progress & KPIs */}
        <div className="grid grid-cols-2 gap-4 border-b border-[#EFEFF7] p-6 sm:grid-cols-4">
          <div>
            <p className="text-xs text-[#525870]">Allocated Budget</p>
            <p className="font-mono-tabular mt-1 text-lg font-bold text-[#101828]">
              {formatINR(trip.budgetPaise)}
            </p>
          </div>
          <div>
            <p className="text-xs text-[#525870]">Total Spending</p>
            <p className="font-mono-tabular mt-1 text-lg font-bold text-[#7047EB]">
              {formatINR(totalSpentPaise)}
            </p>
          </div>
          <div>
            <p className="text-xs text-[#525870]">Remaining Budget</p>
            <p
              className={`font-mono-tabular mt-1 text-lg font-bold ${
                budgetAlert.remainingPaise < 0 ? 'text-[#EF5350]' : 'text-[#16A36A]'
              }`}
            >
              {formatINR(budgetAlert.remainingPaise)}
            </p>
          </div>
          <div>
            <p className="text-xs text-[#525870]">Simplified Settlements</p>
            <p className="font-mono-tabular mt-1 text-lg font-bold text-[#101828]">
              {sim.simplifiedTransactions.length} pending
            </p>
          </div>
        </div>

        <div className="bg-[#F6F5FC]/60 px-6 py-4">
          <div className="mb-1.5 flex items-center justify-between text-xs">
            <span className="inline-flex items-center gap-1.5 font-semibold text-[#101828]">
              {budgetAlert.level !== 'nominal' && (
                <AlertTriangle
                  size={14}
                  className={
                    budgetAlert.level === 'exceeded' || budgetAlert.level === 'limit100'
                      ? 'text-[#EF5350]'
                      : 'text-[#F5A623]'
                  }
                />
              )}
              {budgetAlert.title}
            </span>
            <span className="font-mono-tabular font-semibold text-[#525870]">
              {budgetAlert.utilizationPercent.toFixed(1)}% used
            </span>
          </div>
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-[#E5E3F3]">
            <div
              className={`h-full rounded-full ${
                budgetAlert.level === 'exceeded' || budgetAlert.level === 'limit100'
                  ? 'bg-[#EF5350]'
                  : budgetAlert.level === 'warning90' || budgetAlert.level === 'warning75'
                  ? 'bg-[#F5A623]'
                  : 'bg-[#16A36A]'
              }`}
              style={{ width: `${Math.min(100, budgetAlert.utilizationPercent)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Sub-Tabs */}
      <div className="inline-flex rounded-lg border border-[#E5E3F3] bg-white p-1">
        {(
          [
            { id: 'expenses', label: `Expenses (${tripExpenses.length})` },
            { id: 'ledger', label: 'Member Ledger' },
            {
              id: 'settlements',
              label: `Simplified Settlements (${sim.simplifiedTransactions.length})`,
            },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`rounded-md px-4 py-2 text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === tab.id
                ? 'bg-[#101828] text-white'
                : 'text-[#525870] hover:text-[#101828]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'expenses' && (
        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] border-collapse text-left">
              <thead>
                <tr className="border-b border-[#EFEFF7] text-xs font-semibold text-[#525870]">
                  <th className="py-3 pr-4">Expense Name</th>
                  <th className="py-3 pr-4">Category</th>
                  <th className="py-3 pr-4">Paid By</th>
                  <th className="py-3 pr-4">Split</th>
                  <th className="py-3 pr-4">Date</th>
                  <th className="py-3 pr-4 text-right">Amount</th>
                  <th className="py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EFEFF7] text-sm">
                {tripExpenses.map((exp) => {
                  const payer = memberMap.get(exp.paidByMemberId);
                  return (
                    <tr key={exp.id} className="hover:bg-[#F6F5FC]/60">
                      <td className="py-3.5 pr-4">
                        <p className="font-semibold text-[#101828]">{exp.title}</p>
                        {exp.notes && (
                          <p className="max-w-xs truncate text-xs text-[#525870]">
                            {exp.notes}
                          </p>
                        )}
                      </td>
                      <td className="py-3.5 pr-4">
                        <CategoryIcon category={exp.category} showLabel />
                      </td>
                      <td className="py-3.5 pr-4 text-xs font-medium text-[#202438]">
                        <span className="inline-flex items-center gap-2">
                          <MemberAvatar member={payer} size="xs" />
                          {payer?.name}
                        </span>
                      </td>
                      <td className="tabular-nums py-3.5 pr-4 text-xs text-[#525870]">
                        {exp.splitType.toUpperCase()} · {exp.participantIds.length}
                      </td>
                      <td className="tabular-nums py-3.5 pr-4 text-xs text-[#525870]">
                        {formatDateShort(exp.date)}
                      </td>
                      <td className="font-mono-tabular py-3.5 pr-4 text-right font-bold text-[#101828]">
                        {formatINR(exp.amountPaise)}
                      </td>
                      <td className="py-3.5 text-right">
                        <div className="inline-flex items-center gap-1">
                          {exp.receipt && (
                            <button
                              type="button"
                              onClick={() => setReceiptExpense(exp)}
                              className="rounded-lg p-1.5 text-[#3478F6] hover:bg-[#3478F6]/10"
                              title="View Receipt"
                            >
                              <Eye size={15} />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              setEditingExpense(exp);
                              setExpenseModalOpen(true);
                            }}
                            className="rounded-lg p-1.5 text-[#525870] hover:bg-[#F6F5FC] hover:text-[#101828]"
                            title="Edit Expense"
                          >
                            <Edit3 size={15} />
                          </button>
                          <button
                            type="button"
                            onClick={() => setExpenseToDelete(exp)}
                            className="rounded-lg p-1.5 text-[#EF5350] hover:bg-[#EF5350]/10"
                            title="Delete Expense"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {tripExpenses.length === 0 && (
                  <tr>
                    <td colSpan={7} className="py-10 text-center text-xs text-[#525870]">
                      No expenses recorded for {trip.name} yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'ledger' && (
        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] border-collapse text-left">
              <thead>
                <tr className="border-b border-[#EFEFF7] text-xs font-semibold text-[#525870]">
                  <th className="py-3 pr-4">Member</th>
                  <th className="py-3 pr-4 text-right">Total Paid</th>
                  <th className="py-3 pr-4 text-right">Total Share</th>
                  <th className="py-3 pr-4 text-right">Settled Adj.</th>
                  <th className="py-3 pr-4 text-right">Net Balance</th>
                  <th className="py-3 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EFEFF7] text-sm">
                {sim.balances.map((b) => (
                  <tr key={b.memberId}>
                    <td className="py-3.5 pr-4">
                      <div className="flex items-center gap-2.5">
                        <MemberAvatar member={b.member} size="sm" />
                        <div>
                          <p className="font-semibold text-[#101828]">{b.member.name}</p>
                          <p className="text-xs text-[#525870]">{b.member.upiId}</p>
                        </div>
                      </div>
                    </td>
                    <td className="font-mono-tabular py-3.5 pr-4 text-right text-[#101828]">
                      {formatINR(b.totalPaidPaise)}
                    </td>
                    <td className="font-mono-tabular py-3.5 pr-4 text-right text-[#525870]">
                      {formatINR(b.totalSharePaise)}
                    </td>
                    <td className="font-mono-tabular py-3.5 pr-4 text-right text-[#525870]">
                      {formatINR(b.settledOutPaise - b.settledInPaise)}
                    </td>
                    <td
                      className={`font-mono-tabular py-3.5 pr-4 text-right font-bold ${
                        b.status === 'owed'
                          ? 'text-[#16A36A]'
                          : b.status === 'owes'
                          ? 'text-[#EF5350]'
                          : 'text-[#525870]'
                      }`}
                    >
                      {b.netBalancePaise > 0 ? '+' : ''}
                      {formatINR(b.netBalancePaise)}
                    </td>
                    <td className="py-3.5 text-right text-xs font-semibold">
                      <span
                        className={
                          b.status === 'owed'
                            ? 'text-[#16A36A]'
                            : b.status === 'owes'
                            ? 'text-[#EF5350]'
                            : 'text-[#525870]'
                        }
                      >
                        {b.status === 'owed'
                          ? 'Owed to Member'
                          : b.status === 'owes'
                          ? 'Owes Group'
                          : 'Settled'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'settlements' && (
        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
          {sim.simplifiedTransactions.length === 0 ? (
            <div className="py-10 text-center">
              <p className="text-sm font-bold text-[#16A36A]">
                Everyone in {trip.name} is settled!
              </p>
            </div>
          ) : (
            <div className="divide-y divide-[#EFEFF7]">
              {sim.simplifiedTransactions.map((tx) => {
                const fromM = memberMap.get(tx.fromMemberId);
                const toM = memberMap.get(tx.toMemberId);
                return (
                  <div
                    key={tx.id}
                    className="flex flex-wrap items-center justify-between gap-4 py-4"
                  >
                    <div className="flex items-center gap-3">
                      <MemberAvatar member={fromM} size="sm" />
                      <div>
                        <p className="text-sm font-bold text-[#101828]">
                          {fromM?.name} pays {toM?.name}
                        </p>
                        <p className="text-xs text-[#525870]">Payee UPI: {toM?.upiId}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-mono-tabular text-base font-bold text-[#7047EB]">
                        {formatINR(tx.amountPaise)}
                      </span>
                      <button
                        type="button"
                        onClick={() => setUpiTx(tx)}
                        className="rounded-lg bg-[#7047EB] px-4 py-2 text-xs font-semibold text-white hover:bg-[#5B34D6]"
                      >
                        Pay & Mark Paid
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      <TripModal
        open={tripModalOpen}
        editingTrip={trip}
        onClose={() => setTripModalOpen(false)}
      />

      <ExpenseModal
        open={expenseModalOpen}
        defaultTripId={trip.id}
        editingExpense={editingExpense}
        onClose={() => {
          setExpenseModalOpen(false);
          setEditingExpense(null);
        }}
      />

      <ReceiptPreviewModal
        expense={receiptExpense}
        onClose={() => setReceiptExpense(null)}
        onDeleteReceipt={removeReceiptFromExpense}
      />

      <UpiPaymentModal
        open={Boolean(upiTx)}
        tripId={trip.id}
        tripName={trip.name}
        fromMember={upiTx ? memberMap.get(upiTx.fromMemberId) : undefined}
        toMember={upiTx ? memberMap.get(upiTx.toMemberId) : undefined}
        amountPaise={upiTx?.amountPaise ?? 0}
        onClose={() => setUpiTx(null)}
      />

      <ConfirmDialog
        open={Boolean(expenseToDelete)}
        title="Delete Expense?"
        description={`Are you sure you want to delete "${expenseToDelete?.title}"? Group balances will recalculate automatically.`}
        confirmLabel="Delete Expense"
        onCancel={() => setExpenseToDelete(null)}
        onConfirm={() => {
          if (expenseToDelete) deleteExpense(expenseToDelete.id);
          setExpenseToDelete(null);
        }}
      />
    </div>
  );
}
