import React, { useMemo, useState } from 'react';
import { Edit3, Info, Plus, Trash2, UserPlus, X } from 'lucide-react';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { MemberAvatar } from '../components/MemberAvatar';
import { useTripTally } from '../context/TripTallyContext';
import type { Member } from '../types';
import { computeTripBalances, formatINR } from '../utils/finance';

export function MembersPage() {
  const { state, addMember, updateMember, deleteMember } = useTripTally();

  const [tripScope, setTripScope] = useState<string>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [memberToDelete, setMemberToDelete] = useState<Member | null>(null);
  const [explainedMemberId, setExplainedMemberId] = useState<string | null>(null);

  // Member form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [upiId, setUpiId] = useState('');
  const [assignTripId, setAssignTripId] = useState('');
  const [formError, setFormError] = useState('');

  const openAddModal = () => {
    setEditingMember(null);
    setName('');
    setEmail('');
    setUpiId('');
    setAssignTripId(state.trips[0]?.id ?? '');
    setFormError('');
    setModalOpen(true);
  };

  const openEditModal = (m: Member) => {
    setEditingMember(m);
    setName(m.name);
    setEmail(m.email);
    setUpiId(m.upiId);
    setAssignTripId('');
    setFormError('');
    setModalOpen(true);
  };

  const handleSaveMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) {
      setFormError('Name and email address are required.');
      return;
    }
    const cleanUpi =
      upiId.trim() || `${name.trim().toLowerCase().replace(/[^a-z0-9]/g, '.')}@okaxis`;

    if (editingMember) {
      updateMember(editingMember.id, {
        name: name.trim(),
        email: email.trim(),
        upiId: cleanUpi,
      });
    } else {
      addMember(
        {
          name: name.trim(),
          email: email.trim(),
          upiId: cleanUpi,
          avatarColor: '#7047EB',
        },
        assignTripId || undefined
      );
    }
    setModalOpen(false);
  };

  const memberMap = useMemo(
    () => new Map<string, Member>(state.members.map((m) => [m.id, m])),
    [state.members]
  );

  const ledgerRows = useMemo(() => {
    const scopedExpenses =
      tripScope === 'all'
        ? state.expenses
        : state.expenses.filter((e) => e.tripId === tripScope);
    const scopedPaidSettlements =
      tripScope === 'all'
        ? state.settlements.filter((s) => s.status === 'paid')
        : state.settlements.filter((s) => s.tripId === tripScope && s.status === 'paid');

    const selectedTrip = state.trips.find((t) => t.id === tripScope);
    const memberIds = selectedTrip
      ? selectedTrip.memberIds
      : state.members.map((m) => m.id);

    return computeTripBalances(
      memberIds,
      memberMap,
      scopedExpenses,
      scopedPaidSettlements
    );
  }, [tripScope, state.expenses, state.settlements, state.trips, state.members, memberMap]);

  const explainedRow = useMemo(
    () => ledgerRows.find((r) => r.memberId === explainedMemberId) ?? null,
    [ledgerRows, explainedMemberId]
  );

  const explainedExpenses = useMemo(() => {
    if (!explainedMemberId) return [];
    return state.expenses.filter((e) => {
      if (tripScope !== 'all' && e.tripId !== tripScope) return false;
      return (
        e.paidByMemberId === explainedMemberId ||
        e.splits.some((s) => s.memberId === explainedMemberId && s.amountPaise > 0)
      );
    });
  }, [explainedMemberId, state.expenses, tripScope]);

  return (
    <div className="space-y-6">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <label className="text-xs font-semibold text-[#525870]">Ledger Scope:</label>
          <select
            value={tripScope}
            onChange={(e) => setTripScope(e.target.value)}
            className="rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-xs font-semibold text-[#101828] outline-none focus:border-[#7047EB]"
          >
            <option value="all">All Trips Combined</option>
            {state.trips.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={openAddModal}
          className="inline-flex items-center gap-1.5 rounded-lg bg-[#7047EB] px-4 py-2 text-xs font-semibold whitespace-nowrap text-white shadow-sm hover:bg-[#5B34D6]"
        >
          <UserPlus size={15} /> Add Member
        </button>
      </div>

      {/* Member Directory & Financial Ledger Table */}
      <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
        <div className="mb-4">
          <h2 className="font-display text-base font-bold text-[#101828]">
            Member Directory & Individual Balances
          </h2>
          <p className="text-xs text-[#525870]">
            Green indicates money owed to the member. Red indicates money the member owes
            the group.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] border-collapse text-left">
            <thead>
              <tr className="border-b border-[#EFEFF7] text-xs font-semibold text-[#525870]">
                <th className="py-3 pr-4">Member Name</th>
                <th className="py-3 pr-4">Email & UPI</th>
                <th className="py-3 pr-4 text-right">Total Paid</th>
                <th className="py-3 pr-4 text-right">Total Share</th>
                <th className="py-3 pr-4 text-right">Net Balance</th>
                <th className="py-3 pr-4">Settlement Status</th>
                <th className="py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EFEFF7] text-sm">
              {ledgerRows.map((row) => (
                <tr key={row.memberId} className="hover:bg-[#F6F5FC]/60">
                  <td className="py-3.5 pr-4">
                    <div className="flex items-center gap-3">
                      <MemberAvatar member={row.member} size="sm" />
                      <div>
                        <p className="font-semibold text-[#101828]">{row.member.name}</p>
                        <p className="tabular-nums text-xs text-[#525870]">
                          {row.paidExpenseCount} paid · {row.participatedExpenseCount} shared
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 pr-4">
                    <p className="text-xs text-[#202438]">{row.member.email}</p>
                    <p className="font-mono-tabular text-[11px] text-[#525870]">
                      {row.member.upiId}
                    </p>
                  </td>
                  <td className="font-mono-tabular py-3.5 pr-4 text-right font-semibold text-[#101828]">
                    {formatINR(row.totalPaidPaise)}
                  </td>
                  <td className="font-mono-tabular py-3.5 pr-4 text-right text-[#525870]">
                    {formatINR(row.totalSharePaise)}
                  </td>
                  <td
                    className={`font-mono-tabular py-3.5 pr-4 text-right font-bold ${
                      row.status === 'owed'
                        ? 'text-[#16A36A]'
                        : row.status === 'owes'
                        ? 'text-[#EF5350]'
                        : 'text-[#525870]'
                    }`}
                  >
                    {row.netBalancePaise > 0 ? '+' : ''}
                    {formatINR(row.netBalancePaise)}
                  </td>
                  <td className="py-3.5 pr-4">
                    <span
                      className={`text-xs font-semibold ${
                        row.status === 'owed'
                          ? 'text-[#16A36A]'
                          : row.status === 'owes'
                          ? 'text-[#EF5350]'
                          : 'text-[#525870]'
                      }`}
                    >
                      {row.status === 'owed'
                        ? 'Receives Reimbursement'
                        : row.status === 'owes'
                        ? 'Owes Settlement'
                        : 'Settled'}
                    </span>
                  </td>
                  <td className="py-3.5 text-right">
                    <div className="inline-flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() =>
                          setExplainedMemberId((prev) =>
                            prev === row.memberId ? null : row.memberId
                          )
                        }
                        className="rounded-lg p-1.5 text-[#3478F6] hover:bg-[#3478F6]/10"
                        title="Explain Balance Calculation"
                      >
                        <Info size={15} />
                      </button>
                      <button
                        type="button"
                        onClick={() => openEditModal(row.member)}
                        className="rounded-lg p-1.5 text-[#525870] hover:bg-[#F6F5FC] hover:text-[#101828]"
                        title="Edit Member"
                      >
                        <Edit3 size={15} />
                      </button>
                      <button
                        type="button"
                        onClick={() => setMemberToDelete(row.member)}
                        className="rounded-lg p-1.5 text-[#EF5350] hover:bg-[#EF5350]/10"
                        title="Remove Member"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detailed Calculation Explanation Panel */}
      {explainedRow && (
        <div className="rounded-xl border border-[#7047EB]/30 bg-white p-6">
          <div className="flex items-start justify-between gap-4 border-b border-[#EFEFF7] pb-4">
            <div className="flex items-center gap-3">
              <MemberAvatar member={explainedRow.member} size="md" />
              <div>
                <h3 className="font-display text-base font-bold text-[#101828]">
                  Balance Audit for {explainedRow.member.name}
                </h3>
                <p className="font-mono-tabular mt-0.5 text-xs text-[#525870]">
                  Formula: Total Paid ({formatINR(explainedRow.totalPaidPaise)}) − Total
                  Share ({formatINR(explainedRow.totalSharePaise)}) + Paid Settlements (
                  {formatINR(explainedRow.settledOutPaise)}) − Received Settlements (
                  {formatINR(explainedRow.settledInPaise)}) ={' '}
                  <strong className="text-[#101828]">
                    {explainedRow.netBalancePaise > 0 ? '+' : ''}
                    {formatINR(explainedRow.netBalancePaise)}
                  </strong>
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setExplainedMemberId(null)}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-[#F6F5FC] hover:text-[#101828]"
            >
              <X size={16} />
            </button>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[540px] border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-[#EFEFF7] font-semibold text-[#525870]">
                  <th className="py-2 pr-3">Expense</th>
                  <th className="py-2 pr-3 text-right">Paid by Member</th>
                  <th className="py-2 pr-3 text-right">Member&apos;s Share</th>
                  <th className="py-2 text-right">Net Impact</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EFEFF7]">
                {explainedExpenses.map((exp) => {
                  const paid =
                    exp.paidByMemberId === explainedRow.memberId ? exp.amountPaise : 0;
                  const share =
                    exp.splits.find((s) => s.memberId === explainedRow.memberId)
                      ?.amountPaise ?? 0;
                  const impact = paid - share;
                  return (
                    <tr key={exp.id}>
                      <td className="py-2.5 pr-3 font-medium text-[#101828]">
                        {exp.title}
                      </td>
                      <td className="font-mono-tabular py-2.5 pr-3 text-right text-[#16A36A]">
                        {paid > 0 ? `+${formatINR(paid)}` : '—'}
                      </td>
                      <td className="font-mono-tabular py-2.5 pr-3 text-right text-[#EF5350]">
                        {share > 0 ? `-${formatINR(share)}` : '—'}
                      </td>
                      <td
                        className={`font-mono-tabular py-2.5 text-right font-semibold ${
                          impact > 0
                            ? 'text-[#16A36A]'
                            : impact < 0
                            ? 'text-[#EF5350]'
                            : 'text-[#525870]'
                        }`}
                      >
                        {impact > 0 ? '+' : ''}
                        {formatINR(impact)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Member Modal */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#101828]/50 p-4 backdrop-blur-[2px]"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md rounded-xl border border-[#E5E3F3] bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#EFEFF7] pb-3">
              <h2 className="font-display text-lg font-bold text-[#101828]">
                {editingMember ? 'Edit Member' : 'Add Group Member'}
              </h2>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-[#F6F5FC]"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveMember} className="mt-4 space-y-4">
              {formError && (
                <div className="rounded-lg border border-[#EF5350]/30 bg-[#EF5350]/10 px-3 py-2 text-xs text-[#C62828]">
                  {formError}
                </div>
              )}

              <div>
                <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Arjun Mehta"
                  className="w-full rounded-lg border border-[#E5E3F3] px-3.5 py-2 text-sm text-[#101828] outline-none focus:border-[#7047EB]"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="arjun.mehta@college.edu"
                  className="w-full rounded-lg border border-[#E5E3F3] px-3.5 py-2 text-sm text-[#101828] outline-none focus:border-[#7047EB]"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                  UPI ID (for settlements)
                </label>
                <input
                  type="text"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  placeholder="arjun.mehta@okaxis"
                  className="font-mono-tabular w-full rounded-lg border border-[#E5E3F3] px-3.5 py-2 text-sm text-[#101828] outline-none focus:border-[#7047EB]"
                />
              </div>

              {!editingMember && state.trips.length > 0 && (
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                    Assign to Trip
                  </label>
                  <select
                    value={assignTripId}
                    onChange={(e) => setAssignTripId(e.target.value)}
                    className="w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm text-[#101828] outline-none focus:border-[#7047EB]"
                  >
                    <option value="">Directory only (do not add to a trip yet)</option>
                    {state.trips.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="flex justify-end gap-3 border-t border-[#EFEFF7] pt-4">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="rounded-lg border border-[#E5E3F3] px-4 py-2 text-xs font-semibold text-[#202438] hover:bg-[#F6F5FC]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#7047EB] px-4 py-2 text-xs font-semibold text-white hover:bg-[#5B34D6]"
                >
                  <Plus size={14} />
                  {editingMember ? 'Save Changes' : 'Add Member'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(memberToDelete)}
        title="Remove Member?"
        description={`Remove ${memberToDelete?.name} from the group directory? Members who appear in existing expenses cannot be removed until those expenses are updated.`}
        confirmLabel="Remove Member"
        onCancel={() => setMemberToDelete(null)}
        onConfirm={() => {
          if (memberToDelete) deleteMember(memberToDelete.id);
          setMemberToDelete(null);
        }}
      />
    </div>
  );
}
