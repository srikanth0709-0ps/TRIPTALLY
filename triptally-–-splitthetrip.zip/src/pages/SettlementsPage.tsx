import { useMemo, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  History,
  Info,
  RotateCcw,
  Smartphone,
  Sparkles,
} from 'lucide-react';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { MemberAvatar } from '../components/MemberAvatar';
import { UpiPaymentModal } from '../components/UpiPaymentModal';
import { useTripTally } from '../context/TripTallyContext';
import type { Member, SettlementRecord, SimplifiedDebt } from '../types';
import { formatDateShort, formatINR, runDebtSimplification } from '../utils/finance';

export function SettlementsPage() {
  const { state, revertSettlement, pushToast } = useTripTally();

  const [selectedTripId, setSelectedTripId] = useState<string>(
    () => state.trips[0]?.id ?? ''
  );
  const [isSimplifying, setIsSimplifying] = useState(false);
  const [upiTx, setUpiTx] = useState<SimplifiedDebt | null>(null);
  const [settlementToRevert, setSettlementToRevert] = useState<SettlementRecord | null>(
    null
  );
  const [expandedMemberId, setExpandedMemberId] = useState<string | null>(null);

  const selectedTrip = useMemo(
    () => state.trips.find((t) => t.id === selectedTripId) ?? state.trips[0],
    [state.trips, selectedTripId]
  );

  const memberMap = useMemo(
    () => new Map<string, Member>(state.members.map((m) => [m.id, m])),
    [state.members]
  );

  const tripExpenses = useMemo(
    () =>
      selectedTrip
        ? state.expenses.filter((e) => e.tripId === selectedTrip.id)
        : [],
    [state.expenses, selectedTrip]
  );

  const tripSettlements = useMemo(
    () =>
      selectedTrip
        ? state.settlements.filter((s) => s.tripId === selectedTrip.id)
        : [],
    [state.settlements, selectedTrip]
  );

  const simplification = useMemo(() => {
    if (!selectedTrip) return null;
    return runDebtSimplification(
      selectedTrip.memberIds,
      state.members,
      tripExpenses,
      tripSettlements
    );
  }, [selectedTrip, state.members, tripExpenses, tripSettlements]);

  const handleTriggerSimplify = () => {
    setIsSimplifying(true);
    window.setTimeout(() => {
      setIsSimplifying(false);
      if (simplification) {
        pushToast({
          type: 'success',
          title: 'Cash-Flow Graph Minimized',
          description: `Reduced ${simplification.rawExpenseDebtEdges} expense debt edges into ${simplification.simplifiedTransactions.length} optimal transfers.`,
        });
      }
    }, 350);
  };

  if (!selectedTrip || !simplification) {
    return (
      <div className="rounded-xl border border-[#E5E3F3] bg-white p-12 text-center">
        <h2 className="font-display text-lg font-bold text-[#101828]">
          No Trips Available
        </h2>
        <p className="mt-1 text-xs text-[#525870]">
          Create a trip and add expenses to run the Greedy Cash-Flow Minimization Engine.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Control Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#E5E3F3] bg-white p-5">
        <div className="flex flex-wrap items-center gap-3">
          <label className="text-xs font-semibold text-[#525870]">Select Trip:</label>
          <select
            value={selectedTrip.id}
            onChange={(e) => setSelectedTripId(e.target.value)}
            className="rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-xs font-semibold text-[#101828] outline-none focus:border-[#7047EB]"
          >
            {state.trips.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} ({t.destination})
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={handleTriggerSimplify}
          className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-[#7047EB] to-[#3478F6] px-5 py-2.5 text-xs font-semibold text-white shadow-sm transition-opacity hover:opacity-95"
        >
          <Sparkles size={15} />
          {isSimplifying ? 'Recalculating Graph...' : 'Simplify Debts'}
        </button>
      </div>

      {/* Simplification Impact KPIs */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-[#E5E3F3] bg-white p-5">
          <p className="text-xs font-semibold text-[#525870]">Original Expense Debts</p>
          <p className="font-mono-tabular mt-2 text-2xl font-bold text-[#101828]">
            {simplification.rawExpenseDebtEdges}
          </p>
          <p className="mt-1 text-xs text-[#525870]">
            {simplification.pairwiseDebts.length} direct pairwise obligations
          </p>
        </div>

        <div className="rounded-xl border border-[#7047EB]/30 bg-gradient-to-br from-white to-[#F5F2FE] p-5">
          <p className="text-xs font-semibold text-[#7047EB]">
            Optimized Transaction Count
          </p>
          <p className="font-mono-tabular mt-2 text-2xl font-bold text-[#101828]">
            {simplification.simplifiedTransactions.length}
          </p>
          <p className="mt-1 text-xs text-[#525870]">
            Minimum transfers via Greedy Cash-Flow
          </p>
        </div>

        <div className="rounded-xl border border-[#E5E3F3] bg-white p-5">
          <p className="text-xs font-semibold text-[#525870]">Total Settlement Volume</p>
          <p className="font-mono-tabular mt-2 text-2xl font-bold text-[#101828]">
            {formatINR(simplification.totalSettlementVolumePaise)}
          </p>
          <p className="mt-1 text-xs text-[#525870]">Remaining net cash to move</p>
        </div>

        <div className="rounded-xl border border-[#E5E3F3] bg-white p-5">
          <p className="text-xs font-semibold text-[#525870]">Transaction Reduction</p>
          <p className="font-mono-tabular mt-2 text-2xl font-bold text-[#16A36A]">
            {simplification.reductionPercent}%
          </p>
          <p className="mt-1 text-xs text-[#525870]">Fewer payments required</p>
        </div>
      </section>

      {/* Before vs After Comparison + Instruction Cards */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Before: Unsimplified Pairwise Obligations */}
        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6 lg:col-span-5">
          <div className="mb-4 flex items-center justify-between border-b border-[#EFEFF7] pb-3">
            <div>
              <h2 className="font-display text-base font-bold text-[#101828]">
                Before: Direct Pairwise Debts
              </h2>
              <p className="text-xs text-[#525870]">
                {simplification.rawExpenseDebtEdges} raw bill edges grouped into{' '}
                {simplification.pairwiseDebts.length} pairs
              </p>
            </div>
          </div>

          {simplification.pairwiseDebts.length === 0 ? (
            <p className="py-8 text-center text-xs text-[#525870]">
              No pairwise debts exist yet.
            </p>
          ) : (
            <div className="divide-y divide-[#EFEFF7]">
              {simplification.pairwiseDebts.map((edge) => {
                const fromM = memberMap.get(edge.fromMemberId);
                const toM = memberMap.get(edge.toMemberId);
                return (
                  <div
                    key={`${edge.fromMemberId}_${edge.toMemberId}`}
                    className="flex items-center justify-between py-3 text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-[#202438]">
                        {fromM?.name.split(' ')[0]}
                      </span>
                      <ArrowRight size={13} className="text-slate-400" />
                      <span className="font-semibold text-[#202438]">
                        {toM?.name.split(' ')[0]}
                      </span>
                      <span className="tabular-nums text-[#525870]">
                        ({edge.expenseCount} bills)
                      </span>
                    </div>
                    <span className="font-mono-tabular font-semibold text-[#525870]">
                      {formatINR(edge.amountPaise)}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* After: Optimized Greedy Cash-Flow Instructions */}
        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6 lg:col-span-7">
          <div className="mb-4 flex items-center justify-between border-b border-[#EFEFF7] pb-3">
            <div>
              <h2 className="font-display text-base font-bold text-[#101828]">
                After: Optimized Settlement Plan
              </h2>
              <p className="text-xs text-[#525870]">
                Largest debtor matched with largest creditor until every balance reaches ₹0
              </p>
            </div>
          </div>

          {simplification.simplifiedTransactions.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-xl bg-[#16A36A]/8 py-12 text-center">
              <CheckCircle2 size={32} className="text-[#16A36A]" />
              <p className="mt-3 font-display text-base font-bold text-[#101828]">
                All Group Debts Are Settled
              </p>
              <p className="mt-1 text-xs text-[#525870]">
                Every member in {selectedTrip.name} has a ₹0 net balance.
              </p>
            </div>
          ) : (
            <div
              className={`space-y-3 transition-opacity duration-200 ${
                isSimplifying ? 'opacity-40' : 'opacity-100'
              }`}
            >
              {simplification.simplifiedTransactions.map((tx) => {
                const fromM = memberMap.get(tx.fromMemberId);
                const toM = memberMap.get(tx.toMemberId);
                return (
                  <div
                    key={tx.id}
                    className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#E5E3F3] bg-[#F6F5FC]/60 p-4 transition-colors hover:border-[#7047EB]/40"
                  >
                    <div className="flex items-center gap-3">
                      <MemberAvatar member={fromM} size="md" />
                      <div>
                        <p className="text-sm font-bold text-[#101828]">
                          {fromM?.name.split(' ')[0]} pays {toM?.name.split(' ')[0]}{' '}
                          <span className="font-mono-tabular text-[#7047EB]">
                            {formatINR(tx.amountPaise)}
                          </span>
                        </p>
                        <p className="text-xs text-[#525870]">
                          {fromM?.name} → {toM?.name} ({toM?.upiId})
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setUpiTx(tx)}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5E3F3] bg-white px-3 py-2 text-xs font-semibold text-[#101828] transition-colors hover:bg-[#F6F5FC]"
                      >
                        <Smartphone size={14} className="text-[#3478F6]" />
                        Pay via UPI
                      </button>
                      <button
                        type="button"
                        onClick={() => setUpiTx(tx)}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-[#16A36A] px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#138A59]"
                      >
                        <CheckCircle2 size={14} />
                        Mark as Paid
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Individual Financial Ledger */}
      <section className="rounded-xl border border-[#E5E3F3] bg-white p-6">
        <div className="mb-4">
          <h2 className="font-display text-base font-bold text-[#101828]">
            Individual Balance Ledger
          </h2>
          <p className="text-xs text-[#525870]">
            Net Balance = Total Paid − Total Share + Outgoing Settlements − Incoming
            Settlements
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] border-collapse text-left">
            <thead>
              <tr className="border-b border-[#EFEFF7] text-xs font-semibold text-[#525870]">
                <th className="py-3 pr-4">Member</th>
                <th className="py-3 pr-4 text-right">Total Paid</th>
                <th className="py-3 pr-4 text-right">Total Share</th>
                <th className="py-3 pr-4 text-right">Net Balance</th>
                <th className="py-3 pr-4">Status</th>
                <th className="py-3 text-right">Settlement Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EFEFF7] text-sm">
              {simplification.balances.map((b) => {
                const relatedTx = simplification.simplifiedTransactions.find(
                  (tx) => tx.fromMemberId === b.memberId
                );
                const isExpanded = expandedMemberId === b.memberId;

                return (
                  <tr key={b.memberId} className="hover:bg-[#F6F5FC]/60">
                    <td className="py-3.5 pr-4">
                      <div className="flex items-center gap-2.5">
                        <MemberAvatar member={b.member} size="sm" />
                        <div>
                          <p className="font-semibold text-[#101828]">{b.member.name}</p>
                          <button
                            type="button"
                            onClick={() =>
                              setExpandedMemberId(isExpanded ? null : b.memberId)
                            }
                            className="inline-flex items-center gap-1 text-[11px] font-medium text-[#3478F6] hover:underline"
                          >
                            <Info size={11} />
                            {isExpanded ? 'Hide formula' : 'How calculated?'}
                          </button>
                          {isExpanded && (
                            <p className="font-mono-tabular mt-1 text-[11px] text-[#525870]">
                              Paid {formatINR(b.totalPaidPaise)} − Share{' '}
                              {formatINR(b.totalSharePaise)} + Settled{' '}
                              {formatINR(b.settledOutPaise - b.settledInPaise)} ={' '}
                              {formatINR(b.netBalancePaise)}
                            </p>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="font-mono-tabular py-3.5 pr-4 text-right font-semibold text-[#101828]">
                      {formatINR(b.totalPaidPaise)}
                    </td>
                    <td className="font-mono-tabular py-3.5 pr-4 text-right text-[#525870]">
                      {formatINR(b.totalSharePaise)}
                    </td>
                    <td
                      className={`font-mono-tabular py-3.5 pr-4 text-right font-bold ${
                        b.status === 'owed'
                          ? 'text-[#16A36A]'
                          : b.status === 'owes'
                          ? 'text-[#EF5350]'
                          : 'text-[#525870]'
                      }`}
                    >
                      {b.netBalancePaise > 0 ? '+' : ''}
                      {formatINR(b.netBalancePaise)}
                    </td>
                    <td className="py-3.5 pr-4 text-xs font-semibold">
                      <span
                        className={
                          b.status === 'owed'
                            ? 'text-[#16A36A]'
                            : b.status === 'owes'
                            ? 'text-[#EF5350]'
                            : 'text-[#525870]'
                        }
                      >
                        {b.status === 'owed'
                          ? 'Owed to Member'
                          : b.status === 'owes'
                          ? 'Owes Group'
                          : 'Settled'}
                      </span>
                    </td>
                    <td className="py-3.5 text-right">
                      {relatedTx ? (
                        <button
                          type="button"
                          onClick={() => setUpiTx(relatedTx)}
                          className="rounded-lg bg-[#7047EB] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#5B34D6]"
                        >
                          Pay {memberMap.get(relatedTx.toMemberId)?.name.split(' ')[0]}{' '}
                          {formatINR(relatedTx.amountPaise)}
                        </button>
                      ) : b.status === 'owed' ? (
                        <span className="text-xs text-[#16A36A]">
                          Awaiting incoming payment
                        </span>
                      ) : (
                        <span className="text-xs text-[#525870]">Cleared</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* Settlement History */}
      <section className="rounded-xl border border-[#E5E3F3] bg-white p-6">
        <div className="mb-4 flex items-center gap-2">
          <History size={17} className="text-[#7047EB]" />
          <h2 className="font-display text-base font-bold text-[#101828]">
            Completed Settlement History ({tripSettlements.length})
          </h2>
        </div>

        {tripSettlements.length === 0 ? (
          <p className="py-6 text-center text-xs text-[#525870]">
            No settlements have been marked as paid for {selectedTrip.name} yet.
          </p>
        ) : (
          <div className="divide-y divide-[#EFEFF7]">
            {tripSettlements.map((st) => {
              const fromM = memberMap.get(st.fromMemberId);
              const toM = memberMap.get(st.toMemberId);
              return (
                <div
                  key={st.id}
                  className="flex flex-wrap items-center justify-between gap-3 py-3"
                >
                  <div>
                    <p className="text-sm font-semibold text-[#101828]">
                      {fromM?.name} paid {toM?.name} ·{' '}
                      <span className="font-mono-tabular text-[#16A36A]">
                        {formatINR(st.amountPaise)}
                      </span>
                    </p>
                    <p className="text-xs text-[#525870]">
                      Method: {st.method?.toUpperCase() ?? 'UPI'} ·{' '}
                      {st.paidAt ? formatDateShort(st.paidAt.slice(0, 10)) : ''}
                      {st.note ? ` · ${st.note}` : ''}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSettlementToRevert(st)}
                    className="inline-flex items-center gap-1 rounded-lg border border-[#E5E3F3] px-3 py-1.5 text-xs font-semibold text-[#525870] hover:bg-[#F6F5FC] hover:text-[#EF5350]"
                  >
                    <RotateCcw size={13} /> Revert
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <UpiPaymentModal
        open={Boolean(upiTx)}
        tripId={selectedTrip.id}
        tripName={selectedTrip.name}
        fromMember={upiTx ? memberMap.get(upiTx.fromMemberId) : undefined}
        toMember={upiTx ? memberMap.get(upiTx.toMemberId) : undefined}
        amountPaise={upiTx?.amountPaise ?? 0}
        onClose={() => setUpiTx(null)}
      />

      <ConfirmDialog
        open={Boolean(settlementToRevert)}
        title="Revert Completed Settlement?"
        description="This will remove the payment record and restore the outstanding balance in the Debt Simplification Engine."
        confirmLabel="Revert Settlement"
        onCancel={() => setSettlementToRevert(null)}
        onConfirm={() => {
          if (settlementToRevert) revertSettlement(settlementToRevert.id);
          setSettlementToRevert(null);
        }}
      />
    </div>
  );
}
