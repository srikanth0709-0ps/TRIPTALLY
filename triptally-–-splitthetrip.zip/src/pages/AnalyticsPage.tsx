import { useMemo, useState } from 'react';
import {
  BudgetUtilizationChart,
  CategoryDoughnutChart,
  DailySpendingBarChart,
  MemberContributionChart,
  MonthlySpendingLineChart,
} from '../components/AnalyticsCharts';
import { useTripTally } from '../context/TripTallyContext';
import type { Member } from '../types';
import { computeTripBalances, formatINR } from '../utils/finance';

export function AnalyticsPage() {
  const { state } = useTripTally();
  const [tripFilter, setTripFilter] = useState<string>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const memberMap = useMemo(
    () => new Map<string, Member>(state.members.map((m) => [m.id, m])),
    [state.members]
  );

  const filteredTrips = useMemo(() => {
    if (tripFilter === 'all') return state.trips;
    return state.trips.filter((t) => t.id === tripFilter);
  }, [state.trips, tripFilter]);

  const filteredExpenses = useMemo(() => {
    return state.expenses.filter((e) => {
      if (tripFilter !== 'all' && e.tripId !== tripFilter) return false;
      if (dateFrom && e.date < dateFrom) return false;
      if (dateTo && e.date > dateTo) return false;
      return true;
    });
  }, [state.expenses, tripFilter, dateFrom, dateTo]);

  const memberBalances = useMemo(() => {
    const memberIds =
      tripFilter === 'all'
        ? state.members.map((m) => m.id)
        : state.trips.find((t) => t.id === tripFilter)?.memberIds ??
          state.members.map((m) => m.id);
    const paidSettlements = state.settlements.filter(
      (s) => s.status === 'paid' && (tripFilter === 'all' || s.tripId === tripFilter)
    );
    return computeTripBalances(memberIds, memberMap, filteredExpenses, paidSettlements);
  }, [tripFilter, state.members, state.trips, state.settlements, memberMap, filteredExpenses]);

  const totalSpendPaise = filteredExpenses.reduce((acc, e) => acc + e.amountPaise, 0);
  const avgExpensePaise =
    filteredExpenses.length > 0
      ? Math.round(totalSpendPaise / filteredExpenses.length)
      : 0;

  return (
    <div className="space-y-6">
      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#E5E3F3] bg-white p-5">
        <div className="flex flex-wrap items-center gap-3">
          <select
            value={tripFilter}
            onChange={(e) => setTripFilter(e.target.value)}
            className="rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-xs font-semibold text-[#101828] outline-none focus:border-[#7047EB]"
          >
            <option value="all">All Trips</option>
            {state.trips.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>

          <div className="flex items-center gap-2">
            <input
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              aria-label="Start date"
              className="rounded-lg border border-[#E5E3F3] bg-white px-3 py-2 text-xs tabular-nums text-[#101828] outline-none focus:border-[#7047EB]"
            />
            <span className="text-xs text-[#525870]">to</span>
            <input
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              aria-label="End date"
              className="rounded-lg border border-[#E5E3F3] bg-white px-3 py-2 text-xs tabular-nums text-[#101828] outline-none focus:border-[#7047EB]"
            />
          </div>

          {(dateFrom || dateTo || tripFilter !== 'all') && (
            <button
              type="button"
              onClick={() => {
                setTripFilter('all');
                setDateFrom('');
                setDateTo('');
              }}
              className="text-xs font-semibold text-[#7047EB] hover:underline"
            >
              Reset Filters
            </button>
          )}
        </div>

        <div className="flex items-center gap-6 text-xs">
          <div>
            <span className="text-[#525870]">Total Spend: </span>
            <strong className="font-mono-tabular text-[#101828]">
              {formatINR(totalSpendPaise)}
            </strong>
          </div>
          <div>
            <span className="text-[#525870]">Avg Expense: </span>
            <strong className="font-mono-tabular text-[#7047EB]">
              {formatINR(avgExpensePaise)}
            </strong>
          </div>
        </div>
      </div>

      {/* 5 Interactive Charts Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
          <div className="mb-4">
            <h2 className="font-display text-base font-bold text-[#101828]">
              1. Expense Category Breakdown
            </h2>
            <p className="text-xs text-[#525870]">
              Share of total spending by category
            </p>
          </div>
          <CategoryDoughnutChart expenses={filteredExpenses} />
        </div>

        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
          <div className="mb-4">
            <h2 className="font-display text-base font-bold text-[#101828]">
              2. Daily Spending Velocity
            </h2>
            <p className="text-xs text-[#525870]">
              Day-by-day expenditure totals in INR
            </p>
          </div>
          <DailySpendingBarChart expenses={filteredExpenses} />
        </div>

        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
          <div className="mb-4">
            <h2 className="font-display text-base font-bold text-[#101828]">
              3. Monthly Spending Trend
            </h2>
            <p className="text-xs text-[#525870]">
              Month-over-month group travel expenditure
            </p>
          </div>
          <MonthlySpendingLineChart expenses={filteredExpenses} />
        </div>

        <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
          <div className="mb-4">
            <h2 className="font-display text-base font-bold text-[#101828]">
              4. Member Contribution vs. Fair Share
            </h2>
            <p className="text-xs text-[#525870]">
              Comparison of out-of-pocket payments and actual consumed share
            </p>
          </div>
          <MemberContributionChart balances={memberBalances} />
        </div>
      </div>

      <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
        <div className="mb-4">
          <h2 className="font-display text-base font-bold text-[#101828]">
            5. Trip Budget Utilization
          </h2>
          <p className="text-xs text-[#525870]">
            Allocated trip budgets compared against actual group expenses
          </p>
        </div>
        <BudgetUtilizationChart trips={filteredTrips} expenses={filteredExpenses} />
      </div>
    </div>
  );
}
