import { useMemo, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Edit3,
  Eye,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import { CategoryIcon } from '../components/CategoryIcon';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { ExpenseModal } from '../components/ExpenseModal';
import { MemberAvatar } from '../components/MemberAvatar';
import { ReceiptPreviewModal } from '../components/ReceiptPreviewModal';
import { useTripTally } from '../context/TripTallyContext';
import type { Expense, ExpenseCategory, Member, Trip } from '../types';
import { ALL_CATEGORIES, formatDateShort, formatINR } from '../utils/finance';

const PAGE_SIZE = 8;

export function ExpensesPage() {
  const { state, deleteExpense, removeReceiptFromExpense } = useTripTally();

  const [search, setSearch] = useState('');
  const [tripFilter, setTripFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState<'all' | ExpenseCategory>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'amount_desc' | 'amount_asc'>(
    'date_desc'
  );
  const [page, setPage] = useState(1);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [expenseToDelete, setExpenseToDelete] = useState<Expense | null>(null);
  const [receiptExpense, setReceiptExpense] = useState<Expense | null>(null);

  const memberMap = useMemo(
    () => new Map<string, Member>(state.members.map((m) => [m.id, m])),
    [state.members]
  );

  const tripMap = useMemo(
    () => new Map<string, Trip>(state.trips.map((t) => [t.id, t])),
    [state.trips]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = state.expenses.filter((exp) => {
      if (tripFilter !== 'all' && exp.tripId !== tripFilter) return false;
      if (categoryFilter !== 'all' && exp.category !== categoryFilter) return false;
      if (dateFrom && exp.date < dateFrom) return false;
      if (dateTo && exp.date > dateTo) return false;
      if (q) {
        const payerName = memberMap.get(exp.paidByMemberId)?.name.toLowerCase() ?? '';
        const tripName = tripMap.get(exp.tripId)?.name.toLowerCase() ?? '';
        const match =
          exp.title.toLowerCase().includes(q) ||
          exp.notes.toLowerCase().includes(q) ||
          payerName.includes(q) ||
          tripName.includes(q);
        if (!match) return false;
      }
      return true;
    });

    return [...list].sort((a, b) => {
      if (sortBy === 'date_desc') return b.date.localeCompare(a.date);
      if (sortBy === 'date_asc') return a.date.localeCompare(b.date);
      if (sortBy === 'amount_desc') return b.amountPaise - a.amountPaise;
      return a.amountPaise - b.amountPaise;
    });
  }, [
    state.expenses,
    tripFilter,
    categoryFilter,
    dateFrom,
    dateTo,
    search,
    sortBy,
    memberMap,
    tripMap,
  ]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const paged = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  const filteredTotalPaise = filtered.reduce((acc, e) => acc + e.amountPaise, 0);

  return (
    <div className="space-y-6">
      {/* Header & Filter Controls */}
      <div className="rounded-xl border border-[#E5E3F3] bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-base font-bold text-[#101828]">
              Expense Ledger ({filtered.length})
            </h2>
            <p className="font-mono-tabular text-xs text-[#525870]">
              Filtered Total:{' '}
              <strong className="text-[#101828]">{formatINR(filteredTotalPaise)}</strong>
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setEditingExpense(null);
              setModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#7047EB] px-4 py-2 text-xs font-semibold whitespace-nowrap text-white shadow-sm hover:bg-[#5B34D6]"
          >
            <Plus size={15} /> Add Expense
          </button>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
          <div className="relative lg:col-span-2">
            <Search
              size={14}
              className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-slate-400"
            />
            <input
              type="search"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search title, payer, notes..."
              className="w-full rounded-lg border border-[#E5E3F3] bg-[#F6F5FC]/60 py-2 pr-3 pl-8 text-xs text-[#101828] outline-none focus:border-[#7047EB] focus:bg-white"
            />
          </div>

          <select
            value={tripFilter}
            onChange={(e) => {
              setTripFilter(e.target.value);
              setPage(1);
            }}
            className="rounded-lg border border-[#E5E3F3] bg-white px-3 py-2 text-xs text-[#101828] outline-none focus:border-[#7047EB]"
          >
            <option value="all">All Trips</option>
            {state.trips.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>

          <select
            value={categoryFilter}
            onChange={(e) => {
              setCategoryFilter(e.target.value as 'all' | ExpenseCategory);
              setPage(1);
            }}
            className="rounded-lg border border-[#E5E3F3] bg-white px-3 py-2 text-xs text-[#101828] outline-none focus:border-[#7047EB]"
          >
            <option value="all">All Categories</option>
            {ALL_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="rounded-lg border border-[#E5E3F3] bg-white px-3 py-2 text-xs text-[#101828] outline-none focus:border-[#7047EB]"
          >
            <option value="date_desc">Date: Newest First</option>
            <option value="date_asc">Date: Oldest First</option>
            <option value="amount_desc">Amount: High to Low</option>
            <option value="amount_asc">Amount: Low to High</option>
          </select>

          <div className="flex items-center gap-1.5">
            <input
              type="date"
              value={dateFrom}
              onChange={(e) => {
                setDateFrom(e.target.value);
                setPage(1);
              }}
              aria-label="Filter from date"
              className="w-1/2 rounded-lg border border-[#E5E3F3] bg-white px-2 py-2 text-[11px] tabular-nums text-[#101828] outline-none focus:border-[#7047EB]"
            />
            <input
              type="date"
              value={dateTo}
              onChange={(e) => {
                setDateTo(e.target.value);
                setPage(1);
              }}
              aria-label="Filter to date"
              className="w-1/2 rounded-lg border border-[#E5E3F3] bg-white px-2 py-2 text-[11px] tabular-nums text-[#101828] outline-none focus:border-[#7047EB]"
            />
          </div>
        </div>
      </div>

      {/* Expense Table */}
      <div className="rounded-xl border border-[#E5E3F3] bg-white p-6">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[840px] border-collapse text-left">
            <thead>
              <tr className="border-b border-[#EFEFF7] text-xs font-semibold text-[#525870]">
                <th className="py-3 pr-4">Expense Name</th>
                <th className="py-3 pr-4">Category</th>
                <th className="py-3 pr-4">Paid By</th>
                <th className="py-3 pr-4">Participants</th>
                <th className="py-3 pr-4">Split Type</th>
                <th className="py-3 pr-4">Date</th>
                <th className="py-3 pr-4 text-right">Amount</th>
                <th className="py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EFEFF7] text-sm">
              {paged.map((exp) => {
                const payer = memberMap.get(exp.paidByMemberId);
                const trip = tripMap.get(exp.tripId);
                return (
                  <tr key={exp.id} className="hover:bg-[#F6F5FC]/60">
                    <td className="py-3.5 pr-4">
                      <p className="font-semibold text-[#101828]">{exp.title}</p>
                      <p className="text-xs text-[#525870]">{trip?.name ?? 'Trip'}</p>
                    </td>
                    <td className="py-3.5 pr-4">
                      <CategoryIcon category={exp.category} showLabel />
                    </td>
                    <td className="py-3.5 pr-4 text-xs font-medium text-[#202438]">
                      <span className="inline-flex items-center gap-2">
                        <MemberAvatar member={payer} size="xs" />
                        {payer?.name}
                      </span>
                    </td>
                    <td className="py-3.5 pr-4">
                      <div className="flex items-center gap-1.5">
                        <div className="flex -space-x-1.5">
                          {exp.participantIds.slice(0, 4).map((pid) => (
                            <MemberAvatar
                              key={pid}
                              member={memberMap.get(pid)}
                              size="xs"
                            />
                          ))}
                        </div>
                        <span className="tabular-nums text-xs text-[#525870]">
                          ({exp.participantIds.length})
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 pr-4 text-xs font-semibold capitalize text-[#525870]">
                      {exp.splitType}
                    </td>
                    <td className="tabular-nums py-3.5 pr-4 text-xs text-[#525870]">
                      {formatDateShort(exp.date)}
                    </td>
                    <td className="font-mono-tabular py-3.5 pr-4 text-right font-bold text-[#101828]">
                      {formatINR(exp.amountPaise)}
                    </td>
                    <td className="py-3.5 text-right">
                      <div className="inline-flex items-center gap-1">
                        {exp.receipt && (
                          <button
                            type="button"
                            onClick={() => setReceiptExpense(exp)}
                            className="rounded-lg p-1.5 text-[#3478F6] hover:bg-[#3478F6]/10"
                            title="View Receipt"
                          >
                            <Eye size={15} />
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => {
                            setEditingExpense(exp);
                            setModalOpen(true);
                          }}
                          className="rounded-lg p-1.5 text-[#525870] hover:bg-[#F6F5FC] hover:text-[#101828]"
                          title="Edit Expense"
                        >
                          <Edit3 size={15} />
                        </button>
                        <button
                          type="button"
                          onClick={() => setExpenseToDelete(exp)}
                          className="rounded-lg p-1.5 text-[#EF5350] hover:bg-[#EF5350]/10"
                          title="Delete Expense"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {paged.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-12 text-center">
                    <p className="text-sm font-semibold text-[#101828]">
                      No Matching Expenses
                    </p>
                    <p className="mt-1 text-xs text-[#525870]">
                      Adjust your filters or log a new expense to see entries here.
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filtered.length > PAGE_SIZE && (
          <div className="mt-4 flex items-center justify-between border-t border-[#EFEFF7] pt-4">
            <p className="tabular-nums text-xs text-[#525870]">
              Showing {(currentPage - 1) * PAGE_SIZE + 1}–
              {Math.min(currentPage * PAGE_SIZE, filtered.length)} of {filtered.length}
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={currentPage <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="inline-flex items-center gap-1 rounded-lg border border-[#E5E3F3] px-3 py-1.5 text-xs font-semibold text-[#101828] disabled:opacity-40"
              >
                <ChevronLeft size={14} /> Prev
              </button>
              <span className="tabular-nums text-xs font-semibold text-[#525870]">
                Page {currentPage} of {totalPages}
              </span>
              <button
                type="button"
                disabled={currentPage >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="inline-flex items-center gap-1 rounded-lg border border-[#E5E3F3] px-3 py-1.5 text-xs font-semibold text-[#101828] disabled:opacity-40"
              >
                Next <ChevronRight size={14} />
              </button>
            </div>
          </div>
        )}
      </div>

      <ExpenseModal
        open={modalOpen}
        defaultTripId={tripFilter !== 'all' ? tripFilter : undefined}
        editingExpense={editingExpense}
        onClose={() => {
          setModalOpen(false);
          setEditingExpense(null);
        }}
      />

      <ReceiptPreviewModal
        expense={receiptExpense}
        onClose={() => setReceiptExpense(null)}
        onDeleteReceipt={removeReceiptFromExpense}
      />

      <ConfirmDialog
        open={Boolean(expenseToDelete)}
        title="Delete Expense?"
        description={`Are you sure you want to remove "${expenseToDelete?.title}"? Group balances and settlements will update automatically.`}
        confirmLabel="Delete Expense"
        onCancel={() => setExpenseToDelete(null)}
        onConfirm={() => {
          if (expenseToDelete) deleteExpense(expenseToDelete.id);
          setExpenseToDelete(null);
        }}
      />
    </div>
  );
}
