import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Archive,
  ArchiveRestore,
  Calendar,
  Edit3,
  MapPin,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { MemberAvatar } from '../components/MemberAvatar';
import { TripModal } from '../components/TripModal';
import { useTripTally } from '../context/TripTallyContext';
import type { Member, Trip } from '../types';
import { computeBudgetAlert, formatDateShort, formatINR } from '../utils/finance';

export function TripsPage() {
  const { state, deleteTrip, toggleArchiveTrip } = useTripTally();
  const [filterStatus, setFilterStatus] = useState<'active' | 'archived' | 'all'>('active');
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTrip, setEditingTrip] = useState<Trip | null>(null);
  const [tripToDelete, setTripToDelete] = useState<Trip | null>(null);

  const memberMap = useMemo(
    () => new Map<string, Member>(state.members.map((m) => [m.id, m])),
    [state.members]
  );

  const filteredTrips = useMemo(() => {
    const q = search.trim().toLowerCase();
    return state.trips.filter((t) => {
      if (filterStatus !== 'all' && t.status !== filterStatus) return false;
      if (
        q &&
        !t.name.toLowerCase().includes(q) &&
        !t.destination.toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });
  }, [state.trips, filterStatus, search]);

  return (
    <div className="space-y-6">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="inline-flex rounded-lg border border-[#E5E3F3] bg-white p-1">
            {(
              [
                { id: 'active', label: 'Active Trips' },
                { id: 'archived', label: 'Archived' },
                { id: 'all', label: 'All Trips' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilterStatus(tab.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                  filterStatus === tab.id
                    ? 'bg-[#101828] text-white'
                    : 'text-[#525870] hover:text-[#101828]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="relative">
            <Search
              size={14}
              className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-slate-400"
            />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Filter trips by name or place..."
              className="w-60 rounded-lg border border-[#E5E3F3] bg-white py-2 pr-3 pl-8 text-xs text-[#101828] outline-none focus:border-[#7047EB]"
            />
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            setEditingTrip(null);
            setModalOpen(true);
          }}
          className="inline-flex items-center gap-1.5 rounded-lg bg-[#7047EB] px-4 py-2 text-xs font-semibold whitespace-nowrap text-white shadow-sm transition-colors hover:bg-[#5B34D6]"
        >
          <Plus size={15} />
          Create New Trip
        </button>
      </div>

      {/* Trip Cards Grid */}
      {filteredTrips.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-xl border border-[#E5E3F3] bg-white px-6 py-16 text-center">
          <p className="font-display text-base font-bold text-[#101828]">
            No Trips Found
          </p>
          <p className="mt-1 max-w-md text-xs text-[#525870]">
            Create a trip to start splitting stays, travel, dining, and activities with
            your group.
          </p>
          <button
            type="button"
            onClick={() => {
              setEditingTrip(null);
              setModalOpen(true);
            }}
            className="mt-5 inline-flex items-center gap-1.5 rounded-lg bg-[#7047EB] px-4 py-2 text-xs font-semibold text-white hover:bg-[#5B34D6]"
          >
            <Plus size={14} /> Create First Trip
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3">
          {filteredTrips.map((trip) => {
            const tripExpenses = state.expenses.filter((e) => e.tripId === trip.id);
            const spentPaise = tripExpenses.reduce((acc, e) => acc + e.amountPaise, 0);
            const alert = computeBudgetAlert(trip, spentPaise);
            const tripMembers = trip.memberIds
              .map((id) => memberMap.get(id))
              .filter((m): m is Member => Boolean(m));

            return (
              <div
                key={trip.id}
                className="flex flex-col overflow-hidden rounded-xl border border-[#E5E3F3] bg-white transition-shadow hover:shadow-md"
              >
                <div className="relative h-44 bg-slate-200">
                  <img
                    src={trip.coverImage}
                    alt={trip.name}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#101828]/85 via-[#101828]/30 to-transparent" />
                  <div className="absolute top-3 right-3 flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingTrip(trip);
                        setModalOpen(true);
                      }}
                      className="rounded-lg bg-white/90 p-2 text-[#101828] backdrop-blur-sm transition-colors hover:bg-white"
                      title="Edit Trip"
                    >
                      <Edit3 size={14} />
                    </button>
                    <button
                      type="button"
                      onClick={() => toggleArchiveTrip(trip.id)}
                      className="rounded-lg bg-white/90 p-2 text-[#101828] backdrop-blur-sm transition-colors hover:bg-white"
                      title={trip.status === 'active' ? 'Archive Trip' : 'Restore Trip'}
                    >
                      {trip.status === 'active' ? (
                        <Archive size={14} />
                      ) : (
                        <ArchiveRestore size={14} />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => setTripToDelete(trip)}
                      className="rounded-lg bg-white/90 p-2 text-[#EF5350] backdrop-blur-sm transition-colors hover:bg-white"
                      title="Delete Trip"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>

                  <div className="absolute right-4 bottom-3.5 left-4 text-white">
                    <h3 className="font-display truncate text-lg font-bold">{trip.name}</h3>
                    <div className="mt-0.5 flex items-center gap-2 text-xs text-slate-200">
                      <span className="inline-flex items-center gap-1 truncate">
                        <MapPin size={12} /> {trip.destination}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums shrink-0">
                        {tripExpenses.length} expenses
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-1 flex-col justify-between p-5">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-[#525870]">
                      <span className="inline-flex items-center gap-1.5 tabular-nums">
                        <Calendar size={13} />
                        {formatDateShort(trip.startDate)} – {formatDateShort(trip.endDate)}
                      </span>
                      <span className="font-medium capitalize">{trip.status}</span>
                    </div>

                    {trip.description && (
                      <p className="line-clamp-2 text-xs leading-relaxed text-[#525870]">
                        {trip.description}
                      </p>
                    )}

                    <div className="space-y-1.5 pt-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-[#525870]">
                          Total Spending:{' '}
                          <strong className="font-mono-tabular text-[#101828]">
                            {formatINR(spentPaise)}
                          </strong>
                        </span>
                        <span className="font-mono-tabular text-[#525870]">
                          Budget {formatINR(trip.budgetPaise)}
                        </span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-[#EFEFF7]">
                        <div
                          className={`h-full rounded-full ${
                            alert.level === 'exceeded' || alert.level === 'limit100'
                              ? 'bg-[#EF5350]'
                              : alert.level === 'warning90' || alert.level === 'warning75'
                              ? 'bg-[#F5A623]'
                              : 'bg-[#7047EB]'
                          }`}
                          style={{ width: `${Math.min(100, alert.utilizationPercent)}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-mono-tabular text-[#525870]">
                          {alert.utilizationPercent.toFixed(1)}% utilized
                        </span>
                        <span
                          className={`font-mono-tabular font-semibold ${
                            alert.remainingPaise < 0
                              ? 'text-[#EF5350]'
                              : 'text-[#16A36A]'
                          }`}
                        >
                          {alert.remainingPaise >= 0
                            ? `${formatINR(alert.remainingPaise)} remaining`
                            : `${formatINR(Math.abs(alert.remainingPaise))} over budget`}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 flex items-center justify-between border-t border-[#EFEFF7] pt-3.5">
                    <div className="flex -space-x-2">
                      {tripMembers.slice(0, 5).map((m) => (
                        <MemberAvatar key={m.id} member={m} size="sm" />
                      ))}
                    </div>
                    <Link
                      to={`/trips/${trip.id}`}
                      className="rounded-lg bg-[#101828] px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-[#1E293B]"
                    >
                      View Details
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <TripModal
        open={modalOpen}
        editingTrip={editingTrip}
        onClose={() => {
          setModalOpen(false);
          setEditingTrip(null);
        }}
      />

      <ConfirmDialog
        open={Boolean(tripToDelete)}
        title="Delete Trip Permanently?"
        description={`Deleting "${tripToDelete?.name}" will also permanently remove all expenses and settlement records attached to this trip.`}
        confirmLabel="Delete Trip"
        onCancel={() => setTripToDelete(null)}
        onConfirm={() => {
          if (tripToDelete) deleteTrip(tripToDelete.id);
          setTripToDelete(null);
        }}
      />
    </div>
  );
}
