import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type {
  Expense,
  Member,
  SettlementRecord,
  Trip,
} from '../types';
import {
  ALL_CATEGORIES,
  computeBudgetAlert,
  formatDateShort,
  runDebtSimplification,
} from '../utils/finance';

function formatPdfINR(paise: number): string {
  const abs = Math.abs(Math.round(paise)) / 100;
  const hasDecimals = Math.abs(Math.round(paise)) % 100 !== 0;
  const num = new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: hasDecimals ? 2 : 0,
    maximumFractionDigits: hasDecimals ? 2 : 0,
  }).format(abs);
  return `${paise < 0 ? '-' : ''}INR ${num}`;
}

export function exportTripFinancialPdf(params: {
  trip: Trip;
  members: Member[];
  expenses: Expense[];
  settlements: SettlementRecord[];
}): void {
  const { trip, members, expenses, settlements } = params;
  const memberMap = new Map(members.map((m) => [m.id, m]));
  const tripMembers = trip.memberIds
    .map((id) => memberMap.get(id))
    .filter((m): m is Member => Boolean(m));

  const tripExpenses = expenses
    .filter((e) => e.tripId === trip.id)
    .sort((a, b) => a.date.localeCompare(b.date));

  const tripSettlements = settlements.filter((s) => s.tripId === trip.id);
  const totalSpentPaise = tripExpenses.reduce((s, e) => s + e.amountPaise, 0);
  const budgetAlert = computeBudgetAlert(trip, totalSpentPaise);
  const simplification = runDebtSimplification(
    trip.memberIds,
    members,
    tripExpenses,
    tripSettlements
  );

  const doc = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();

  // Header Banner
  doc.setFillColor(16, 24, 40); // Deep Navy #101828
  doc.rect(0, 0, pageWidth, 108, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.text('TripTally – SplitTheTrip', 40, 42);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(203, 213, 225);
  doc.text('Travel Together. Split Smarter. Settle Faster.', 40, 60);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(255, 255, 255);
  doc.text(`Financial Statement: ${trip.name}`, 40, 86);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(203, 213, 225);
  doc.text(
    `Generated ${new Date().toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    })}`,
    pageWidth - 40,
    42,
    { align: 'right' }
  );

  // Trip Details Summary
  let y = 132;
  doc.setTextColor(32, 36, 56);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('1. Trip Overview & Budget Summary', 40, y);

  y += 10;
  autoTable(doc, {
    startY: y,
    theme: 'grid',
    headStyles: { fillColor: [112, 71, 235], textColor: 255, fontSize: 9 },
    styles: { fontSize: 9, cellPadding: 6, textColor: [32, 36, 56] },
    head: [['Destination', 'Dates', 'Total Budget', 'Total Spending', 'Remaining', 'Utilization']],
    body: [
      [
        trip.destination,
        `${formatDateShort(trip.startDate)} – ${formatDateShort(trip.endDate)}`,
        formatPdfINR(trip.budgetPaise),
        formatPdfINR(totalSpentPaise),
        formatPdfINR(budgetAlert.remainingPaise),
        `${budgetAlert.utilizationPercent.toFixed(1)}%`,
      ],
    ],
  });

  // Member Information & Individual Balances
  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 24;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('2. Member Contributions & Individual Balance Ledger', 40, y);

  y += 10;
  autoTable(doc, {
    startY: y,
    theme: 'striped',
    headStyles: { fillColor: [16, 24, 40], textColor: 255, fontSize: 9 },
    styles: { fontSize: 9, cellPadding: 6, textColor: [32, 36, 56] },
    head: [['Member', 'Email / UPI', 'Total Paid', 'Total Share', 'Settled Adj.', 'Net Balance', 'Status']],
    body: simplification.balances.map((b) => {
      const m = memberMap.get(b.memberId);
      const settledAdj = b.settledOutPaise - b.settledInPaise;
      const statusText =
        b.status === 'owed'
          ? 'Owed to Member'
          : b.status === 'owes'
          ? 'Owes Group'
          : 'Settled';
      return [
        b.member.name,
        `${m?.email ?? ''}\n${m?.upiId ?? ''}`,
        formatPdfINR(b.totalPaidPaise),
        formatPdfINR(b.totalSharePaise),
        formatPdfINR(settledAdj),
        formatPdfINR(b.netBalancePaise),
        statusText,
      ];
    }),
  });

  // Category-wise Breakdown
  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 24;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('3. Category-Wise Spending Breakdown', 40, y);

  const catTotals = ALL_CATEGORIES.map((cat) => {
    const items = tripExpenses.filter((e) => e.category === cat);
    const sum = items.reduce((s, e) => s + e.amountPaise, 0);
    const pct = totalSpentPaise > 0 ? ((sum / totalSpentPaise) * 100).toFixed(1) : '0.0';
    return { cat, count: items.length, sum, pct };
  }).filter((row) => row.count > 0);

  y += 10;
  autoTable(doc, {
    startY: y,
    theme: 'striped',
    headStyles: { fillColor: [52, 120, 246], textColor: 255, fontSize: 9 },
    styles: { fontSize: 9, cellPadding: 6, textColor: [32, 36, 56] },
    head: [['Category', 'Expenses Count', 'Total Spent', 'Share of Spend']],
    body:
      catTotals.length > 0
        ? catTotals.map((r) => [r.cat, String(r.count), formatPdfINR(r.sum), `${r.pct}%`])
        : [['No expenses recorded', '0', formatPdfINR(0), '0.0%']],
  });

  // Final Settlement Instructions
  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 24;
  if (y > 680) {
    doc.addPage();
    y = 48;
  }
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('4. Optimized Settlement Instructions (Greedy Cash-Flow Minimization)', 40, y);

  y += 10;
  autoTable(doc, {
    startY: y,
    theme: 'grid',
    headStyles: { fillColor: [22, 163, 106], textColor: 255, fontSize: 9 },
    styles: { fontSize: 9, cellPadding: 6, textColor: [32, 36, 56] },
    head: [['From (Debtor)', 'To (Creditor)', 'Payee UPI ID', 'Settlement Amount', 'Status']],
    body:
      simplification.simplifiedTransactions.length > 0
        ? simplification.simplifiedTransactions.map((tx) => {
            const fromM = memberMap.get(tx.fromMemberId);
            const toM = memberMap.get(tx.toMemberId);
            return [
              fromM?.name ?? tx.fromMemberId,
              toM?.name ?? tx.toMemberId,
              toM?.upiId ?? '—',
              formatPdfINR(tx.amountPaise),
              'Pending Settlement',
            ];
          })
        : [['All Balances Clear', '—', '—', formatPdfINR(0), 'Settled']],
  });

  // Expense History
  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 24;
  if (y > 660) {
    doc.addPage();
    y = 48;
  }
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text(`5. Complete Expense History (${tripExpenses.length} Transactions)`, 40, y);

  y += 10;
  autoTable(doc, {
    startY: y,
    theme: 'striped',
    headStyles: { fillColor: [16, 24, 40], textColor: 255, fontSize: 8.5 },
    styles: { fontSize: 8.5, cellPadding: 5, textColor: [32, 36, 56] },
    head: [['Date', 'Expense Title', 'Category', 'Paid By', 'Split', 'Amount']],
    body:
      tripExpenses.length > 0
        ? tripExpenses.map((exp) => [
            formatDateShort(exp.date),
            exp.title,
            exp.category,
            memberMap.get(exp.paidByMemberId)?.name ?? 'Unknown',
            `${exp.splitType.toUpperCase()} (${exp.participantIds.length})`,
            formatPdfINR(exp.amountPaise),
          ])
        : [['—', 'No expenses logged yet', '—', '—', '—', formatPdfINR(0)]],
  });

  // Footer note on last page
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text(
      `TripTally Financial Statement · ${trip.name} · ${tripMembers.length} Members · Page ${i} of ${pageCount}`,
      40,
      doc.internal.pageSize.getHeight() - 24
    );
  }

  const safeSlug = trip.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  doc.save(`triptally-report-${safeSlug}.pdf`);
}
