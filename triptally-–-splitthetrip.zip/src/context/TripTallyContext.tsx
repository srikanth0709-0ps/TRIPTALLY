import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { createInitialDemoState } from '../data/demoData';
import type {
  AppSettings,
  Expense,
  Member,
  ReceiptAsset,
  SettlementMethod,
  SettlementRecord,
  Trip,
  TripTallyState,
} from '../types';

const LOCAL_STORAGE_KEY = 'triptally_v1_state';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  description?: string;
}

interface TripTallyContextValue {
  state: TripTallyState;
  isLoaded: boolean;
  toasts: ToastMessage[];
  dismissToast: (id: string) => void;
  pushToast: (toast: Omit<ToastMessage, 'id'>) => void;
  globalSearch: string;
  setGlobalSearch: (q: string) => void;

  // Trip Actions
  addTrip: (trip: Omit<Trip, 'id' | 'createdAt' | 'status'>) => Trip;
  updateTrip: (tripId: string, patch: Partial<Omit<Trip, 'id' | 'createdAt'>>) => void;
  deleteTrip: (tripId: string) => void;
  toggleArchiveTrip: (tripId: string) => void;

  // Member Actions
  addMember: (member: Omit<Member, 'id'>, tripIdToAssign?: string) => Member;
  updateMember: (memberId: string, patch: Partial<Omit<Member, 'id'>>) => void;
  deleteMember: (memberId: string) => { ok: boolean; reason?: string };

  // Expense Actions
  addExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => Expense;
  updateExpense: (expenseId: string, patch: Partial<Omit<Expense, 'id' | 'createdAt'>>) => void;
  deleteExpense: (expenseId: string) => void;
  attachReceiptToExpense: (expenseId: string, receipt: ReceiptAsset) => void;
  removeReceiptFromExpense: (expenseId: string) => void;

  // Settlement Actions
  markSettlementPaid: (params: {
    tripId: string;
    fromMemberId: string;
    toMemberId: string;
    amountPaise: number;
    method: SettlementMethod;
    note?: string;
  }) => void;
  revertSettlement: (settlementId: string) => void;

  // Settings & Storage
  updateSettings: (patch: Partial<AppSettings>) => void;
  resetDemoData: () => void;
  importState: (nextState: TripTallyState) => void;
}

const TripTallyContext = createContext<TripTallyContextValue | null>(null);

function loadLocalFallback(): TripTallyState {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as TripTallyState;
      if (parsed && Array.isArray(parsed.trips) && Array.isArray(parsed.members)) {
        return parsed;
      }
    }
  } catch {
    // ignore corrupted local storage
  }
  return createInitialDemoState();
}

export function TripTallyProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<TripTallyState>(() => loadLocalFallback());
  const [isLoaded, setIsLoaded] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [globalSearch, setGlobalSearch] = useState('');
  const syncTimerRef = useRef<number | null>(null);
  const skipNextServerPushRef = useRef(true);

  const pushToast = useCallback((toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev.slice(-3), { ...toast, id }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4200);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Hydrate from Express persistent API on mount (falling back to localStorage / demo)
  useEffect(() => {
    let cancelled = false;
    async function hydrate() {
      try {
        const res = await fetch('/api/state');
        if (res.ok) {
          const data = (await res.json()) as {
            initialized: boolean;
            state: TripTallyState | null;
          };
          if (!cancelled) {
            if (data.initialized && data.state) {
              skipNextServerPushRef.current = true;
              setState(data.state);
              localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data.state));
            } else {
              // Seed server DB with initial state
              const seed = loadLocalFallback();
              await fetch('/api/state', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(seed),
              });
            }
          }
        }
      } catch {
        // Offline / localStorage fallback continues working seamlessly
      } finally {
        if (!cancelled) setIsLoaded(true);
      }
    }
    hydrate();
    return () => {
      cancelled = true;
    };
  }, []);

  // Persist every state change to localStorage & Express JSON DB
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(state));
    } catch {
      // ignore quota errors
    }

    if (skipNextServerPushRef.current) {
      skipNextServerPushRef.current = false;
      return;
    }

    if (syncTimerRef.current) {
      window.clearTimeout(syncTimerRef.current);
    }

    syncTimerRef.current = window.setTimeout(() => {
      fetch('/api/state', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(state),
      }).catch(() => {
        // Ignore transient network errors
      });
    }, 250);
  }, [state]);

  const addTrip = useCallback(
    (tripInput: Omit<Trip, 'id' | 'createdAt' | 'status'>) => {
      const newTrip: Trip = {
        ...tripInput,
        id: `trip_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        status: 'active',
        createdAt: new Date().toISOString(),
      };
      setState((prev) => ({
        ...prev,
        trips: [newTrip, ...prev.trips],
      }));
      pushToast({
        type: 'success',
        title: 'Trip Created',
        description: `${newTrip.name} is ready for expense tracking.`,
      });
      return newTrip;
    },
    [pushToast]
  );

  const updateTrip = useCallback(
    (tripId: string, patch: Partial<Omit<Trip, 'id' | 'createdAt'>>) => {
      setState((prev) => ({
        ...prev,
        trips: prev.trips.map((t) => (t.id === tripId ? { ...t, ...patch } : t)),
      }));
      pushToast({
        type: 'success',
        title: 'Trip Updated',
        description: 'Trip details and budget settings saved.',
      });
    },
    [pushToast]
  );

  const deleteTrip = useCallback(
    (tripId: string) => {
      setState((prev) => ({
        ...prev,
        trips: prev.trips.filter((t) => t.id !== tripId),
        expenses: prev.expenses.filter((e) => e.tripId !== tripId),
        settlements: prev.settlements.filter((s) => s.tripId !== tripId),
      }));
      pushToast({
        type: 'info',
        title: 'Trip Deleted',
        description: 'The trip and its associated expenses were removed.',
      });
    },
    [pushToast]
  );

  const toggleArchiveTrip = useCallback(
    (tripId: string) => {
      setState((prev) => ({
        ...prev,
        trips: prev.trips.map((t) =>
          t.id === tripId
            ? { ...t, status: t.status === 'active' ? 'archived' : 'active' }
            : t
        ),
      }));
      pushToast({
        type: 'info',
        title: 'Trip Status Updated',
      });
    },
    [pushToast]
  );

  const addMember = useCallback(
    (memberInput: Omit<Member, 'id'>, tripIdToAssign?: string) => {
      const colors = ['#3478F6', '#7047EB', '#16A36A', '#F5A623', '#EC4899', '#0EA5E9'];
      const newMember: Member = {
        ...memberInput,
        id: `mem_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        avatarColor: memberInput.avatarColor || colors[Math.floor(Math.random() * colors.length)],
      };

      setState((prev) => ({
        ...prev,
        members: [...prev.members, newMember],
        trips: tripIdToAssign
          ? prev.trips.map((t) =>
              t.id === tripIdToAssign && !t.memberIds.includes(newMember.id)
                ? { ...t, memberIds: [...t.memberIds, newMember.id] }
                : t
            )
          : prev.trips,
      }));
      pushToast({
        type: 'success',
        title: 'Member Added',
        description: `${newMember.name} joined your group directory.`,
      });
      return newMember;
    },
    [pushToast]
  );

  const updateMember = useCallback(
    (memberId: string, patch: Partial<Omit<Member, 'id'>>) => {
      setState((prev) => ({
        ...prev,
        members: prev.members.map((m) => (m.id === memberId ? { ...m, ...patch } : m)),
      }));
      pushToast({
        type: 'success',
        title: 'Member Updated',
      });
    },
    [pushToast]
  );

  const deleteMember = useCallback(
    (memberId: string): { ok: boolean; reason?: string } => {
      const usedInExpense = state.expenses.some(
        (e) =>
          e.paidByMemberId === memberId ||
          e.participantIds.includes(memberId) ||
          e.splits.some((s) => s.memberId === memberId && s.amountPaise > 0)
      );
      if (usedInExpense) {
        pushToast({
          type: 'error',
          title: 'Cannot Remove Member',
          description:
            'This member is referenced in existing expenses. Reassign or delete those expenses first.',
        });
        return { ok: false, reason: 'Referenced in existing expenses' };
      }

      if (state.members.length <= 1) {
        pushToast({
          type: 'error',
          title: 'Cannot Remove Last Member',
        });
        return { ok: false, reason: 'At least one member is required' };
      }

      setState((prev) => {
        const remaining = prev.members.filter((m) => m.id !== memberId);
        return {
          ...prev,
          members: remaining,
          trips: prev.trips.map((t) => ({
            ...t,
            memberIds: t.memberIds.filter((id) => id !== memberId),
          })),
          settings: {
            ...prev.settings,
            activeUserId:
              prev.settings.activeUserId === memberId
                ? remaining[0]?.id ?? ''
                : prev.settings.activeUserId,
          },
        };
      });
      pushToast({
        type: 'info',
        title: 'Member Removed',
      });
      return { ok: true };
    },
    [state.expenses, state.members.length, pushToast]
  );

  const addExpense = useCallback(
    (expenseInput: Omit<Expense, 'id' | 'createdAt'>) => {
      const newExpense: Expense = {
        ...expenseInput,
        id: `exp_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        createdAt: new Date().toISOString(),
      };
      setState((prev) => ({
        ...prev,
        expenses: [newExpense, ...prev.expenses],
      }));
      pushToast({
        type: 'success',
        title: 'Expense Logged',
        description: `${newExpense.title} added and balances recalculated.`,
      });
      return newExpense;
    },
    [pushToast]
  );

  const updateExpense = useCallback(
    (expenseId: string, patch: Partial<Omit<Expense, 'id' | 'createdAt'>>) => {
      setState((prev) => ({
        ...prev,
        expenses: prev.expenses.map((e) => (e.id === expenseId ? { ...e, ...patch } : e)),
      }));
      pushToast({
        type: 'success',
        title: 'Expense Updated',
        description: 'Splits and group balances updated.',
      });
    },
    [pushToast]
  );

  const deleteExpense = useCallback(
    (expenseId: string) => {
      setState((prev) => ({
        ...prev,
        expenses: prev.expenses.filter((e) => e.id !== expenseId),
      }));
      pushToast({
        type: 'info',
        title: 'Expense Deleted',
      });
    },
    [pushToast]
  );

  const attachReceiptToExpense = useCallback(
    (expenseId: string, receipt: ReceiptAsset) => {
      setState((prev) => ({
        ...prev,
        expenses: prev.expenses.map((e) =>
          e.id === expenseId ? { ...e, receipt } : e
        ),
      }));
      pushToast({
        type: 'success',
        title: 'Receipt Attached',
        description: `${receipt.name} saved to expense.`,
      });
    },
    [pushToast]
  );

  const removeReceiptFromExpense = useCallback(
    (expenseId: string) => {
      setState((prev) => ({
        ...prev,
        expenses: prev.expenses.map((e) => {
          if (e.id !== expenseId) return e;
          const copy = { ...e };
          delete copy.receipt;
          return copy;
        }),
      }));
      pushToast({
        type: 'info',
        title: 'Receipt Removed',
      });
    },
    [pushToast]
  );

  const markSettlementPaid = useCallback(
    (params: {
      tripId: string;
      fromMemberId: string;
      toMemberId: string;
      amountPaise: number;
      method: SettlementMethod;
      note?: string;
    }) => {
      const record: SettlementRecord = {
        id: `stl_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        tripId: params.tripId,
        fromMemberId: params.fromMemberId,
        toMemberId: params.toMemberId,
        amountPaise: params.amountPaise,
        status: 'paid',
        paidAt: new Date().toISOString(),
        method: params.method,
        note: params.note,
      };
      setState((prev) => ({
        ...prev,
        settlements: [record, ...prev.settlements],
      }));
      pushToast({
        type: 'success',
        title: 'Settlement Recorded',
        description: 'Payment confirmed and ledger updated.',
      });
    },
    [pushToast]
  );

  const revertSettlement = useCallback(
    (settlementId: string) => {
      setState((prev) => ({
        ...prev,
        settlements: prev.settlements.filter((s) => s.id !== settlementId),
      }));
      pushToast({
        type: 'info',
        title: 'Settlement Reverted',
        description: 'Debt balance restored to pending settlements.',
      });
    },
    [pushToast]
  );

  const updateSettings = useCallback(
    (patch: Partial<AppSettings>) => {
      setState((prev) => ({
        ...prev,
        settings: { ...prev.settings, ...patch },
      }));
      pushToast({
        type: 'success',
        title: 'Settings Saved',
      });
    },
    [pushToast]
  );

  const resetDemoData = useCallback(() => {
    const fresh = createInitialDemoState();
    setState(fresh);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(fresh));
    fetch('/api/state', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(fresh),
    }).catch(() => {});
    pushToast({
      type: 'success',
      title: 'Demo Data Restored',
      description: 'Goa Road Trip 2026 and Manali Winter Escape reset to default.',
    });
  }, [pushToast]);

  const importState = useCallback(
    (nextState: TripTallyState) => {
      setState(nextState);
      pushToast({
        type: 'success',
        title: 'Backup Imported',
      });
    },
    [pushToast]
  );

  const value = useMemo<TripTallyContextValue>(
    () => ({
      state,
      isLoaded,
      toasts,
      dismissToast,
      pushToast,
      globalSearch,
      setGlobalSearch,
      addTrip,
      updateTrip,
      deleteTrip,
      toggleArchiveTrip,
      addMember,
      updateMember,
      deleteMember,
      addExpense,
      updateExpense,
      deleteExpense,
      attachReceiptToExpense,
      removeReceiptFromExpense,
      markSettlementPaid,
      revertSettlement,
      updateSettings,
      resetDemoData,
      importState,
    }),
    [
      state,
      isLoaded,
      toasts,
      dismissToast,
      pushToast,
      globalSearch,
      addTrip,
      updateTrip,
      deleteTrip,
      toggleArchiveTrip,
      addMember,
      updateMember,
      deleteMember,
      addExpense,
      updateExpense,
      deleteExpense,
      attachReceiptToExpense,
      removeReceiptFromExpense,
      markSettlementPaid,
      revertSettlement,
      updateSettings,
      resetDemoData,
      importState,
    ]
  );

  return <TripTallyContext.Provider value={value}>{children}</TripTallyContext.Provider>;
}

export function useTripTally(): TripTallyContextValue {
  const ctx = useContext(TripTallyContext);
  if (!ctx) {
    throw new Error('useTripTally must be used within TripTallyProvider');
  }
  return ctx;
}
