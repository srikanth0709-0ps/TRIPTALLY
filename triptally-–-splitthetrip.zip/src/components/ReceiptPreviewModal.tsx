import { Trash2, X } from 'lucide-react';
import type { Expense } from '../types';
import { formatDateShort, formatINR } from '../utils/finance';

interface ReceiptPreviewModalProps {
  expense: Expense | null;
  onClose: () => void;
  onDeleteReceipt?: (expenseId: string) => void;
}

export function ReceiptPreviewModal({
  expense,
  onClose,
  onDeleteReceipt,
}: ReceiptPreviewModalProps) {
  if (!expense || !expense.receipt) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#101828]/70 p-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-xl overflow-hidden rounded-xl border border-[#E5E3F3] bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#EFEFF7] px-5 py-3.5">
          <div className="min-w-0">
            <h3 className="truncate font-display text-sm font-bold text-[#101828]">
              {expense.title}
            </h3>
            <p className="text-xs text-[#525870]">
              {expense.receipt.name} · {formatINR(expense.amountPaise)} ·{' '}
              {formatDateShort(expense.date)}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {onDeleteReceipt && (
              <button
                type="button"
                onClick={() => {
                  onDeleteReceipt(expense.id);
                  onClose();
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#EF5350]/30 px-3 py-1.5 text-xs font-semibold text-[#EF5350] hover:bg-[#EF5350]/10"
              >
                <Trash2 size={13} />
                Delete Receipt
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-[#F6F5FC] hover:text-[#101828]"
              aria-label="Close receipt preview"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="flex max-h-[75vh] items-center justify-center overflow-auto bg-[#F6F5FC] p-6">
          <img
            src={expense.receipt.dataUrl}
            alt={`Receipt for ${expense.title}`}
            referrerPolicy="no-referrer"
            className="max-h-[66vh] w-auto rounded-lg border border-[#E5E3F3] bg-white object-contain shadow-sm"
          />
        </div>
      </div>
    </div>
  );
}
