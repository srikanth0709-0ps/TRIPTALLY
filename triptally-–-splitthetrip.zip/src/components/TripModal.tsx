import React, { useEffect, useState } from 'react';
import { Calendar, Check, MapPin, Plus, UserPlus, X } from 'lucide-react';
import { useTripTally } from '../context/TripTallyContext';
import { COVER_IMAGES } from '../data/demoData';
import type { Trip } from '../types';
import { fromPaise, toPaise } from '../utils/finance';
import { MemberAvatar } from './MemberAvatar';

interface TripModalProps {
  open: boolean;
  editingTrip?: Trip | null;
  onClose: () => void;
}

const PRESET_COVERS = [
  { label: 'Coastal Goa', url: COVER_IMAGES.goa },
  { label: 'Mountain Pass', url: COVER_IMAGES.mountains },
  { label: 'Heritage Palace', url: COVER_IMAGES.heritage },
];

export function TripModal({ open, editingTrip, onClose }: TripModalProps) {
  const { state, addTrip, updateTrip, addMember } = useTripTally();

  const [name, setName] = useState('');
  const [destination, setDestination] = useState('');
  const [startDate, setStartDate] = useState('2026-11-20');
  const [endDate, setEndDate] = useState('2026-11-24');
  const [budgetRupees, setBudgetRupees] = useState('20000');
  const [description, setDescription] = useState('');
  const [coverImage, setCoverImage] = useState(COVER_IMAGES.goa);
  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([]);
  const [error, setError] = useState('');

  // Inline new member state
  const [showNewMember, setShowNewMember] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberUpi, setNewMemberUpi] = useState('');

  useEffect(() => {
    if (!open) return;
    if (editingTrip) {
      setName(editingTrip.name);
      setDestination(editingTrip.destination);
      setStartDate(editingTrip.startDate);
      setEndDate(editingTrip.endDate);
      setBudgetRupees(String(fromPaise(editingTrip.budgetPaise)));
      setDescription(editingTrip.description);
      setCoverImage(editingTrip.coverImage || COVER_IMAGES.goa);
      setSelectedMemberIds(editingTrip.memberIds);
    } else {
      setName('');
      setDestination('');
      setStartDate('2026-11-20');
      setEndDate('2026-11-24');
      setBudgetRupees('20000');
      setDescription('');
      setCoverImage(COVER_IMAGES.heritage);
      setSelectedMemberIds(state.members.map((m) => m.id));
    }
    setError('');
    setShowNewMember(false);
    setNewMemberName('');
    setNewMemberEmail('');
    setNewMemberUpi('');
  }, [open, editingTrip, state.members]);

  if (!open) return null;

  const toggleMember = (id: string) => {
    setSelectedMemberIds((prev) =>
      prev.includes(id) ? prev.filter((m) => m !== id) : [...prev, id]
    );
  };

  const handleQuickAddMember = () => {
    const trimmedName = newMemberName.trim();
    const trimmedEmail = newMemberEmail.trim();
    if (!trimmedName || !trimmedEmail) {
      setError('Enter both name and email to add a new trip member.');
      return;
    }
    const created = addMember({
      name: trimmedName,
      email: trimmedEmail,
      upiId:
        newMemberUpi.trim() ||
        `${trimmedName.toLowerCase().replace(/[^a-z0-9]/g, '.')}@okaxis`,
      avatarColor: '#3478F6',
    });
    setSelectedMemberIds((prev) => [...prev, created.id]);
    setNewMemberName('');
    setNewMemberEmail('');
    setNewMemberUpi('');
    setShowNewMember(false);
    setError('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const budgetNum = Number(budgetRupees);
    if (!name.trim() || !destination.trim()) {
      setError('Trip name and destination are required.');
      return;
    }
    if (!startDate || !endDate || endDate < startDate) {
      setError('End date must be on or after start date.');
      return;
    }
    if (!Number.isFinite(budgetNum) || budgetNum <= 0) {
      setError('Please enter a valid positive trip budget in INR.');
      return;
    }
    if (selectedMemberIds.length === 0) {
      setError('Select at least one member for this trip.');
      return;
    }

    const payload = {
      name: name.trim(),
      destination: destination.trim(),
      startDate,
      endDate,
      budgetPaise: toPaise(budgetNum),
      description: description.trim(),
      coverImage,
      memberIds: selectedMemberIds,
    };

    if (editingTrip) {
      updateTrip(editingTrip.id, payload);
    } else {
      addTrip(payload);
    }
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#101828]/50 p-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
    >
      <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-xl border border-[#E5E3F3] bg-white shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[#EFEFF7] bg-white px-6 py-4">
          <div>
            <h2 className="font-display text-lg font-bold text-[#101828]">
              {editingTrip ? 'Edit Trip Details' : 'Create New Trip'}
            </h2>
            <p className="text-xs text-[#525870]">
              Set your destination, budget target, and participating travelers.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-[#F6F5FC] hover:text-[#101828]"
            aria-label="Close trip modal"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 p-6">
          {error && (
            <div className="rounded-lg border border-[#EF5350]/30 bg-[#EF5350]/10 px-4 py-2.5 text-xs font-medium text-[#C62828]">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                Trip Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Udaipur Heritage Weekend"
                className="w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm text-[#101828] outline-none transition-colors focus:border-[#7047EB] focus:ring-2 focus:ring-[#7047EB]/15"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                Destination *
              </label>
              <div className="relative">
                <MapPin
                  size={15}
                  className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-slate-400"
                />
                <input
                  type="text"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  placeholder="e.g., Udaipur, Rajasthan"
                  className="w-full rounded-lg border border-[#E5E3F3] bg-white py-2 pr-3.5 pl-9 text-sm text-[#101828] outline-none transition-colors focus:border-[#7047EB] focus:ring-2 focus:ring-[#7047EB]/15"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                Start Date *
              </label>
              <div className="relative">
                <Calendar
                  size={14}
                  className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-slate-400"
                />
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full rounded-lg border border-[#E5E3F3] bg-white py-2 pr-3 pl-9 text-sm tabular-nums text-[#101828] outline-none transition-colors focus:border-[#7047EB]"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                End Date *
              </label>
              <div className="relative">
                <Calendar
                  size={14}
                  className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-slate-400"
                />
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full rounded-lg border border-[#E5E3F3] bg-white py-2 pr-3 pl-9 text-sm tabular-nums text-[#101828] outline-none transition-colors focus:border-[#7047EB]"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                Total Budget (₹) *
              </label>
              <input
                type="number"
                min="1"
                step="1"
                value={budgetRupees}
                onChange={(e) => setBudgetRupees(e.target.value)}
                className="font-mono-tabular w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm text-[#101828] outline-none transition-colors focus:border-[#7047EB] focus:ring-2 focus:ring-[#7047EB]/15"
              />
            </div>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
              Trip Description
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Briefly describe the itinerary, stay plans, or split rules..."
              className="w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm text-[#101828] outline-none transition-colors focus:border-[#7047EB] focus:ring-2 focus:ring-[#7047EB]/15"
            />
          </div>

          <div>
            <label className="mb-2 block text-xs font-semibold text-[#202438]">
              Trip Cover Artwork
            </label>
            <div className="grid grid-cols-3 gap-3">
              {PRESET_COVERS.map((preset) => {
                const active = coverImage === preset.url;
                return (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => setCoverImage(preset.url)}
                    className={`group relative overflow-hidden rounded-lg border text-left transition-all ${
                      active
                        ? 'border-[#7047EB] ring-2 ring-[#7047EB]/25'
                        : 'border-[#E5E3F3] hover:border-[#7047EB]/50'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.label}
                      referrerPolicy="no-referrer"
                      className="h-20 w-full object-cover"
                    />
                    <div className="flex items-center justify-between bg-white px-2.5 py-1.5">
                      <span className="truncate text-xs font-medium text-[#202438]">
                        {preset.label}
                      </span>
                      {active && <Check size={14} className="shrink-0 text-[#7047EB]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="border-t border-[#EFEFF7] pt-4">
            <div className="mb-2.5 flex items-center justify-between">
              <label className="text-xs font-semibold text-[#202438]">
                Trip Members ({selectedMemberIds.length} selected)
              </label>
              <button
                type="button"
                onClick={() => setShowNewMember((v) => !v)}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#7047EB] hover:text-[#5B34D6]"
              >
                <UserPlus size={14} />
                {showNewMember ? 'Close' : 'Add New Member'}
              </button>
            </div>

            {showNewMember && (
              <div className="mb-3 grid grid-cols-1 gap-2.5 rounded-lg border border-[#E5E3F3] bg-[#F6F5FC] p-3 sm:grid-cols-3">
                <input
                  type="text"
                  value={newMemberName}
                  onChange={(e) => setNewMemberName(e.target.value)}
                  placeholder="Full name"
                  className="rounded-lg border border-[#E5E3F3] bg-white px-3 py-1.5 text-xs text-[#101828] outline-none focus:border-[#7047EB]"
                />
                <input
                  type="email"
                  value={newMemberEmail}
                  onChange={(e) => setNewMemberEmail(e.target.value)}
                  placeholder="Email address"
                  className="rounded-lg border border-[#E5E3F3] bg-white px-3 py-1.5 text-xs text-[#101828] outline-none focus:border-[#7047EB]"
                />
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newMemberUpi}
                    onChange={(e) => setNewMemberUpi(e.target.value)}
                    placeholder="UPI ID (optional)"
                    className="min-w-0 flex-1 rounded-lg border border-[#E5E3F3] bg-white px-3 py-1.5 text-xs text-[#101828] outline-none focus:border-[#7047EB]"
                  />
                  <button
                    type="button"
                    onClick={handleQuickAddMember}
                    className="inline-flex shrink-0 items-center gap-1 rounded-lg bg-[#101828] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#1E293B]"
                  >
                    <Plus size={13} />
                    Add
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {state.members.map((member) => {
                const selected = selectedMemberIds.includes(member.id);
                return (
                  <button
                    key={member.id}
                    type="button"
                    onClick={() => toggleMember(member.id)}
                    className={`flex items-center justify-between rounded-lg border px-3 py-2 text-left transition-colors ${
                      selected
                        ? 'border-[#7047EB] bg-[#7047EB]/5'
                        : 'border-[#E5E3F3] bg-white hover:bg-[#F6F5FC]'
                    }`}
                  >
                    <div className="flex min-w-0 items-center gap-2.5">
                      <MemberAvatar member={member} size="sm" />
                      <div className="min-w-0">
                        <p className="truncate text-xs font-semibold text-[#101828]">
                          {member.name}
                        </p>
                        <p className="truncate text-[11px] text-[#525870]">{member.email}</p>
                      </div>
                    </div>
                    <span
                      className={`flex h-5 w-5 shrink-0 items-center justify-center rounded border ${
                        selected
                          ? 'border-[#7047EB] bg-[#7047EB] text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {selected && <Check size={12} strokeWidth={3} />}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-[#EFEFF7] pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-[#E5E3F3] bg-white px-4 py-2 text-sm font-semibold text-[#202438] hover:bg-[#F6F5FC]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-[#7047EB] px-5 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#5B34D6]"
            >
              {editingTrip ? 'Save Changes' : 'Create Trip'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
