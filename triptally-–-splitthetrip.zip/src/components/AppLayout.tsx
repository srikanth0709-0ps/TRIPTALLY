import React, { useMemo, useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowLeftRight,
  BarChart3,
  Bell,
  Compass,
  FileSpreadsheet,
  HelpCircle,
  LayoutDashboard,
  Map as MapIcon,
  Menu,
  Plus,
  Receipt,
  Search,
  Settings,
  Users,
  X,
} from 'lucide-react';
import { useTripTally } from '../context/TripTallyContext';
import { computeBudgetAlert, formatINR, runDebtSimplification } from '../utils/finance';
import { MemberAvatar } from './MemberAvatar';
import { ToastContainer } from './ToastContainer';
import { TripModal } from './TripModal';

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/trips', label: 'My Trips', icon: MapIcon },
  { to: '/expenses', label: 'All Expenses', icon: Receipt },
  { to: '/members', label: 'Members', icon: Users },
  { to: '/settlements', label: 'Settlements', icon: ArrowLeftRight },
  { to: '/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/reports', label: 'Reports', icon: FileSpreadsheet },
  { to: '/settings', label: 'Settings', icon: Settings },
];

const ROUTE_TITLES: Record<string, string> = {
  '/': 'Financial Dashboard',
  '/trips': 'My Trips',
  '/expenses': 'All Expenses',
  '/members': 'Group Members',
  '/settlements': 'Debt Simplification & Settlements',
  '/analytics': 'Spending Analytics',
  '/reports': 'Reports & Receipts',
  '/settings': 'Workspace Settings',
};

export function AppLayout({ children }: { children: React.ReactNode }) {
  const { state, globalSearch, setGlobalSearch, updateSettings } = useTripTally();
  const location = useLocation();
  const navigate = useNavigate();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [tripModalOpen, setTripModalOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const activeUser = useMemo(
    () =>
      state.members.find((m) => m.id === state.settings.activeUserId) ??
      state.members[0],
    [state.members, state.settings.activeUserId]
  );

  // Build real notifications from Smart Budget Alerts + Pending Settlements
  const notifications = useMemo(() => {
    const items: Array<{
      id: string;
      severity: 'danger' | 'warning' | 'info';
      title: string;
      message: string;
      route: string;
    }> = [];

    for (const trip of state.trips) {
      if (trip.status === 'archived') continue;
      const tripExpenses = state.expenses.filter((e) => e.tripId === trip.id);
      const spentPaise = tripExpenses.reduce((s, e) => s + e.amountPaise, 0);
      const alert = computeBudgetAlert(trip, spentPaise);

      if (
        (alert.level === 'exceeded' && state.settings.enable100Alert) ||
        (alert.level === 'limit100' && state.settings.enable100Alert)
      ) {
        items.push({
          id: `budget_${trip.id}`,
          severity: 'danger',
          title: alert.title,
          message: alert.message,
          route: `/trips/${trip.id}`,
        });
      } else if (
        (alert.level === 'warning90' && state.settings.enable90Alert) ||
        (alert.level === 'warning75' && state.settings.enable75Alert)
      ) {
        items.push({
          id: `budget_${trip.id}`,
          severity: 'warning',
          title: alert.title,
          message: alert.message,
          route: `/trips/${trip.id}`,
        });
      }

      const sim = runDebtSimplification(
        trip.memberIds,
        state.members,
        tripExpenses,
        state.settlements.filter((s) => s.tripId === trip.id)
      );
      if (sim.simplifiedTransactions.length > 0) {
        items.push({
          id: `settle_${trip.id}`,
          severity: 'info',
          title: `${sim.simplifiedTransactions.length} Pending Settlements in ${trip.name}`,
          message: `${formatINR(sim.totalSettlementVolumePaise)} total to clear balances.`,
          route: '/settlements',
        });
      }
    }

    return items;
  }, [state.trips, state.expenses, state.members, state.settlements, state.settings]);

  // Global quick search results
  const searchResults = useMemo(() => {
    const q = globalSearch.trim().toLowerCase();
    if (!q) return null;
    const matchedTrips = state.trips
      .filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.destination.toLowerCase().includes(q)
      )
      .slice(0, 3);
    const matchedExpenses = state.expenses
      .filter(
        (e) =>
          e.title.toLowerCase().includes(q) ||
          e.category.toLowerCase().includes(q) ||
          e.notes.toLowerCase().includes(q)
      )
      .slice(0, 4);
    return { matchedTrips, matchedExpenses };
  }, [globalSearch, state.trips, state.expenses]);

  const pageTitle = useMemo(() => {
    if (location.pathname.startsWith('/trips/')) {
      const id = location.pathname.replace('/trips/', '');
      const found = state.trips.find((t) => t.id === id);
      return found ? found.name : 'Trip Details';
    }
    return ROUTE_TITLES[location.pathname] ?? 'TripTally';
  }, [location.pathname, state.trips]);

  const sidebarContent = (
    <div className="flex h-full flex-col bg-[#101828] text-white">
      {/* Brand Header */}
      <div className="flex items-center gap-3 px-5 py-6">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#7047EB] to-[#3478F6] text-white shadow-md">
          <Compass size={20} strokeWidth={2.2} />
        </div>
        <div className="min-w-0">
          <p className="font-display truncate text-base font-extrabold tracking-tight text-white">
            TripTally
          </p>
          <p className="truncate text-[11px] font-medium text-slate-400">SplitTheTrip</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-2" aria-label="Primary">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              onClick={() => setMobileMenuOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-lg px-3.5 py-2.5 text-sm font-medium whitespace-nowrap transition-colors duration-150 ${
                  isActive
                    ? 'bg-gradient-to-r from-[#7047EB] to-[#3478F6] text-white shadow-sm'
                    : 'text-slate-300 hover:bg-white/8 hover:text-white'
                }`
              }
            >
              <Icon size={18} strokeWidth={2} className="shrink-0" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* Bottom Active User Profile */}
      <div className="border-t border-white/10 p-4">
        <button
          type="button"
          onClick={() => {
            navigate('/settings');
            setMobileMenuOpen(false);
          }}
          className="flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-white/8"
        >
          <MemberAvatar member={activeUser} size="md" />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-white">
              {activeUser?.name ?? 'User'}
            </p>
            <p className="truncate text-xs text-slate-400">
              {activeUser?.upiId ?? 'Active Profile'}
            </p>
          </div>
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[#F6F5FC] text-[#202438]">
      {/* Desktop Sidebar */}
      <aside className="hidden w-64 shrink-0 lg:sticky lg:top-0 lg:block lg:h-screen">
        {sidebarContent}
      </aside>

      {/* Mobile Collapsible Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 flex lg:hidden">
          <div
            className="fixed inset-0 bg-[#101828]/60 backdrop-blur-[1px]"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-50 h-full w-64 shrink-0 shadow-2xl">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              className="absolute top-4 right-3 rounded-lg p-1.5 text-slate-300 hover:bg-white/10 hover:text-white"
              aria-label="Close sidebar"
            >
              <X size={18} />
            </button>
            {sidebarContent}
          </aside>
        </div>
      )}

      {/* Main Column */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Top Bar */}
        <header className="sticky top-0 z-30 border-b border-[#E5E3F3] bg-white/90 backdrop-blur-md">
          <div className="flex items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
            <div className="flex min-w-0 items-center gap-3">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-[#E5E3F3] bg-white text-[#101828] hover:bg-[#F6F5FC] lg:hidden"
                aria-label="Open navigation menu"
              >
                <Menu size={18} />
              </button>
              <h1 className="font-display truncate text-lg font-bold tracking-tight text-[#101828] sm:text-xl">
                {pageTitle}
              </h1>
            </div>

            {/* Search + Action Controls */}
            <div className="flex items-center gap-2.5 sm:gap-3">
              {/* Global Search */}
              <div className="relative hidden md:block">
                <Search
                  size={15}
                  className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-slate-400"
                />
                <input
                  type="search"
                  value={globalSearch}
                  onChange={(e) => setGlobalSearch(e.target.value)}
                  placeholder="Search trips or expenses..."
                  className="w-56 rounded-lg border border-[#E5E3F3] bg-[#F6F5FC] py-2 pr-3 pl-9 text-xs text-[#101828] outline-none transition-all focus:w-72 focus:border-[#7047EB] focus:bg-white"
                />

                {searchResults && (
                  <div className="absolute right-0 mt-2 w-80 rounded-xl border border-[#E5E3F3] bg-white p-2 shadow-xl">
                    {searchResults.matchedTrips.length === 0 &&
                    searchResults.matchedExpenses.length === 0 ? (
                      <p className="p-3 text-center text-xs text-[#525870]">
                        No trips or expenses match "{globalSearch}".
                      </p>
                    ) : (
                      <div className="space-y-2">
                        {searchResults.matchedTrips.length > 0 && (
                          <div>
                            <p className="px-2.5 py-1 text-[11px] font-semibold text-[#525870]">
                              Trips
                            </p>
                            {searchResults.matchedTrips.map((t) => (
                              <button
                                key={t.id}
                                type="button"
                                onClick={() => {
                                  navigate(`/trips/${t.id}`);
                                  setGlobalSearch('');
                                }}
                                className="flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-left text-xs hover:bg-[#F6F5FC]"
                              >
                                <span className="truncate font-semibold text-[#101828]">
                                  {t.name}
                                </span>
                                <span className="text-[11px] text-[#525870]">
                                  {t.destination}
                                </span>
                              </button>
                            ))}
                          </div>
                        )}
                        {searchResults.matchedExpenses.length > 0 && (
                          <div>
                            <p className="px-2.5 py-1 text-[11px] font-semibold text-[#525870]">
                              Expenses
                            </p>
                            {searchResults.matchedExpenses.map((e) => (
                              <button
                                key={e.id}
                                type="button"
                                onClick={() => {
                                  navigate('/expenses');
                                }}
                                className="flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-left text-xs hover:bg-[#F6F5FC]"
                              >
                                <span className="truncate font-medium text-[#101828]">
                                  {e.title}
                                </span>
                                <span className="font-mono-tabular shrink-0 font-semibold text-[#7047EB]">
                                  {formatINR(e.amountPaise)}
                                </span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Notifications Popover */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setNotifOpen((v) => !v);
                    setProfileOpen(false);
                  }}
                  className="relative inline-flex h-10 w-10 items-center justify-center rounded-lg border border-[#E5E3F3] bg-white text-[#202438] transition-colors hover:bg-[#F6F5FC]"
                  aria-label="Notifications"
                >
                  <Bell size={17} />
                  {notifications.length > 0 && (
                    <span className="font-mono-tabular absolute -top-1 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-[#EF5350] px-1 text-[10px] font-bold text-white">
                      {notifications.length}
                    </span>
                  )}
                </button>

                {notifOpen && (
                  <div className="absolute right-0 z-50 mt-2 w-80 rounded-xl border border-[#E5E3F3] bg-white p-3 shadow-xl sm:w-96">
                    <div className="mb-2 flex items-center justify-between border-b border-[#EFEFF7] pb-2">
                      <span className="text-xs font-bold text-[#101828]">
                        Budget Alerts & Settlement Reminders
                      </span>
                      <button
                        type="button"
                        onClick={() => setNotifOpen(false)}
                        className="text-xs font-medium text-[#525870] hover:text-[#101828]"
                      >
                        Close
                      </button>
                    </div>
                    {notifications.length === 0 ? (
                      <p className="py-4 text-center text-xs text-[#525870]">
                        All trip budgets and settlements are on track.
                      </p>
                    ) : (
                      <div className="max-h-72 space-y-2 overflow-y-auto">
                        {notifications.map((n) => (
                          <button
                            key={n.id}
                            type="button"
                            onClick={() => {
                              navigate(n.route);
                              setNotifOpen(false);
                            }}
                            className="flex w-full items-start gap-2.5 rounded-lg border border-[#EFEFF7] p-2.5 text-left transition-colors hover:bg-[#F6F5FC]"
                          >
                            <AlertTriangle
                              size={15}
                              className={`mt-0.5 shrink-0 ${
                                n.severity === 'danger'
                                  ? 'text-[#EF5350]'
                                  : n.severity === 'warning'
                                  ? 'text-[#F5A623]'
                                  : 'text-[#3478F6]'
                              }`}
                            />
                            <div className="min-w-0">
                              <p className="text-xs font-semibold text-[#101828]">{n.title}</p>
                              <p className="mt-0.5 text-[11px] leading-relaxed text-[#525870]">
                                {n.message}
                              </p>
                            </div>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Help Guide Trigger */}
              <button
                type="button"
                onClick={() => setHelpOpen(true)}
                className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-[#E5E3F3] bg-white text-[#202438] transition-colors hover:bg-[#F6F5FC]"
                aria-label="How TripTally works"
                title="How TripTally Works"
              >
                <HelpCircle size={17} />
              </button>

              {/* Active User Switcher */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setProfileOpen((v) => !v);
                    setNotifOpen(false);
                  }}
                  className="inline-flex h-10 items-center gap-2 rounded-lg border border-[#E5E3F3] bg-white px-2.5 text-xs font-semibold text-[#101828] transition-colors hover:bg-[#F6F5FC]"
                  title="Switch active viewing member"
                >
                  <MemberAvatar member={activeUser} size="xs" />
                  <span className="hidden whitespace-nowrap sm:inline">
                    {activeUser?.name.split(' ')[0]}
                  </span>
                </button>

                {profileOpen && (
                  <div className="absolute right-0 z-50 mt-2 w-60 rounded-xl border border-[#E5E3F3] bg-white p-2 shadow-xl">
                    <p className="px-2.5 py-1.5 text-[11px] font-semibold text-[#525870]">
                      View Balances As
                    </p>
                    {state.members.map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => {
                          updateSettings({ activeUserId: m.id });
                          setProfileOpen(false);
                        }}
                        className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-left text-xs transition-colors ${
                          m.id === activeUser?.id
                            ? 'bg-[#7047EB]/10 font-semibold text-[#7047EB]'
                            : 'text-[#202438] hover:bg-[#F6F5FC]'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <MemberAvatar member={m} size="xs" />
                          <span>{m.name}</span>
                        </div>
                        {m.id === activeUser?.id && <span className="text-[10px]">Active</span>}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Primary Action: Add New Trip */}
              <button
                type="button"
                onClick={() => setTripModalOpen(true)}
                className="inline-flex h-10 shrink-0 items-center gap-1.5 rounded-lg bg-[#7047EB] px-4 text-xs font-semibold whitespace-nowrap text-white shadow-sm transition-colors hover:bg-[#5E38D4]"
              >
                <Plus size={15} />
                <span>Add New Trip</span>
              </button>
            </div>
          </div>
        </header>

        {/* Main Viewport */}
        <main className="mx-auto w-full max-w-[1400px] flex-1 p-4 sm:p-6 lg:p-8">
          {children}
        </main>
      </div>

      {/* Global Modals */}
      <TripModal open={tripModalOpen} onClose={() => setTripModalOpen(false)} />
      <ToastContainer />

      {/* Help Modal */}
      {helpOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#101828]/50 p-4 backdrop-blur-[2px]"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-lg rounded-xl border border-[#E5E3F3] bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#EFEFF7] pb-3">
              <h2 className="font-display text-lg font-bold text-[#101828]">
                TripTally Financial Guide
              </h2>
              <button
                type="button"
                onClick={() => setHelpOpen(false)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-[#F6F5FC] hover:text-[#101828]"
              >
                <X size={18} />
              </button>
            </div>
            <div className="mt-4 space-y-3 text-xs leading-relaxed text-[#525870]">
              <p>
                <strong className="text-[#101828]">1. Integer Paise Precision:</strong> All
                amounts are calculated internally in integer paise (1 INR = 100 paise) so
                splits never lose or gain rounding cents.
              </p>
              <p>
                <strong className="text-[#101828]">2. Flexible Splitting:</strong> Choose
                Equal Split across the whole group, Subset Split for partial participation,
                or Exact Amount Split with live sum validation.
              </p>
              <p>
                <strong className="text-[#101828]">
                  3. Greedy Cash-Flow Minimization:
                </strong>{' '}
                TripTally computes each member&apos;s net balance (Total Paid − Total Share)
                and repeatedly pairs the largest debtor with the largest creditor to minimize
                the total number of settlement transfers.
              </p>
              <p>
                <strong className="text-[#101828]">4. Verified UPI Settlements:</strong>{' '}
                Opening a UPI link launches your payment app with pre-filled details. Debts
                are only marked paid after you explicitly confirm the payment.
              </p>
            </div>
            <div className="mt-5 flex justify-end">
              <button
                type="button"
                onClick={() => setHelpOpen(false)}
                className="rounded-lg bg-[#101828] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1E293B]"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
