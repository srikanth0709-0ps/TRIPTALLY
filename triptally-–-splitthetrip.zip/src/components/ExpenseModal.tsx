import React, { useEffect, useMemo, useState } from 'react';
import { Check, Image as ImageIcon, Trash2, Upload, X } from 'lucide-react';
import { useTripTally } from '../context/TripTallyContext';
import type { Expense, ExpenseCategory, ExpenseSplit, ReceiptAsset, SplitType } from '../types';
import {
  ALL_CATEGORIES,
  calculateEqualSplits,
  formatINR,
  fromPaise,
  toPaise,
  validateExactSplits,
} from '../utils/finance';
import { MemberAvatar } from './MemberAvatar';

interface ExpenseModalProps {
  open: boolean;
  defaultTripId?: string;
  editingExpense?: Expense | null;
  onClose: () => void;
}

export function ExpenseModal({
  open,
  defaultTripId,
  editingExpense,
  onClose,
}: ExpenseModalProps) {
  const { state, addExpense, updateExpense } = useTripTally();

  const [tripId, setTripId] = useState('');
  const [title, setTitle] = useState('');
  const [amountRupees, setAmountRupees] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Food');
  const [date, setDate] = useState('2026-11-19');
  const [paidByMemberId, setPaidByMemberId] = useState('');
  const [splitType, setSplitType] = useState<SplitType>('equal');
  const [participantIds, setParticipantIds] = useState<string[]>([]);
  const [exactInputs, setExactInputs] = useState<Record<string, string>>({});
  const [notes, setNotes] = useState('');
  const [receipt, setReceipt] = useState<ReceiptAsset | undefined>(undefined);
  const [error, setError] = useState('');

  const selectedTrip = useMemo(
    () => state.trips.find((t) => t.id === tripId) ?? state.trips[0],
    [state.trips, tripId]
  );

  const tripMembers = useMemo(() => {
    if (!selectedTrip) return state.members;
    const set = new Set(selectedTrip.memberIds);
    const filtered = state.members.filter((m) => set.has(m.id));
    return filtered.length > 0 ? filtered : state.members;
  }, [selectedTrip, state.members]);

  useEffect(() => {
    if (!open) return;
    if (editingExpense) {
      setTripId(editingExpense.tripId);
      setTitle(editingExpense.title);
      setAmountRupees(String(fromPaise(editingExpense.amountPaise)));
      setCategory(editingExpense.category);
      setDate(editingExpense.date);
      setPaidByMemberId(editingExpense.paidByMemberId);
      setSplitType(editingExpense.splitType);
      setParticipantIds(editingExpense.participantIds);
      const map: Record<string, string> = {};
      for (const s of editingExpense.splits) {
        map[s.memberId] = String(fromPaise(s.amountPaise));
      }
      setExactInputs(map);
      setNotes(editingExpense.notes);
      setReceipt(editingExpense.receipt);
    } else {
      const initialTrip =
        state.trips.find((t) => t.id === defaultTripId) ??
        state.trips.find((t) => t.status === 'active') ??
        state.trips[0];
      const initialTripId = initialTrip?.id ?? '';
      const initialMembers = initialTrip?.memberIds ?? state.members.map((m) => m.id);
      setTripId(initialTripId);
      setTitle('');
      setAmountRupees('');
      setCategory('Food');
      setDate(new Date().toISOString().slice(0, 10));
      setPaidByMemberId(
        initialMembers.includes(state.settings.activeUserId)
          ? state.settings.activeUserId
          : initialMembers[0] ?? ''
      );
      setSplitType(state.settings.defaultSplitType || 'equal');
      setParticipantIds(initialMembers);
      setExactInputs({});
      setNotes('');
      setReceipt(undefined);
    }
    setError('');
  }, [open, editingExpense, defaultTripId, state.trips, state.members, state.settings]);

  // Keep participants aligned if user switches trip during creation
  const handleTripChange = (nextTripId: string) => {
    setTripId(nextTripId);
    const nextTrip = state.trips.find((t) => t.id === nextTripId);
    if (nextTrip) {
      setParticipantIds(nextTrip.memberIds);
      if (!nextTrip.memberIds.includes(paidByMemberId)) {
        setPaidByMemberId(nextTrip.memberIds[0] ?? '');
      }
      setExactInputs({});
    }
  };

  const amountPaise = useMemo(() => toPaise(Number(amountRupees || 0)), [amountRupees]);

  // Compute live split preview
  const previewSplits: ExpenseSplit[] = useMemo(() => {
    if (splitType === 'exact') {
      return tripMembers
        .map((m) => ({
          memberId: m.id,
          amountPaise: toPaise(Number(exactInputs[m.id] || 0)),
        }))
        .filter((s) => s.amountPaise > 0);
    }
    const activeIds =
      splitType === 'equal'
        ? tripMembers.map((m) => m.id)
        : tripMembers.filter((m) => participantIds.includes(m.id)).map((m) => m.id);
    return calculateEqualSplits(amountPaise, activeIds);
  }, [splitType, tripMembers, participantIds, exactInputs, amountPaise]);

  const exactValidation = useMemo(() => {
    if (splitType !== 'exact') {
      return { valid: true, sumPaise: amountPaise, diffPaise: 0 };
    }
    const allSplits = tripMembers.map((m) => ({
      memberId: m.id,
      amountPaise: toPaise(Number(exactInputs[m.id] || 0)),
    }));
    return validateExactSplits(amountPaise, allSplits);
  }, [splitType, tripMembers, exactInputs, amountPaise]);

  if (!open) return null;

  const toggleParticipant = (id: string) => {
    setParticipantIds((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  };

  const handleSplitTypeChange = (nextType: SplitType) => {
    setSplitType(nextType);
    if (nextType === 'equal') {
      setParticipantIds(tripMembers.map((m) => m.id));
    } else if (nextType === 'exact') {
      // Seed exact inputs from current preview if empty
      const hasAny = Object.values(exactInputs).some((v) => Number(v) > 0);
      if (!hasAny && amountPaise > 0) {
        const eq = calculateEqualSplits(
          amountPaise,
          participantIds.length > 0 ? participantIds : tripMembers.map((m) => m.id)
        );
        const seeded: Record<string, string> = {};
        for (const s of eq) {
          seeded[s.memberId] = String(fromPaise(s.amountPaise));
        }
        setExactInputs(seeded);
      }
    }
  };

  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 4 * 1024 * 1024) {
      setError('Receipt image must be smaller than 4 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setReceipt({
          id: `rcpt_${Date.now()}`,
          name: file.name,
          dataUrl: reader.result,
          uploadedAt: new Date().toISOString(),
          sizeBytes: file.size,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tripId) {
      setError('Please select a trip.');
      return;
    }
    if (!title.trim()) {
      setError('Expense title is required.');
      return;
    }
    if (amountPaise <= 0) {
      setError('Please enter a valid positive amount in INR.');
      return;
    }
    if (!paidByMemberId) {
      setError('Please select who paid this expense.');
      return;
    }

    let finalParticipantIds: string[] = [];
    let finalSplits: ExpenseSplit[] = [];

    if (splitType === 'equal') {
      finalParticipantIds = tripMembers.map((m) => m.id);
      finalSplits = calculateEqualSplits(amountPaise, finalParticipantIds);
    } else if (splitType === 'subset') {
      finalParticipantIds = tripMembers
        .filter((m) => participantIds.includes(m.id))
        .map((m) => m.id);
      if (finalParticipantIds.length === 0) {
        setError('Select at least one participating member for a subset split.');
        return;
      }
      finalSplits = calculateEqualSplits(amountPaise, finalParticipantIds);
    } else {
      if (!exactValidation.valid) {
        setError(
          `Exact split shares must sum to ${formatINR(amountPaise)}. Difference: ${formatINR(
            exactValidation.diffPaise
          )}`
        );
        return;
      }
      finalSplits = previewSplits;
      finalParticipantIds = finalSplits.map((s) => s.memberId);
    }

    const payload = {
      tripId,
      title: title.trim(),
      amountPaise,
      category,
      date,
      paidByMemberId,
      participantIds: finalParticipantIds,
      splitType,
      splits: finalSplits,
      notes: notes.trim(),
      receipt,
    };

    if (editingExpense) {
      updateExpense(editingExpense.id, payload);
    } else {
      addExpense(payload);
    }
    onClose();
  };

  const memberMap = new Map(state.members.map((m) => [m.id, m]));

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#101828]/50 p-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
    >
      <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-xl border border-[#E5E3F3] bg-white shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[#EFEFF7] bg-white px-6 py-4">
          <div>
            <h2 className="font-display text-lg font-bold text-[#101828]">
              {editingExpense ? 'Edit Expense' : 'Log New Expense'}
            </h2>
            <p className="text-xs text-[#525870]">
              Precision paise-level splitting with live member share preview.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-[#F6F5FC] hover:text-[#101828]"
            aria-label="Close expense modal"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 p-6">
          {error && (
            <div className="rounded-lg border border-[#EF5350]/30 bg-[#EF5350]/10 px-4 py-2.5 text-xs font-medium text-[#C62828]">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                Trip *
              </label>
              <select
                value={tripId}
                onChange={(e) => handleTripChange(e.target.value)}
                className="w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm text-[#101828] outline-none focus:border-[#7047EB]"
              >
                {state.trips.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                Expense Title *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Sunset Beach Dinner"
                className="w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm text-[#101828] outline-none focus:border-[#7047EB] focus:ring-2 focus:ring-[#7047EB]/15"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                Amount (₹) *
              </label>
              <input
                type="number"
                min="0.01"
                step="0.01"
                value={amountRupees}
                onChange={(e) => setAmountRupees(e.target.value)}
                placeholder="0.00"
                className="font-mono-tabular w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm text-[#101828] outline-none focus:border-[#7047EB] focus:ring-2 focus:ring-[#7047EB]/15"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                Category *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                className="w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm text-[#101828] outline-none focus:border-[#7047EB]"
              >
                {ALL_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                Date *
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm tabular-nums text-[#101828] outline-none focus:border-[#7047EB]"
              />
            </div>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
              Paid By *
            </label>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {tripMembers.map((m) => {
                const active = paidByMemberId === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setPaidByMemberId(m.id)}
                    className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-left transition-colors ${
                      active
                        ? 'border-[#7047EB] bg-[#7047EB]/8 text-[#101828]'
                        : 'border-[#E5E3F3] bg-white text-[#525870] hover:bg-[#F6F5FC]'
                    }`}
                  >
                    <MemberAvatar member={m} size="xs" />
                    <span className="truncate text-xs font-semibold">{m.name.split(' ')[0]}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Split Type Selector */}
          <div className="border-t border-[#EFEFF7] pt-4">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <label className="text-xs font-semibold text-[#202438]">Split Method</label>
              <div className="inline-flex rounded-lg bg-[#F6F5FC] p-1">
                {(
                  [
                    { id: 'equal', label: 'Equal Split' },
                    { id: 'subset', label: 'Subset Split' },
                    { id: 'exact', label: 'Exact Amount' },
                  ] as const
                ).map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => handleSplitTypeChange(opt.id)}
                    className={`rounded-md px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                      splitType === opt.id
                        ? 'bg-white text-[#101828] shadow-sm'
                        : 'text-[#525870] hover:text-[#101828]'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {splitType === 'equal' && (
              <p className="mb-3 text-xs text-[#525870]">
                Split equally across all {tripMembers.length} trip members. Remainder paise
                are distributed deterministically so totals match to the exact paisa.
              </p>
            )}

            {splitType === 'subset' && (
              <div className="mb-3">
                <p className="mb-2 text-xs text-[#525870]">
                  Choose which members participated in this expense ({participantIds.length}{' '}
                  selected):
                </p>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {tripMembers.map((m) => {
                    const checked = participantIds.includes(m.id);
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => toggleParticipant(m.id)}
                        className={`flex items-center justify-between rounded-lg border px-3 py-2 text-left transition-colors ${
                          checked
                            ? 'border-[#3478F6] bg-[#3478F6]/8'
                            : 'border-[#E5E3F3] bg-white hover:bg-[#F6F5FC]'
                        }`}
                      >
                        <div className="flex min-w-0 items-center gap-2">
                          <MemberAvatar member={m} size="xs" />
                          <span className="truncate text-xs font-semibold text-[#101828]">
                            {m.name.split(' ')[0]}
                          </span>
                        </div>
                        {checked && <Check size={14} className="shrink-0 text-[#3478F6]" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {splitType === 'exact' && (
              <div className="mb-3 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#525870]">
                    Enter exact rupee amounts for each member:
                  </span>
                  <span
                    className={`font-mono-tabular font-semibold ${
                      exactValidation.valid ? 'text-[#16A36A]' : 'text-[#EF5350]'
                    }`}
                  >
                    {exactValidation.valid
                      ? 'Exact match (₹0 remaining)'
                      : exactValidation.diffPaise > 0
                      ? `${formatINR(exactValidation.diffPaise)} left to assign`
                      : `${formatINR(Math.abs(exactValidation.diffPaise))} over total`}
                  </span>
                </div>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {tripMembers.map((m) => (
                    <div
                      key={m.id}
                      className="flex items-center justify-between gap-2 rounded-lg border border-[#E5E3F3] bg-white px-3 py-2"
                    >
                      <div className="flex min-w-0 items-center gap-2">
                        <MemberAvatar member={m} size="xs" />
                        <span className="truncate text-xs font-semibold text-[#101828]">
                          {m.name}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-xs text-[#525870]">₹</span>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={exactInputs[m.id] ?? ''}
                          onChange={(e) =>
                            setExactInputs((prev) => ({
                              ...prev,
                              [m.id]: e.target.value,
                            }))
                          }
                          placeholder="0"
                          className="font-mono-tabular w-24 rounded-md border border-[#E5E3F3] px-2 py-1 text-right text-xs text-[#101828] outline-none focus:border-[#7047EB]"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Live Split Preview */}
            <div className="rounded-lg bg-[#F6F5FC] p-3.5">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-xs font-semibold text-[#101828]">
                  Live Split Preview
                </span>
                <span className="font-mono-tabular text-xs font-semibold text-[#7047EB]">
                  Total: {formatINR(amountPaise)}
                </span>
              </div>
              {previewSplits.length === 0 ? (
                <p className="text-xs text-[#525870]">
                  Enter an amount and choose participants to preview individual shares.
                </p>
              ) : (
                <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 sm:grid-cols-4">
                  {previewSplits.map((s) => {
                    const m = memberMap.get(s.memberId);
                    return (
                      <div
                        key={s.memberId}
                        className="flex items-center justify-between border-b border-[#E5E3F3]/80 py-1 text-xs"
                      >
                        <span className="truncate text-[#525870]">
                          {m?.name.split(' ')[0] ?? s.memberId}
                        </span>
                        <span className="font-mono-tabular font-semibold text-[#101828]">
                          {formatINR(s.amountPaise)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                Notes
              </label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Optional bill details, vendor name, or split context..."
                className="w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-sm text-[#101828] outline-none focus:border-[#7047EB]"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-[#202438]">
                Receipt Attachment
              </label>
              {receipt ? (
                <div className="flex items-center justify-between gap-3 rounded-lg border border-[#E5E3F3] bg-[#F6F5FC] p-2.5">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <img
                      src={receipt.dataUrl}
                      alt={receipt.name}
                      referrerPolicy="no-referrer"
                      className="h-12 w-12 shrink-0 rounded-md border border-[#E5E3F3] object-cover"
                    />
                    <div className="min-w-0">
                      <p className="truncate text-xs font-semibold text-[#101828]">
                        {receipt.name}
                      </p>
                      <p className="text-[11px] text-[#525870]">
                        {Math.max(1, Math.round(receipt.sizeBytes / 1024))} KB
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setReceipt(undefined)}
                    className="rounded-lg p-1.5 text-[#EF5350] hover:bg-[#EF5350]/10"
                    aria-label="Remove receipt"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              ) : (
                <label className="flex h-[84px] cursor-pointer flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-[#CBD5E1] bg-[#F6F5FC]/60 px-4 text-center transition-colors hover:border-[#7047EB] hover:bg-[#7047EB]/5">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#7047EB]">
                    <Upload size={14} />
                    <span>Upload Receipt Image</span>
                  </div>
                  <span className="inline-flex items-center gap-1 text-[11px] text-[#525870]">
                    <ImageIcon size={12} /> PNG, JPG, WebP up to 4 MB
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleReceiptUpload}
                    className="hidden"
                  />
                </label>
              )}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-[#EFEFF7] pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-[#E5E3F3] bg-white px-4 py-2 text-sm font-semibold text-[#202438] hover:bg-[#F6F5FC]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-[#7047EB] px-5 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#5B34D6]"
            >
              {editingExpense ? 'Save Expense' : 'Add Expense'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
