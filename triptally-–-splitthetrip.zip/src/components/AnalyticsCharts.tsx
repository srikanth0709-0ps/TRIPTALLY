import {
  ArcElement,
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Filler,
  Legend,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
  type ChartOptions,
} from 'chart.js';
import { Bar, Doughnut, Line } from 'react-chartjs-2';
import type { Expense, MemberBalance, Trip } from '../types';
import { ALL_CATEGORIES, CATEGORY_CONFIG, formatINR } from '../utils/finance';

ChartJS.register(
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
  Filler
);

const BASE_FONT = {
  family: "'Plus Jakarta Sans', system-ui, sans-serif",
  size: 12,
};

export function CategoryDoughnutChart({ expenses }: { expenses: Expense[] }) {
  const categoryTotals = ALL_CATEGORIES.map((cat) => {
    const sumPaise = expenses
      .filter((e) => e.category === cat)
      .reduce((acc, e) => acc + e.amountPaise, 0);
    return { cat, sumRupees: sumPaise / 100, color: CATEGORY_CONFIG[cat].chartColor };
  }).filter((item) => item.sumRupees > 0);

  if (categoryTotals.length === 0) {
    return (
      <div className="flex h-64 items-center justify-center text-xs text-[#525870]">
        Log expenses to visualize spending by category.
      </div>
    );
  }

  const data = {
    labels: categoryTotals.map((c) => c.cat),
    datasets: [
      {
        data: categoryTotals.map((c) => c.sumRupees),
        backgroundColor: categoryTotals.map((c) => c.color),
        borderColor: '#FFFFFF',
        borderWidth: 2,
        hoverOffset: 6,
      },
    ],
  };

  const options: ChartOptions<'doughnut'> = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '64%',
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          usePointStyle: true,
          pointStyle: 'circle',
          padding: 14,
          color: '#202438',
          font: BASE_FONT,
        },
      },
      tooltip: {
        backgroundColor: '#101828',
        padding: 10,
        callbacks: {
          label: (ctx) => {
            const val = Number(ctx.raw || 0);
            const total = categoryTotals.reduce((a, b) => a + b.sumRupees, 0);
            const pct = total > 0 ? ((val / total) * 100).toFixed(1) : '0';
            return ` ${ctx.label}: ${formatINR(Math.round(val * 100))} (${pct}%)`;
          },
        },
      },
    },
  };

  return (
    <div className="h-64 w-full">
      <Doughnut data={data} options={options} />
    </div>
  );
}

export function MonthlySpendingLineChart({ expenses }: { expenses: Expense[] }) {
  const monthMap = new Map<string, number>();

  for (const exp of expenses) {
    const key = exp.date.slice(0, 7); // YYYY-MM
    monthMap.set(key, (monthMap.get(key) ?? 0) + exp.amountPaise);
  }

  const sortedKeys = Array.from(monthMap.keys()).sort();

  if (sortedKeys.length === 0) {
    return (
      <div className="flex h-64 items-center justify-center text-xs text-[#525870]">
        No monthly expense data available for the selected filters.
      </div>
    );
  }

  const labels = sortedKeys.map((ym) => {
    const [y, m] = ym.split('-').map(Number);
    return new Date(y, (m || 1) - 1, 1).toLocaleDateString('en-IN', {
      month: 'short',
      year: 'numeric',
    });
  });

  const values = sortedKeys.map((k) => (monthMap.get(k) ?? 0) / 100);

  const data = {
    labels,
    datasets: [
      {
        label: 'Monthly Spending (₹)',
        data: values,
        borderColor: '#7047EB',
        backgroundColor: 'rgba(112, 71, 235, 0.12)',
        pointBackgroundColor: '#7047EB',
        pointBorderColor: '#FFFFFF',
        pointBorderWidth: 2,
        pointRadius: 5,
        pointHoverRadius: 7,
        tension: 0.32,
        fill: true,
      },
    ],
  };

  const options: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#101828',
        padding: 10,
        callbacks: {
          label: (ctx) => ` Spent: ${formatINR(Math.round(Number(ctx.raw || 0) * 100))}`,
        },
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: '#525870', font: BASE_FONT },
      },
      y: {
        beginAtZero: true,
        grid: { color: '#EFEFF7' },
        ticks: {
          color: '#525870',
          font: BASE_FONT,
          callback: (val) => `₹${Number(val).toLocaleString('en-IN')}`,
        },
      },
    },
  };

  return (
    <div className="h-64 w-full">
      <Line data={data} options={options} />
    </div>
  );
}

export function DailySpendingBarChart({ expenses }: { expenses: Expense[] }) {
  const dayMap = new Map<string, number>();
  for (const exp of expenses) {
    dayMap.set(exp.date, (dayMap.get(exp.date) ?? 0) + exp.amountPaise);
  }
  const sortedDates = Array.from(dayMap.keys()).sort();

  if (sortedDates.length === 0) {
    return (
      <div className="flex h-64 items-center justify-center text-xs text-[#525870]">
        No daily spending records match the active filter.
      </div>
    );
  }

  const data = {
    labels: sortedDates.map((d) => {
      const [y, m, day] = d.split('-').map(Number);
      return new Date(y, (m || 1) - 1, day || 1).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
      });
    }),
    datasets: [
      {
        label: 'Daily Spend',
        data: sortedDates.map((d) => (dayMap.get(d) ?? 0) / 100),
        backgroundColor: '#3478F6',
        borderRadius: 6,
        maxBarThickness: 38,
      },
    ],
  };

  const options: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#101828',
        padding: 10,
        callbacks: {
          label: (ctx) => ` Spend: ${formatINR(Math.round(Number(ctx.raw || 0) * 100))}`,
        },
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: '#525870', font: BASE_FONT },
      },
      y: {
        beginAtZero: true,
        grid: { color: '#EFEFF7' },
        ticks: {
          color: '#525870',
          font: BASE_FONT,
          callback: (val) => `₹${Number(val).toLocaleString('en-IN')}`,
        },
      },
    },
  };

  return (
    <div className="h-64 w-full">
      <Bar data={data} options={options} />
    </div>
  );
}

export function MemberContributionChart({ balances }: { balances: MemberBalance[] }) {
  if (balances.length === 0) {
    return (
      <div className="flex h-64 items-center justify-center text-xs text-[#525870]">
        No member contribution data available.
      </div>
    );
  }

  const data = {
    labels: balances.map((b) => b.member.name.split(' ')[0]),
    datasets: [
      {
        label: 'Total Paid',
        data: balances.map((b) => b.totalPaidPaise / 100),
        backgroundColor: '#16A36A',
        borderRadius: 6,
      },
      {
        label: 'Fair Share',
        data: balances.map((b) => b.totalSharePaise / 100),
        backgroundColor: '#7047EB',
        borderRadius: 6,
      },
    ],
  };

  const options: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          usePointStyle: true,
          pointStyle: 'circle',
          padding: 14,
          color: '#202438',
          font: BASE_FONT,
        },
      },
      tooltip: {
        backgroundColor: '#101828',
        padding: 10,
        callbacks: {
          label: (ctx) =>
            ` ${ctx.dataset.label}: ${formatINR(Math.round(Number(ctx.raw || 0) * 100))}`,
        },
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: '#525870', font: BASE_FONT },
      },
      y: {
        beginAtZero: true,
        grid: { color: '#EFEFF7' },
        ticks: {
          color: '#525870',
          font: BASE_FONT,
          callback: (val) => `₹${Number(val).toLocaleString('en-IN')}`,
        },
      },
    },
  };

  return (
    <div className="h-64 w-full">
      <Bar data={data} options={options} />
    </div>
  );
}

export function BudgetUtilizationChart({
  trips,
  expenses,
}: {
  trips: Trip[];
  expenses: Expense[];
}) {
  if (trips.length === 0) {
    return (
      <div className="flex h-64 items-center justify-center text-xs text-[#525870]">
        Create a trip to track budget utilization.
      </div>
    );
  }

  const tripStats = trips.map((t) => {
    const spent = expenses
      .filter((e) => e.tripId === t.id)
      .reduce((acc, e) => acc + e.amountPaise, 0);
    return {
      name: t.name.length > 20 ? `${t.name.slice(0, 18)}…` : t.name,
      budget: t.budgetPaise / 100,
      spent: spent / 100,
    };
  });

  const data = {
    labels: tripStats.map((t) => t.name),
    datasets: [
      {
        label: 'Allocated Budget',
        data: tripStats.map((t) => t.budget),
        backgroundColor: '#CBD5E1',
        borderRadius: 6,
      },
      {
        label: 'Actual Spend',
        data: tripStats.map((t) => t.spent),
        backgroundColor: tripStats.map((t) =>
          t.spent > t.budget ? '#EF5350' : t.spent >= t.budget * 0.9 ? '#F5A623' : '#3478F6'
        ),
        borderRadius: 6,
      },
    ],
  };

  const options: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          usePointStyle: true,
          pointStyle: 'circle',
          padding: 14,
          color: '#202438',
          font: BASE_FONT,
        },
      },
      tooltip: {
        backgroundColor: '#101828',
        padding: 10,
        callbacks: {
          label: (ctx) =>
            ` ${ctx.dataset.label}: ${formatINR(Math.round(Number(ctx.raw || 0) * 100))}`,
        },
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: '#525870', font: BASE_FONT },
      },
      y: {
        beginAtZero: true,
        grid: { color: '#EFEFF7' },
        ticks: {
          color: '#525870',
          font: BASE_FONT,
          callback: (val) => `₹${Number(val).toLocaleString('en-IN')}`,
        },
      },
    },
  };

  return (
    <div className="h-64 w-full">
      <Bar data={data} options={options} />
    </div>
  );
}
