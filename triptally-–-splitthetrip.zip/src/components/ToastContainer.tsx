import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';
import { useTripTally } from '../context/TripTallyContext';

export function ToastContainer() {
  const { toasts, dismissToast } = useTripTally();

  if (toasts.length === 0) return null;

  return (
    <div className="pointer-events-none fixed right-4 bottom-4 z-50 flex w-full max-w-sm flex-col gap-2.5">
      {toasts.map((toast) => {
        const Icon =
          toast.type === 'success'
            ? CheckCircle2
            : toast.type === 'error' || toast.type === 'warning'
            ? AlertCircle
            : Info;

        const iconColor =
          toast.type === 'success'
            ? 'text-[#16A36A]'
            : toast.type === 'error'
            ? 'text-[#EF5350]'
            : toast.type === 'warning'
            ? 'text-[#F5A623]'
            : 'text-[#3478F6]';

        return (
          <div
            key={toast.id}
            className="pointer-events-auto flex items-start gap-3 rounded-xl border border-[#E5E3F3] bg-white p-4 shadow-lg transition-all duration-200"
          >
            <Icon size={18} className={`mt-0.5 shrink-0 ${iconColor}`} />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-[#101828]">{toast.title}</p>
              {toast.description && (
                <p className="mt-0.5 text-xs leading-relaxed text-[#525870]">
                  {toast.description}
                </p>
              )}
            </div>
            <button
              type="button"
              onClick={() => dismissToast(toast.id)}
              className="rounded-md p-1 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600"
              aria-label="Dismiss notification"
            >
              <X size={14} />
            </button>
          </div>
        );
      })}
    </div>
  );
}
