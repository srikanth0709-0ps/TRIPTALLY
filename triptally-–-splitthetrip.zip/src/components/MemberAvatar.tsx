import { useState } from 'react';
import type { Member } from '../types';
import { getInitials } from '../utils/finance';

export function MemberAvatar({
  member,
  size = 'md',
}: {
  member?: Member;
  size?: 'xs' | 'sm' | 'md' | 'lg';
}) {
  const [imgError, setImgError] = useState(false);

  const dims =
    size === 'xs'
      ? 'h-6 w-6 text-[10px]'
      : size === 'sm'
      ? 'h-8 w-8 text-xs'
      : size === 'lg'
      ? 'h-11 w-11 text-sm'
      : 'h-9 w-9 text-xs';

  if (!member) {
    return (
      <span
        className={`inline-flex ${dims} shrink-0 items-center justify-center rounded-full bg-slate-200 font-semibold text-slate-600`}
      >
        ?
      </span>
    );
  }

  if (member.avatarUrl && !imgError) {
    return (
      <img
        src={member.avatarUrl}
        alt={member.name}
        referrerPolicy="no-referrer"
        onError={() => setImgError(true)}
        className={`${dims} shrink-0 rounded-full object-cover ring-2 ring-white`}
      />
    );
  }

  return (
    <span
      style={{ backgroundColor: member.avatarColor || '#7047EB' }}
      className={`inline-flex ${dims} shrink-0 items-center justify-center rounded-full font-semibold text-white ring-2 ring-white`}
      title={member.name}
    >
      {getInitials(member.name)}
    </span>
  );
}
