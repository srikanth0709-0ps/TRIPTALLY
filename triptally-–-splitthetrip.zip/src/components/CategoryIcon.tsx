import {
  Car,
  Compass,
  Hotel,
  MoreHorizontal,
  ShoppingBag,
  Utensils,
} from 'lucide-react';
import type { ExpenseCategory } from '../types';
import { CATEGORY_CONFIG } from '../utils/finance';

export function CategoryIcon({
  category,
  size = 16,
  showLabel = false,
}: {
  category: ExpenseCategory;
  size?: number;
  showLabel?: boolean;
}) {
  const cfg = CATEGORY_CONFIG[category];

  const Icon =
    category === 'Travel'
      ? Car
      : category === 'Food'
      ? Utensils
      : category === 'Stay'
      ? Hotel
      : category === 'Activities'
      ? Compass
      : category === 'Shopping'
      ? ShoppingBag
      : MoreHorizontal;

  return (
    <span className="inline-flex items-center gap-2">
      <span
        className={`inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${cfg.bgTint} ${cfg.textClass}`}
      >
        <Icon size={size} strokeWidth={2} />
      </span>
      {showLabel && (
        <span className={`text-xs font-semibold ${cfg.textClass}`}>{category}</span>
      )}
    </span>
  );
}
