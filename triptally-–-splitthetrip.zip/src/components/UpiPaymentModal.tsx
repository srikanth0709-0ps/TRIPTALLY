import { useState } from 'react';
import {
  ArrowRight,
  Check,
  CheckCircle2,
  Copy,
  ExternalLink,
  ShieldAlert,
  Smartphone,
  X,
} from 'lucide-react';
import { useTripTally } from '../context/TripTallyContext';
import type { Member, SettlementMethod } from '../types';
import { formatINR, generateUpiLink } from '../utils/finance';
import { MemberAvatar } from './MemberAvatar';

interface UpiPaymentModalProps {
  open: boolean;
  tripId: string;
  tripName: string;
  fromMember?: Member;
  toMember?: Member;
  amountPaise: number;
  onClose: () => void;
}

export function UpiPaymentModal({
  open,
  tripId,
  tripName,
  fromMember,
  toMember,
  amountPaise,
  onClose,
}: UpiPaymentModalProps) {
  const { markSettlementPaid, pushToast } = useTripTally();
  const [method, setMethod] = useState<SettlementMethod>('upi');
  const [note, setNote] = useState('');
  const [upiLaunched, setUpiLaunched] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!open || !fromMember || !toMember) return null;

  const upiLink = generateUpiLink({
    upiId: toMember.upiId,
    payeeName: toMember.name,
    amountPaise,
    tripName,
  });

  const handleCopyUpi = () => {
    navigator.clipboard?.writeText(toMember.upiId).catch(() => {});
    setCopied(true);
    pushToast({
      type: 'info',
      title: 'UPI ID Copied',
      description: `${toMember.upiId} copied to clipboard.`,
    });
    window.setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenUpiApp = () => {
    // Never mark paid automatically when UPI deep link is clicked.
    setUpiLaunched(true);
    window.location.href = upiLink;
  };

  const handleConfirmPaid = () => {
    markSettlementPaid({
      tripId,
      fromMemberId: fromMember.id,
      toMemberId: toMember.id,
      amountPaise,
      method,
      note: note.trim() || undefined,
    });
    setNote('');
    setUpiLaunched(false);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#101828]/50 p-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-lg rounded-xl border border-[#E5E3F3] bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#EFEFF7] px-6 py-4">
          <div>
            <h2 className="font-display text-lg font-bold text-[#101828]">
              Settle Payment via UPI
            </h2>
            <p className="text-xs text-[#525870]">{tripName}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 hover:bg-[#F6F5FC] hover:text-[#101828]"
            aria-label="Close payment modal"
          >
            <X size={18} />
          </button>
        </div>

        <div className="space-y-5 p-6">
          {/* Payer -> Payee Summary */}
          <div className="flex items-center justify-between rounded-xl bg-[#F6F5FC] p-4">
            <div className="flex items-center gap-2.5">
              <MemberAvatar member={fromMember} size="md" />
              <div>
                <p className="text-xs text-[#525870]">Payer</p>
                <p className="text-sm font-bold text-[#101828]">{fromMember.name}</p>
              </div>
            </div>

            <div className="flex flex-col items-center px-2">
              <span className="font-mono-tabular text-base font-bold text-[#7047EB]">
                {formatINR(amountPaise)}
              </span>
              <ArrowRight size={16} className="mt-0.5 text-[#7047EB]" />
            </div>

            <div className="flex items-center gap-2.5 text-right">
              <div>
                <p className="text-xs text-[#525870]">Recipient</p>
                <p className="text-sm font-bold text-[#101828]">{toMember.name}</p>
              </div>
              <MemberAvatar member={toMember} size="md" />
            </div>
          </div>

          {/* UPI Deep Link Box */}
          <div className="space-y-3 rounded-xl border border-[#E5E3F3] p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone size={16} className="text-[#3478F6]" />
                <span className="text-xs font-semibold text-[#101828]">
                  Payee UPI Address
                </span>
              </div>
              <button
                type="button"
                onClick={handleCopyUpi}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#3478F6] hover:text-[#1D5AD6]"
              >
                {copied ? <Check size={13} /> : <Copy size={13} />}
                {copied ? 'Copied' : 'Copy UPI ID'}
              </button>
            </div>

            <div className="flex items-center justify-between rounded-lg bg-[#F6F5FC] px-3.5 py-2.5">
              <code className="font-mono-tabular text-xs font-medium text-[#101828]">
                {toMember.upiId}
              </code>
              <span className="font-mono-tabular text-xs font-semibold text-[#525870]">
                {formatINR(amountPaise)}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={handleOpenUpiApp}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-[#101828] px-4 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-[#1E293B]"
              >
                <ExternalLink size={14} />
                Pay {toMember.name.split(' ')[0]} {formatINR(amountPaise)} via UPI App
              </button>
            </div>

            <div className="flex items-start gap-2 rounded-lg bg-[#F5A623]/10 p-2.5 text-[11px] leading-relaxed text-[#8B5A06]">
              <ShieldAlert size={14} className="mt-0.5 shrink-0 text-[#D97706]" />
              <span>
                {upiLaunched
                  ? 'UPI app link launched. Please complete the transfer in your UPI app and manually confirm below once verified.'
                  : 'Opening a UPI link only initiates the app on mobile. Settlements are never marked paid automatically until you verify and confirm below.'}
              </span>
            </div>
          </div>

          {/* Manual Verification & Mark Paid */}
          <div className="space-y-3 border-t border-[#EFEFF7] pt-4">
            <p className="text-xs font-semibold text-[#101828]">
              Manual Payment Confirmation
            </p>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  { id: 'upi', label: 'UPI Verified' },
                  { id: 'cash', label: 'Cash Paid' },
                  { id: 'bank', label: 'Bank Transfer' },
                ] as const
              ).map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMethod(m.id)}
                  className={`rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${
                    method === m.id
                      ? 'border-[#16A36A] bg-[#16A36A]/10 text-[#118254]'
                      : 'border-[#E5E3F3] bg-white text-[#525870] hover:bg-[#F6F5FC]'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Optional UPI Ref / UTR number or settlement note"
              className="w-full rounded-lg border border-[#E5E3F3] bg-white px-3.5 py-2 text-xs text-[#101828] outline-none focus:border-[#16A36A]"
            />

            <div className="flex items-center justify-end gap-3 pt-1">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-[#E5E3F3] bg-white px-4 py-2 text-sm font-semibold text-[#202438] hover:bg-[#F6F5FC]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmPaid}
                className="inline-flex items-center gap-2 rounded-lg bg-[#16A36A] px-5 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#138A59]"
              >
                <CheckCircle2 size={16} />
                Confirm & Mark as Paid
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
